﻿from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class ClickTransitionData:
    """内部解析状态流转类"""

    name: str = ""
    startup_id: int = -1
    deliver_ts: int = -1
    deliver_te: int = -1
    new_process: str | None = None
    startup_type: str | None = None
    new_utid: int = -1
    new_upid: int = -1
    new_pid: int = -1
    launching_ts: int = -1
    launching_te: int = -1
    resume_ts: int = -1
    resume_te: int = -1
    new_activity: str = ""
    wmframe_sf_ts: int = -1
    wmframe_sf_te: int = -1
    transition_time: int = -1
    wmshell: bool = False
    thread_state: dict[str, Any] = field(default_factory=dict)


@dataclass
class ClickTransitionResult:
    """对外输出的强类型结果类"""

    new_activity: str
    new_process: str
    op_start: int
    startup_type: str
    launching_dur: float
    response_time: int
    wmshell: bool
    thread_state: dict[str, Any]

    def to_dict(self):
        return asdict(self)

