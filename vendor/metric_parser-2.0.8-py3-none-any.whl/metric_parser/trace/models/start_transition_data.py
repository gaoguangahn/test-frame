# metric_parser/trace/models/startup_state.py
from dataclasses import asdict, dataclass, field

import pandas as pd


@dataclass
class StartupAnalyseState:
    """
    启动分析运行时状态（内部态）

    注意：
    - 仅供 analyse pipeline 内部使用
    - 允许存在 DataFrame / cache / 临时字段
    - 不作为最终返回结果
    """

    startup_id: int = -1
    new_package: str = ""
    new_activity: str = "unknown"
    new_upid: int = -1
    launching_dur: tuple[int, int] = field(default_factory=lambda: (-1, -1))

    deliver_ts: int = -1
    deliver_te: int = -1
    deliver_data: pd.DataFrame = field(default_factory=pd.DataFrame)

    startup_type: str = "unknown"

    animator_time: tuple[int, int] = field(default_factory=lambda: (-1, -1))
    animator_fps: int = -1

    response_time: int = -1
    spend_time: int = -1

    animation_frames: list[float] = field(default_factory=list)
    transaction_frames: list[float] = field(default_factory=list)
    thread_states: dict[str, int] = field(default_factory=dict)


@dataclass
class StartupTransitionResult:
    """
    应用启动分析最终结果（对外输出）
    """

    new_package: str
    new_activity: str
    startup_type: str
    op_start: int

    response_time: int
    spend_time: int

    animator_fps: int
    animation_frames: list[float] = field(default_factory=list)
    transaction_frames: list[float] = field(default_factory=list)
    thread_states: dict[str, int] = field(default_factory=dict)

    def to_dict(self):
        return asdict(self)
