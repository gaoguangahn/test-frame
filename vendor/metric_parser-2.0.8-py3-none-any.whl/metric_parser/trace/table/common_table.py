"""
建表SQL

版本: v1.1.0
"""

TABLE_LAUNCHER_ACTUAL_TIMELINE = """
    DROP TABLE IF EXISTS _launcher_actual_timelines;
    CREATE PERFETTO TABLE _launcher_actual_timelines AS
    SELECT
      s.id AS ui_slice_id,
      s.ts AS ui_ts,
      (s.ts + s.dur) AS ui_te,
      pt.upid AS upid
    FROM slice s
    JOIN process_track pt ON pt.id = s.track_id
    WHERE
      pt.name = 'Actual Timeline'
      AND pt.upid = {LAUNCHER_UPID}
      AND s.ts >= {start_ts}
      AND s.ts <= {end_ts}
    ORDER BY ui_ts;
    """

TABLE_SF_ACTUAL_TIMELINE = """
    DROP TABLE IF EXISTS _sf_actual_timelines;
    CREATE PERFETTO TABLE _sf_actual_timelines AS
    WITH sf_map AS (
      SELECT
        uf.ui_slice_id,
        uf.upid,
        uf.ui_ts,
        uf.ui_te,
        f.slice_in AS sf_slice_id
      FROM _launcher_actual_timelines uf
      JOIN directly_connected_flow(uf.ui_slice_id) f
    )
    SELECT
      sm.upid,
      sm.ui_slice_id,
      sm.sf_slice_id,
      sm.ui_ts,
      sm.ui_te,
      sl.ts AS sf_ts,
      (sl.ts + sl.dur) AS sf_te
    FROM sf_map sm
    JOIN slice sl ON sm.sf_slice_id = sl.slice_id
    ORDER BY sf_ts;
    """


# 表名: _uid_package_count，根据 package_list 建表，统计 uid 维度下不同 package 的数量
TABLE_UID_PACKAGE_COUNT = """
    DROP TABLE IF EXISTS _uid_package_count;
    CREATE PERFETTO TABLE _uid_package_count AS
    SELECT
      uid,
      count(1) AS cnt
    FROM package_list
    GROUP BY
      1;
    """

# 表名: _android_kernel_tasks，根据 process 建立内核任务表
TABLE_KERNEL_TASKS = """
    CREATE PERFETTO TABLE _android_kernel_tasks (
      upid LONG
    ) AS
    SELECT
      a.upid
    FROM process AS a
    LEFT JOIN process AS b
      ON a.parent_upid = b.upid
    WHERE
      b.name = 'kthreadd' OR a.pid = 0 OR b.pid = 0
    ORDER BY
      1;
    """

# 表名: android_process_metadata，建立进程元数据表，包含了进程名、进程 id、所属 uid、所属 package 等信息
TABLE_PROCESS_METADATA = """
    DROP TABLE IF EXISTS android_process_metadata;
    CREATE PERFETTO TABLE android_process_metadata (
      upid LONG,
      pid LONG,
      process_name STRING,
      uid LONG,
      package_name STRING,
      version_code LONG,
      debuggable LONG
    ) AS
    SELECT
      process.upid,
      process.pid,
      CASE
        WHEN length(process.name) = 15
        AND (
          process.cmdline IN ('zygote', 'zygote64', '<pre-initialized>')
          OR process.cmdline GLOB '*' || process.name
        )
        THEN process.cmdline
        ELSE process.name
      END AS process_name,
      process.android_appid AS uid,
      plist.package_name,
      plist.version_code,
      plist.debuggable
    FROM process
    LEFT JOIN _uid_package_count
      ON process.android_appid = _uid_package_count.uid
    LEFT JOIN _android_package_for_process(process.android_appid, _uid_package_count.cnt, process.name) AS plist
    ORDER BY
      upid;
    """

# 表名: _startup_async_events，建立activity start的表，
TABLE_STARTUP_ASYNC_EVENTS = """
    DROP VIEW IF EXISTS _startup_async_events;
    CREATE PERFETTO VIEW _startup_async_events AS
    SELECT
      ts,
      dur,
      cast_int!(SUBSTR(name, 19) ) AS startup_id
    FROM slice
    WHERE
      name GLOB 'launchingActivity#*' AND dur > 0 AND instr(name, ':') = 0;
    """

# 表名: _startup_complete_events，建立activity complete和activity cancel的表，用于应用启动完成事件
TABLE_STARTUP_COMPLETE_EVENTS = """
    CREATE PERFETTO VIEW _startup_complete_events AS
    SELECT
      cast_int!(STR_SPLIT(status, ':', 0)) AS startup_id,
      str_split(status, ':', 2) AS package_name,
      CASE
        WHEN str_split(status, ':', 1) = 'completed-hot' THEN 'hot'
        WHEN str_split(status, ':', 1) = 'completed-warm' THEN 'warm'
        WHEN str_split(status, ':', 1) = 'completed-cold' THEN 'cold'
        ELSE NULL
      END AS startup_type,
      min(ts)
    FROM (
      SELECT
        ts,
        substr(name, 19) AS status
      FROM slice
      WHERE
        dur = 0
        AND name GLOB 'launchingActivity#*:completed*:*'
    )
    GROUP BY
      1,
      2,
      3;
    """

# 表名: _same_process_activity_events，建立相同进程的activity点击启动完成的表，
TABLE_SAME_PROCESS_ACTIVITY_EVENTS = """
    DROP VIEW IF EXISTS _same_process_activity_events;
    CREATE PERFETTO VIEW _same_process_activity_events AS
    SELECT
      cast_int!(STR_SPLIT(completed, ':', 0)) AS startup_id,
      str_split(completed, ':', 2) AS package_name,
      CASE
        WHEN str_split(completed, ':', 1) = 'completed-hot'
        THEN 'hot'
        WHEN str_split(completed, ':', 1) = 'completed-warm'
        THEN 'warm'
        WHEN str_split(completed, ':', 1) = 'completed-cold'
        THEN 'cold'
        ELSE NULL
      END AS startup_type,
      min(ts)
    FROM (
      SELECT
        ts,
        substr(name, 19) AS completed
      FROM slice
      WHERE
        dur = 0
        AND name GLOB 'launchingActivity#*:completed*:*'
        AND name GLOB '*:completed*'
    )
    GROUP BY
      1,
      2,
      3;
    """

# 表名: android_activity_startups_raw，建立所有activity的点击启动表,不包含进程信息
TABLE_ACTIVITY_STARTUPS_RAW = """
    DROP TABLE IF EXISTS android_activity_startups_raw;
    CREATE PERFETTO TABLE android_activity_startups_raw AS
    SELECT
      startup_id,
      ts,
      ts + dur AS ts_end,
      dur,
      package_name AS package,
      startup_type
    FROM _startup_async_events
    JOIN _same_process_activity_events
      USING (startup_id);
    """

# view名: android_activity_startups，建立activity的点击启动表, 包含了进程信息和启动的包名
VIEW_ACTIVITY_STARTUPS = """
    DROP VIEW IF EXISTS android_activity_startups;
    CREATE PERFETTO VIEW android_activity_startups (
      startup_id LONG,
      ts LONG,
      ts_end LONG,
      package STRING,
      upid LONG,
      pid LONG
    ) AS
    SELECT
      l.startup_id,
      l.ts,
      l.ts_end,
      l.package,
      p.upid,
      p.pid
    FROM android_activity_startups_raw AS l
    JOIN android_process_metadata AS p
      ON (
        (p.process_name = l.package AND l.package = p.package_name)
        OR (
          NOT EXISTS (SELECT 1 FROM package_list)
          AND p.process_name = l.package
        )
      )
    JOIN thread AS t
      ON p.upid = t.upid AND t.is_main_thread;
    """

# 表名: _android_startups_raw，建立启动过程表，包含了启动id、启动类型、所属package等信息
TABLE_ANDROID_STARTUPS_RAW = """
    CREATE PERFETTO TABLE _android_startups_raw AS
    SELECT
      startup_id,
      ts,
      ts + dur AS ts_end,
      dur,
      package_name AS package,
      startup_type
    FROM _startup_async_events
    JOIN _startup_complete_events
      USING (startup_id);
    """

# 表名: _startup_indicator_slices，建立启动关键slice表，包含了关键slice的信息
TABLE_STARTUP_INDICATOR_SLICES = """
    CREATE PERFETTO TABLE _startup_indicator_slices AS
    SELECT
      ts,
      name,
      track_id
    FROM slice
    WHERE
      name IN ('bindApplication', 'activityStart', 'activityResume');
    """

# 表名: android_startup_processes，建立进程启动表，包含了startup_id、upid、pid、startup_type
TABLE_STARTUP_PROCESSES = """
    CREATE PERFETTO TABLE android_startup_processes (
      startup_id LONG,
      upid LONG,
      pid LONG,
      startup_type STRING
    ) AS
    WITH
      startup_with_type AS MATERIALIZED (
        SELECT
          startup_id,
          upid,
          pid,
          CASE
            WHEN startup_type IS NOT NULL THEN startup_type
            WHEN bind_app > 0
              AND a_start > 0
              AND a_resume > 0 THEN 'cold'
            WHEN a_start > 0
              AND a_resume > 0 THEN 'warm'
            WHEN a_resume > 0 THEN 'hot'
            ELSE NULL
          END AS startup_type
        FROM (
          SELECT
            l.startup_id,
            l.startup_type,
            p.upid,
            p.pid,
            _startup_indicator_slice_count(
              l.ts,
              l.ts_end,
              t.utid,
              'bindApplication'
            ) AS bind_app,
            _startup_indicator_slice_count(
              l.ts,
              l.ts_end,
              t.utid,
              'activityStart'
            ) AS a_start,
            _startup_indicator_slice_count(
              l.ts,
              l.ts_end,
              t.utid,
              'activityResume'
            ) AS a_resume
          FROM _android_startups_raw AS l
          JOIN android_process_metadata AS p
            ON (
              l.package = p.package_name
              OR (
                (SELECT count(1) = 0 FROM package_list)
                AND p.process_name GLOB l.package || '*'
              )
            )
          JOIN thread AS t
            ON p.upid = t.upid AND t.is_main_thread
          WHERE
            a_resume > 0
        )
      )
    SELECT *
    FROM startup_with_type
    WHERE startup_type IS NOT NULL;
    """

# view名: android_startups，建立最终的启动视图，包含了startup_id、ts、ts_end、dur、package、startup_type
VIEW_ANDROID_STARTUPS = """
    CREATE PERFETTO VIEW android_startups (
      startup_id ID,
      ts TIMESTAMP,
      ts_end LONG,
      dur DURATION,
      package STRING,
      startup_type STRING
    ) AS
    SELECT
      r.startup_id,
      r.ts,
      r.ts_end,
      r.dur,
      r.package,
      coalesce(r.startup_type, max(p.startup_type)) AS startup_type
    FROM _android_startups_raw AS r
    LEFT JOIN android_startup_processes AS p
      USING (startup_id)
    GROUP BY
      r.startup_id;
    """

# view名: android_startup_threads，
VIEW_ANDROID_STARTUP_THREADS = """
    CREATE PERFETTO VIEW android_startup_threads (
      startup_id LONG,
      ts TIMESTAMP,
      dur DURATION,
      upid LONG,
      pid LONG,
      utid LONG,
      tid LONG,
      thread_name STRING,
      is_main_thread BOOL
    ) AS
    SELECT
      startups.startup_id,
      startups.ts,
      startups.dur,
      android_startup_processes.upid,
      android_startup_processes.pid,
      thread.utid,
      thread.tid,
      thread.name AS thread_name,
      thread.is_main_thread AS is_main_thread
    FROM android_startups AS startups
    JOIN android_startup_processes
      USING (startup_id)
    JOIN thread
      USING (upid);
    """

# view名: thread_state_extended，添加列io_wait
VIEW_THREAD_STATE_EXTENDED = """
    DROP VIEW IF EXISTS thread_state_extended;
    CREATE PERFETTO VIEW thread_state_extended AS
    SELECT
      ts,
      IIF(dur = -1, trace_end(), dur) AS dur,
      utid,
      state,
      io_wait
    FROM thread_state;
    """

# 表名: launch_threads_by_thread_state，用于存放启动线程与其状态的映射关系
TABLE_LAUNCH_THREADS_BY_THREAD_STATE = """
    DROP TABLE IF EXISTS launch_threads_by_thread_state;
    CREATE VIRTUAL TABLE launch_threads_by_thread_state
    USING SPAN_JOIN(
      android_startup_threads PARTITIONED utid,
      thread_state_extended PARTITIONED utid
    );  
    """

# 表名: launch_thread_state_io_wait_dur_sum，用于存放线程状态与io_wait的映射关系
TABLE_LAUNCH_THREAD_STATE_IO_WAIT_DUR_SUM = """
    CREATE PERFETTO TABLE launch_thread_state_io_wait_dur_sum AS
    SELECT tid, startup_id, state, is_main_thread, thread_name, io_wait, SUM(dur) AS dur
    FROM launch_threads_by_thread_state l
    JOIN android_startup_processes p USING (startup_id)
    WHERE
      (is_main_thread AND p.startup_type NOT NULL)
      OR thread_name IN (
        'Jit thread pool'
      )
    GROUP BY 1, 2, 3, 4, 5, 6;
    """