"""
trace建表工具类

功能说明:
- 对传入TraceProcessor建各临时分析表

版本: v1.1.0
"""

from metric_parser.trace.base.trace_processor_handler import TraceProcessorHandler
from metric_parser.utils.logger import ParseLogger

from .common_function import *
from .common_table import *


class TableHandler:
    """
    建表类，用于创建一些必要的表和函数
    构造时注入 TraceProcessorHandler，一个 TableHandler 实例对应一个 tp
    """

    def __init__(self, tp: TraceProcessorHandler):
        self.tp = tp
        self.logger = ParseLogger("TableHandler")

        # 标记是否创建了某些表或者sql函数
        # 函数
        self.tag_func_package_for_process = False
        self.tag_func_kernel_tasks = False
        self.tag_func_startup_indicator_slice_count = False

        # 通用表
        self.tag_launcher_actual_timelines = False
        self.tag_sf_actual_timelines = False
        self.tag_uid_package_count = False
        self.tag_kernel_tasks = False
        self.tag_process_metadata_table = False

        # startup表
        self.tag_startup_async_events = False
        self.tag_startup_complete_events = False
        self.tag_same_process_activity_events = False
        self.tag_android_startups_raw = False
        self.tag_activity_startups_raw = False
        self.tag_android_startup_processes = False
        self.tag_startup_indicator_slices = False
        self.tag_android_startups = False
        self.tag_activity_startups = False
        self.tag_android_startup_threads = False
        self.tag_thread_state_extended = False
        self.tag_launch_threads_by_thread_state = False
        self.tag_launch_thread_state_io_wait_dur_sum = False

    def table_launcher_actual_timelines(self, upid, start_ts, end_ts):
        """
        创建launcher进程upid对应的实际时间线表
        """
        sql = TABLE_LAUNCHER_ACTUAL_TIMELINE.format(
            LAUNCHER_UPID=upid, start_ts=start_ts, end_ts=end_ts
        )
        self.tp.query(sql)
        self.tag_launcher_actual_timelines = True

    def table_sf_actual_timelines(self):
        """
        根据launcher实际时间线表，创建sf和launcher联系的时间线表
        """
        if not self.tag_launcher_actual_timelines:
            self.logger.e("需要先新建launcher实际时间线表")
            return

        self.tp.query(TABLE_SF_ACTUAL_TIMELINE)
        self.tag_sf_actual_timelines = True

    def table_uid_package_count(self):
        """
        创建 uid_package_count 表，用于从package_list中获取对应的uid和包含的包名\
        表名: _uid_package_count
        """
        if self.tag_uid_package_count:
            return
        sql = TABLE_UID_PACKAGE_COUNT
        self.tp.query(sql)
        self.tag_uid_package_count = True

    def func_package_for_process(self):
        """
        sql函数，用于根据进程名和uid获取到对应的包名等信息，执行后会建立一个新的临时表
        """
        if self.tag_func_package_for_process:
            return
        sql = FUNCTION_PACKAGE_FOR_PROCESS
        self.tp.query(sql)
        self.tag_func_package_for_process = True

    def table_kernel_tasks(self):
        """
        创建 kernel_tasks 表，生成一个包含所有内核任务（kernel tasks）的 upid
        判断父进程是不是内核线程管理器
        """
        if self.tag_kernel_tasks:
            return
        sql = TABLE_KERNEL_TASKS
        self.tp.query(sql)
        self.tag_kernel_tasks = True

    def func_is_kernel_task(self):
        """
        检查一个upid是否是内核线程
        """
        if self.tag_func_kernel_tasks:
            return
        self.table_kernel_tasks()
        sql = FUNCTION_IS_KERNEL_TASK
        self.tp.query(sql)
        self.tag_func_kernel_tasks = True

    def table_process_metadata_table(self):
        """
        创建 process_metadata 表，用于存储进程的重要信心，包括 upid、pid、process_name、uid、package_name等，
        如果没有package_list，包名信息会为空
        """
        if self.tag_process_metadata_table:
            return

        self.table_uid_package_count()
        self.func_package_for_process()
        sql = TABLE_PROCESS_METADATA
        self.tp.query(sql)
        self.tag_process_metadata_table = True

    def table_startup_async_events(self):
        """
        创建 _startup_async_events 表，用于存储应用启动时的异步事件，包括 ts、dur、startup_id
        """
        if self.tag_startup_async_events:
            return
        sql = TABLE_STARTUP_ASYNC_EVENTS
        self.tp.query(sql)
        self.tag_startup_async_events = True

    def table_startup_complete_events(self):
        """
        创建 _startup_complete_events 表，用于存储应用启动完成事件，包括 startup_id、package_name、startup_type、ts
        """
        if self.tag_startup_complete_events:
            return
        sql = TABLE_STARTUP_COMPLETE_EVENTS
        self.tp.query(sql)
        self.tag_startup_complete_events = True

    def table_same_process_activity_events(self):
        """
        创建 _same_process_activity_events 表，用于同一个进程中的activity启动事件
        """
        if self.tag_same_process_activity_events:
            return
        sql = TABLE_SAME_PROCESS_ACTIVITY_EVENTS
        self.tp.query(sql)
        self.tag_same_process_activity_events = True

    def table_android_startups(self):
        """
        创建 _android_startups_raw 表，用于存储应用启动信息，包括 startup_id、ts、te、dur、package、startup_type
        """
        if self.tag_android_startups_raw:
            return
        self.table_startup_async_events()
        self.table_startup_complete_events()
        sql = TABLE_ANDROID_STARTUPS_RAW
        self.tp.query(sql)
        self.tag_android_startups_raw = True

    def table_activity_startups(self):
        """
        创建 _android_activity_startups_raw 表，用于存储activity点击启动信息，包含应用内点击和启动应用
        """
        if self.tag_activity_startups_raw:
            return
        self.table_startup_async_events()
        self.table_same_process_activity_events()
        sql = TABLE_ACTIVITY_STARTUPS_RAW
        self.tp.query(sql)
        self.tag_activity_startups_raw = True

    # def view_activity_startups(self):
    #     """
    #     创建 android_activity_startups 视图，用于查看应用启动信息，归并同一个startup_id的启动进程
    #     """
    #     if self.tag_activity_startups:
    #         return
    #     self.table_android_startups()
    #     self.table_process_metadata_table()
    #     sql = VIEW_ACTIVITY_STARTUPS
    #     self.tp.query(sql)
    #     self.tag_activity_startups = True

    def table_startup_indicator_slices(self):
        """
        创建 _startup_indicator_slices 表，用于存储应用启动时的关键slice
        """
        if self.tag_startup_indicator_slices:
            return
        sql = TABLE_STARTUP_INDICATOR_SLICES
        self.tp.query(sql)
        self.tag_startup_indicator_slices = True

    def func_startup_indicator_slice_count(self):
        """
        创建 _startup_indicator_slice_count 函数，用于计算 startup_id 对应的关键 slice 数量
        """
        if self.tag_func_startup_indicator_slice_count:
            return
        if not self.tag_startup_indicator_slices:
            self.table_startup_indicator_slices()
        sql = FUNCTION_STARTUP_INDICATOR_SLICE_COUNT
        self.tp.query(sql)
        self.tag_func_startup_indicator_slice_count = True

    def table_android_startup_processes(self):
        """
        表名: android_startup_processes，建立进程启动表，包含了startup_id、upid、pid、startup_type
        """
        if self.tag_android_startup_processes:
            return
        self.table_process_metadata_table()
        self.table_android_startups()
        self.func_startup_indicator_slice_count()
        sql = TABLE_STARTUP_PROCESSES
        self.tp.query(sql)
        self.tag_android_startup_processes = True

    def view_android_startups(self):
        """
        创建 android_startups 视图，用于查看应用启动信息，归并同一个startup_id的启动进程
        """
        if self.tag_android_startups:
            return
        self.table_android_startup_processes()
        sql = VIEW_ANDROID_STARTUPS
        self.tp.query(sql)
        self.tag_android_startups = True

    def view_android_startup_threads(self):
        """
        创建 android_startup_threads 视图，用于查看应用启动时的进程和线程信息
        """
        if self.tag_android_startup_threads:
            return
        self.view_android_startups()
        sql = VIEW_ANDROID_STARTUP_THREADS
        self.tp.query(sql)
        self.tag_android_startup_threads = True

    def view_thread_state_extended(self):
        """
        创建 thread_state_extended 视图，消除dur=-1的情况，方便后续的计算
        """
        if self.tag_thread_state_extended:
            return
        sql = VIEW_THREAD_STATE_EXTENDED
        self.tp.query(sql)
        self.tag_thread_state_extended = True

    def table_launch_threads_by_thread_state(self):
        """创建 launch_threads_by_thread_state 表，用于存储启动线程的相关信息"""
        if self.tag_launch_threads_by_thread_state:
            return
        self.view_android_startup_threads()
        self.view_thread_state_extended()
        sql = TABLE_LAUNCH_THREADS_BY_THREAD_STATE
        self.tp.query(sql)
        self.tag_launch_threads_by_thread_state = True

    def table_launch_thread_state_io_wait_dur_sum(self):
        """创建 launch_thread_state_io_wait_dur_sum 表，用于存储启动线程的io等待时间相关信息"""
        if self.tag_launch_thread_state_io_wait_dur_sum:
            return
        self.table_launch_threads_by_thread_state()
        sql = TABLE_LAUNCH_THREAD_STATE_IO_WAIT_DUR_SUM
        self.tp.query(sql)
        self.tag_launch_thread_state_io_wait_dur_sum = True
