from pathlib import Path

import metric_parser.trace.parsers
from metric_parser.trace.base.base_analyser import AnalyseResult
from metric_parser.trace.base.context import TraceContext
from metric_parser.trace.base.registry import AnalyseRegistry
from metric_parser.trace.models.app_exit_data import ExitAnimationResult
from metric_parser.trace.models.click_response_data import ClickResponseResult
from metric_parser.trace.models.click_transition_data import ClickTransitionResult
from metric_parser.trace.models.control_center_data import ControlCenterResult
from metric_parser.trace.models.keyboard_popup_data import KeyboardPopupResult
from metric_parser.trace.models.multi_task_data import MultiTaskResult
from metric_parser.trace.models.start_transition_data import StartupTransitionResult
from metric_parser.trace.models.swipe_offscreen_data import SwipeOffScreenResult
from metric_parser.trace.models.swipe_onscreen_data import SwipeOnScreenResult


class TraceParser:
    """
    Trace 解析库的统一对外暴露入口。
    封装了资源管理(Context)和分析器调度，支持上下文管理器(with)语法。
    """

    def __init__(
        self,
        trace_file: str,
        exe_path: str | None = None,
        device_brand: str = "Honor",
    ):
        """
        初始化 Trace 解析器
        :param trace_file: 必传，trace 文件的路径
        :param exe_path: 可选，trace_processor_shell_win.exe 的路径。不传则使用库内默认路径
        :param device_brand: 可选，设备品牌，默认为 "Honor"
        """

        # 如果外部没有传入 exe_path，则使用相对当前文件的默认路径
        if exe_path is None:
            # 获取当前文件 (trace_parser.py) 所在的绝对目录
            current_dir = Path(__file__).resolve().parent
            # 拼接默认的 exe 路径: metric_parser/res/trace_processor_shell_win.exe
            default_exe_path = current_dir / "res" / "trace_processor_shell_win.exe"

            if not default_exe_path.exists():
                raise FileNotFoundError(
                    f"未找到默认的 trace_processor 执行文件: {default_exe_path}，"
                    f"请检查库文件完整性或手动传入 exe_path"
                )
            exe_path = str(default_exe_path)

        # 内部持有 Context 管理器，但不立即激活（等待 __enter__）
        self._context_manager = TraceContext(exe_path, trace_file, device_brand)
        self.context = None
        self._analyser_cache = {}  # 缓存已实例化的分析器，避免重复创建

    def __enter__(self):
        # 激活 Context，加载 Trace
        self.context = self._context_manager.__enter__()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        # 释放资源，清理 TraceProcessor 进程
        self._context_manager.__exit__(exc_type, exc_val, exc_tb)

    def _get_analyser_instance(self, metric_name: str):
        """从注册表获取分析器并实例化（懒加载）"""
        if not self.context:
            raise RuntimeError(
                "TraceParser 尚未初始化，请使用 'with TraceParser(...) as parser:' 语法"
            )

        if metric_name not in self._analyser_cache:
            analyser_cls = AnalyseRegistry.get_analyser(metric_name)
            if not analyser_cls:
                raise ValueError(f"未找到注册名为 '{metric_name}' 的分析器")
            # 注入 context 并缓存实例
            self._analyser_cache[metric_name] = analyser_cls(self.context)

        return self._analyser_cache[metric_name]

    # ==========================================
    # 以下是对外暴露的强类型业务解析接口
    # ==========================================

    def startup_transition(
        self,
        from_app: str | None = None,
        start: int | None = None,
        end: int | None = None,
    ) -> AnalyseResult[list[StartupTransitionResult]]:
        """
        解析应用启动响应与动效指标
        :param from_app: 起始进程名（如 Launcher）
        :param start: 搜索起始时间戳 (ns)
        :param end: 搜索结束时间戳 (ns)
        """
        analyser = self._get_analyser_instance("startup_transition")
        return analyser.analyse(from_app=from_app, start=start, end=end)

    def non_desk_start(
        self,
        from_app: str | None = None,
        start: int | None = None,
        end: int | None = None,
    ) -> AnalyseResult[list[StartupTransitionResult]]:
        """
        解析非桌面启动响应与动效指标
        :param start: 搜索起始时间戳 (ns)
        :param end: 搜索结束时间戳 (ns)
        """
        analyser = self._get_analyser_instance("non_desk_start")
        return analyser.analyse(from_app=from_app, start=start, end=end)

    def exit_animation(
        self, start: int | None = None, end: int | None = None
    ) -> AnalyseResult[list[ExitAnimationResult]]:
        """
        解析应用退出动画指标
        :param start: 搜索起始时间戳 (ns)
        :param end: 搜索结束时间戳 (ns)
        """
        analyser = self._get_analyser_instance("exit_animation")
        return analyser.analyse(start=start, end=end)

    def click_response(
        self, start: int | None = None, end: int | None = None
    ) -> AnalyseResult[list[ClickResponseResult]]:
        """
        解析应用内点击延迟响应指标（测量从触摸事件到UI响应的完整处理链路耗时）
        :param start: 搜索起始时间戳 (ns)
        :param end: 搜索结束时间戳 (ns)
        """
        analyser = self._get_analyser_instance("click_response")
        return analyser.analyse(start=start, end=end)

    def click_transition(
        self, start: int | None = None, end: int | None = None
    ) -> AnalyseResult[list[ClickTransitionResult]]:
        """
        解析应用内点击转场时间指标
        :param start: 搜索起始时间戳 (ns)
        :param end: 搜索结束时间戳 (ns)
        """
        analyser = self._get_analyser_instance("click_transition")
        return analyser.analyse(start=start, end=end)

    def swipe_offscreen(
        self,
        package: str,
        activity: str,
        start: int | None = None,
        end: int | None = None,
    ) -> AnalyseResult[list[SwipeOffScreenResult]]:
        """
        解析应用内离手滑动动效卡顿指标
        :param package: 目标应用包名
        :param activity: 目标应用 Activity
        :param start: 搜索起始时间戳 (ns)
        :param end: 搜索结束时间戳 (ns)
        """
        analyser = self._get_analyser_instance("swipe_offScreen")
        return analyser.analyse(
            package=package, activity=activity, start=start, end=end
        )

    def swipe_onscreen(
        self,
        package: str,
        activity: str,
        start: int | None = None,
        end: int | None = None,
        vertical: bool = True,
    ) -> AnalyseResult[list[SwipeOnScreenResult]]:
        """
        解析应用内跟手滑动动效卡顿指标
        :param package: 目标应用包名
        :param activity: 目标应用 Activity
        :param start: 搜索起始时间戳 (ns)
        :param end: 搜索结束时间戳 (ns)
        :param vertical: 是否为垂直滑动 (默认 True)
        """
        analyser = self._get_analyser_instance("swipe_onScreen")
        return analyser.analyse(
            package=package, activity=activity, start=start, end=end, vertical=vertical
        )

    def control_center(
        self, start: int | None = None, end: int | None = None
    ) -> AnalyseResult[list[ControlCenterResult]]:
        """
        解析下拉控制中心和通知栏的动效卡顿指标
        :param start: 搜索起始时间戳 (ns)
        :param end: 搜索结束时间戳 (ns)
        """
        analyser = self._get_analyser_instance("control_center")
        return analyser.analyse(start=start, end=end)

    def multi_task(
        self, start: int | None = None, end: int | None = None
    ) -> AnalyseResult[list[MultiTaskResult]]:
        """
        解析进入多任务界面的动效卡顿指标
        :param start: 搜索起始时间戳 (ns)
        :param end: 搜索结束时间戳 (ns)
        """
        analyser = self._get_analyser_instance("multi_task")
        return analyser.analyse(start=start, end=end)

    def keyboard_popup(
        self,
        from_app: str | None = None,
        start: int | None = None,
        end: int | None = None,
    ) -> AnalyseResult[list[KeyboardPopupResult]]:
        """
        解析输入法弹出响应和动效丢帧指标
        :param from_app: 触发输入法弹出的应用进程名
        :param start: 搜索起始时间戳 (ns)
        :param end: 搜索结束时间戳 (ns)
        """
        analyser = self._get_analyser_instance("input_method")
        return analyser.analyse(from_app=from_app, start=start, end=end)

    # ==========================================
    # 辅助属性与方法
    # ==========================================

    @property
    def trace_length(self) -> float:
        """获取 Trace 总时长（秒）"""
        return self.context.trace_length if self.context else 0.0

    @property
    def trace_start(self) -> int:
        """获取 Trace 起始时间戳 (ns)"""

        return self.context.trace_start if self.context else 0

    @property
    def trace_end(self) -> int:
        """获取 Trace 结束时间戳 (ns)"""

        return self.context.trace_end if self.context else 0


if __name__ == "__main__":
    # 1. 准备路径
    TRACE_FILE = r"D:\ptrace_analysis\execute_framework\execute_framework\outputs\dynamic2\ASPS015928000498\round_001\TestCamera_test_camera\traces\Camera_CameraPhoto.pftrace"

    # 2. 使用 with 语法自动管理资源（进入时启动进程，退出时自动销毁进程）
    with TraceParser(trace_file=TRACE_FILE, device_brand="Honor") as parser:
        print(f"Trace 加载成功，总时长: {parser.trace_length} 秒")
        res = parser.non_desk_start(from_app="com.hihonor.camera")
        if res.success:
            print(res.data)
