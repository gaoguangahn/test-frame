"""
应用启动响应/应用启动动效分析模块

功能说明:
- 测量应用启动过程从点击到动效第一帧渲染的响应时间
- 测量应用启动过程的launcher动效卡顿和动效引擎卡顿
- 支持时间段多次应用启动场景分析

版本: v1.1.0
"""

import numpy as np
import pandas as pd

from metric_parser.trace.base.base_analyser import BaseTraceAnalyse
from metric_parser.trace.base.constants import HonorMachines
from metric_parser.trace.base.registry import AnalyseRegistry
from metric_parser.trace.base.sqls import SqlFactory
from metric_parser.trace.models.start_transition_data import (
    StartupAnalyseState,
    StartupTransitionResult,
)
from metric_parser.trace.parsers.utils.thread_state import StateQuery
from metric_parser.trace.parsers.utils.util import is_all_none


@AnalyseRegistry.register("startup_transition")
class StartupTransition(BaseTraceAnalyse):
    """应用启动响应/应用启动动效分析模块"""

    def __init__(self, context):
        super().__init__(context)
        self.state_query = StateQuery(self.tp)
        self.sqls = SqlFactory.get_sql_class(self.device_brand)

    def analyse(self, from_app=None, start=None, end=None, **kwargs):
        """返回启动响应、耗时、动效、线程状态等"""

        try:
            startup_states = self._analyse_internal(from_app, start, end)
        except Exception as e:
            self.logger.e(f"应用启动分析失败: {e}")
            return self.fail(f"应用启动分析失败: {e}")

        # 返回的数据
        results: list[StartupTransitionResult] = []

        for state in startup_states:
            if state.response_time == -1:
                continue

            results.append(
                StartupTransitionResult(
                    new_package=state.new_package,
                    new_activity=state.new_activity,
                    startup_type=state.startup_type,
                    op_start=start if start else state.deliver_ts,
                    response_time=state.response_time,
                    spend_time=state.spend_time,
                    animator_fps=state.animator_fps,
                    animation_frames=state.animation_frames,
                    transaction_frames=state.transaction_frames,
                    thread_states=state.thread_states,
                )
            )

        return self.success(results)

    def _analyse_internal(
        self, from_app: str | None, start: int | None, end: int | None
    ) -> list[StartupAnalyseState]:
        """获取应用启动的相关metric"""

        startup_states: list[StartupAnalyseState] = []

        # 1.获取实际的分析时间范围
        actual_start_time, actual_end_time = self._validate_time_range(start, end)
        if actual_start_time is None or actual_end_time is None:
            self.logger.e("获取trace检测时间段失败")
            raise ValueError("获取trace检测时间段失败")

        # 2.获取启动的起始进程
        from_app_final = from_app or getattr(self.sqls, "launcher_process", None)
        if not from_app_final:
            self.logger.e("获取from app失败")
            raise ValueError("获取from app失败")

        from_upid_sql = self.sqls.query_process_upid(process_name=from_app_final)
        from_upid_data = self.tp.query(from_upid_sql)

        from_app_upid = (
            int(from_upid_data.iloc[0]["upid"]) if not from_upid_data.empty else -1
        )
        if from_app_upid == -1:
            self.logger.e("获取from app upid失败")
            raise ValueError("获取from app upid失败")

        # 3.获取本次启动的包名列表
        startup_states = self._get_launching_pkgs(
            start_time=actual_start_time, end_time=actual_end_time
        )

        if not startup_states:
            self.logger.w("没有识别到应用启动")
            return startup_states

        # 4.获取各次启动前的触控时间戳
        startup_states = self._get_deliver_input(
            startup_states=startup_states,
            from_app=from_app_final,
            start_time=actual_start_time,
            end_time=actual_end_time,
        )

        # 5.获取动画起止时间戳
        # startup_type 已在 android_startup_processes 中按新版 Perfetto 逻辑计算，
        # 这里不再额外判断冷热温，避免使用错误/兜底 upid 造成类型偏差。
        self._get_animator_time(startup_states=startup_states, end_time=actual_end_time)

        # 7.输入事件的修正
        startup_states = self._correct_iq_input(startup_states=startup_states)

        # 8.获取launcher线程的帧间隔
        self._get_launcher_view_frames(
            startup_states=startup_states,
            from_app_upid=from_app_upid,
            start_time=actual_start_time,
            end_time=actual_end_time,
        )

        # 9.获取动效引擎的帧间隔
        if self.device_brand in HonorMachines.HONOR_BRANDS:
            self._get_transaction_frames(
                startup_states=startup_states,
                start_time=actual_start_time,
                end_time=actual_end_time,
            )

        # 10.获取启动耗时
        self._get_startup_spend(startup_states=startup_states)

        return startup_states

    def _get_launching_pkgs(
        self, start_time: int, end_time: int
    ) -> list[StartupAnalyseState]:
        """
        获取本次启动的包名列表, 根据launching：寻找
        """
        startup_states: list[StartupAnalyseState] = []

        # 创建 _android_startups_raw，查表得到本段trace中的启动信息
        try:
            self.table_handler.view_android_startups()
        except Exception as e:
            self.logger.e(f"构建 android_startups_raw 失败: {e}")
            return startup_states

        sql = self.sqls.query_android_startups(
            process_name=self.sqls.launcher_process,
            start_time=start_time,
            end_time=end_time,
        )
        df_startup = self.tp.query(sql)

        # 填充默认值
        df_startup = df_startup.fillna(
            {
                "package": "unknown",
                "ts": -1,
                "ts_end": -1,
                "dur": -1,
                "upid": -1,
                "startup_type": "unknown",
            }
        )

        # 1. 循环外：一次性查出全局所有的 performResume
        global_resume_sql = getattr(self.sqls, "query_global_activity_resume", None)
        if global_resume_sql:
            global_resume_df = self.tp.query(global_resume_sql(start_time, end_time))
        else:
            global_resume_df = pd.DataFrame()

        for _, row in df_startup.iterrows():
            pkg_name = row["package"]
            launching_ts = int(row["ts"])
            launching_te = int(row["ts_end"])

            if not pkg_name:
                self.logger.i("无法确定进程名，该次启动无效")
                continue

            # 3. UPID 由 android_startup_processes 按新版 Perfetto 逻辑提供。
            # 不再按包名 fallback 查询 process upid，避免多进程/旧进程场景拿错启动目标进程。
            current_upid = row.get("upid", -1)
            if pd.isna(current_upid):
                current_upid = -1
            else:
                current_upid = int(current_upid)

            # 4. 优化 Activity 获取：Pandas 内存过滤
            new_activity = "unknown"
            if not global_resume_df.empty:
                # 过滤条件：时间在 launching 范围内，且进程名匹配
                mask = (
                    (global_resume_df["slice_ts"] >= launching_ts)
                    & (global_resume_df["slice_ts"] <= launching_te)
                    & (
                        global_resume_df["process_name"].str.startswith(
                            pkg_name, na=False
                        )
                    )
                )
                resume_df = global_resume_df.loc[mask]

                if not resume_df.empty:
                    # 取最后一条
                    first_resume = resume_df.iloc[-1]
                    resume_name = first_resume.get("slice_name", None)
                    if isinstance(resume_name, str) and ":" in resume_name:
                        new_activity = resume_name.split(":", 1)[1]
                    else:
                        new_activity = resume_name or ""

            startup_id = row.get("startup_id", -1)
            if pd.isna(startup_id):
                startup_id = -1
            else:
                startup_id = int(startup_id)

            startup_states.append(
                StartupAnalyseState(
                    startup_id=startup_id,
                    new_package=pkg_name,
                    new_activity=new_activity,
                    new_upid=current_upid,
                    launching_dur=(row["ts"], row["ts_end"]),
                    startup_type=row["startup_type"],
                )
            )
        return startup_states

    def _get_deliver_input(
        self,
        startup_states: list[StartupAnalyseState],
        from_app: str,
        start_time: int,
        end_time: int,
    ) -> list[StartupAnalyseState]:
        """获取输入的时间戳
        根据两次launching之间有无触控数据，做一步筛选，排除掉应用启动连续启动两个activity的情况
        """
        if not startup_states:
            return startup_states

        new_startups: list[StartupAnalyseState] = []

        # 1) 获取 deliverInputEvent 触控事件，通过 process_name 判断是哪个进程产生的 deliverInputEvent
        deliver_input_sql = self.sqls.query_deliver_input(
            process_name=from_app,
            start_time=start_time,
            end_time=end_time,
        )
        deliver_input_data = self.tp.query(deliver_input_sql)

        if deliver_input_data.empty:
            return new_startups

        for i, startup in enumerate(startup_states):
            # 查找launching_ts之前最近的deliver
            pre_launching_te = (
                startup_states[i - 1].launching_dur[1] if i > 0 else start_time
            )
            # 找到满足：pre_launching_te < iq_input_ts < startup.launching_ts 的所有触控
            delivers_in_range = deliver_input_data.loc[
                (deliver_input_data["slice_ts"] > pre_launching_te)
                & (deliver_input_data["slice_ts"] < startup.launching_dur[0])
            ]

            if delivers_in_range.empty:
                # 连续 Activity 启动或无输入，跳过
                continue

            nearest_deliver = delivers_in_range.iloc[-1]
            # 检查异常滑动
            try:
                check_deliver_sql = self.sqls.check_deliver_input(
                    deliver_input_ts=int(nearest_deliver["slice_ts"]),
                    deliver_input_te=int(nearest_deliver["slice_te"]),
                )
                check_deliver = self.tp.query(check_deliver_sql)
                # 只要查出结果，就说明是异常滑动，直接跳过
                if not check_deliver.empty:
                    self.logger.d("过滤异常 LAUNCHER_SLIDE_ANIMATION deliverInput")
                    continue
            except Exception as e:
                self.logger.e(f"CheckDeliverInput 失败：{e}")

            startup.deliver_ts = int(nearest_deliver["slice_ts"])
            startup.deliver_te = int(nearest_deliver["slice_te"])
            startup.deliver_data = delivers_in_range

            new_startups.append(startup)

        return new_startups

    def _get_animator_time(
        self, startup_states: list[StartupAnalyseState], end_time: int
    ):
        """获取动画器(Animator)的开始和结束时间戳"""
        if not startup_states:
            return

        for i, startup in enumerate(startup_states):
            # 1. 基础校验与时间边界计算
            if startup.deliver_te == -1 or startup.deliver_data.empty:
                startup.animator_time = (-1, -1)
                continue

            deliver_begin = int(startup.deliver_data["slice_ts"].iloc[0])
            animator_search_start = startup.deliver_ts

            next_launching_ts = end_time
            if i < len(startup_states) - 1:
                next_ts = int(startup_states[i + 1].launching_dur[0])
                if next_ts != -1 and next_ts > deliver_begin:
                    next_launching_ts = next_ts

            animator_ts, animator_te = -1, -1

            # 2. 尝试荣耀高优先级逻辑
            if self.device_brand in HonorMachines.HONOR_BRANDS:
                animator_ts, animator_te = self._get_honor_high_priority_animator(
                    animator_search_start, next_launching_ts
                )

            # 3. 统一兜底与竞品逻辑
            if animator_ts == -1 or animator_te == -1:
                animator_ts, animator_te = self._get_fallback_animator(
                    startup, animator_search_start, next_launching_ts
                )

            # 4. 最终赋值
            startup.animator_time = (animator_ts, animator_te)

    def _get_honor_high_priority_animator(self, start_time: int, end_time: int):
        """荣耀专属高优先级 Animator 查询 (PreStartAnim -> PhysicsMotion -> AnimationKey)"""
        # 优先级 1: PreStartAnim
        try:
            sql = self.sqls.pre_start_anim(start_time, end_time)
            df = self.tp.query(sql)
            if not df.empty:
                return int(df.iloc[0]["slice_ts"]), int(df.iloc[0]["slice_te"])
        except Exception as e:
            self.logger.e(f"PreStartAnim 查询失败：{e}")

        # 优先级 2: PhysicsMotion
        try:
            sql = self.sqls.physics_motion(start_time, end_time)
            df = self.tp.query(sql)
            if not df.empty:
                return int(df.iloc[0]["slice_ts"]), int(df.iloc[0]["slice_te"])
        except Exception as e:
            self.logger.e(f"PhysicsMotion 查询失败：{e}")

        # 优先级 3: AnimationKey
        try:
            sql = self.sqls.query_startup_animation_flag(start_time, end_time)
            df = self.tp.query(sql)
            if not df.empty and not is_all_none(df):
                ts, te = int(df["ts"].iloc[0]), int(df["te"].iloc[0])
                if te - ts >= 100_000_000:
                    return ts, te
        except Exception as e:
            self.logger.e(f"AnimationKey 查询失败：{e}")

        return -1, -1

    def _get_fallback_animator(
        self, startup: StartupAnalyseState, start_time: int, end_time: int
    ):
        """通用兜底与竞品 Animator 查询逻辑"""
        try:
            # 1. 通用查询
            sql = self.sqls.query_animator(
                start_time,
                end_time,
                self.sqls.start_animator_process,
                self.sqls.start_animator_name,
            )
            df = self.tp.query(sql)

            # 2. 降级查询 (Vivo)
            if df.empty and hasattr(self.sqls, "query_animator_fallback"):
                self.logger.d("带进程名未查到 animator，触发降级查询...")
                fallback_sql = self.sqls.query_animator_fallback(start_time, end_time)
                df = self.tp.query(fallback_sql)

            # 3. 过滤 100ms
            if not df.empty:
                df = df[df["slice_dur"] > 100_000_000]

            if df.empty:
                self.logger.w(f"未找到 {startup.new_package} 的通用 animator slice")
                return -1, -1

            if self.device_brand in ["Xiaomi", "Honor"]:
                return int(df.iloc[0]["slice_ts"]), int(df.iloc[0]["slice_te"])

            else:
                # 竞品合并逻辑
                temp_ts, temp_te = (
                    int(df.iloc[0]["slice_ts"]),
                    int(df.iloc[0]["slice_te"]),
                )
                for _, row in df.iterrows():
                    row_ts, row_te = int(row["slice_ts"]), int(row["slice_te"])
                    if row_ts > temp_te:
                        temp_ts, temp_te = row_ts, row_te
                    elif row_ts > temp_ts and row_te > temp_te:
                        temp_te = row_te
                return temp_ts, temp_te

        except Exception as e:
            self.logger.e(f"通用 animator 查询失败：{e}")
            return -1, -1

    def _correct_iq_input(
        self, startup_states: list[StartupAnalyseState]
    ) -> list[StartupAnalyseState]:
        """
        如果 deliver 晚于动画开始，则修正为动画开始前最近一次 deliver。
        """
        new_list: list[StartupAnalyseState] = []
        for startup in startup_states:
            anim_ts = startup.animator_time[0]
            if anim_ts == -1 or startup.deliver_te == -1 or startup.deliver_data.empty:
                continue

            if startup.deliver_te >= anim_ts:
                delivers_before_anim = startup.deliver_data.loc[
                    startup.deliver_data["slice_ts"] < anim_ts
                ]
                if not delivers_before_anim.empty:
                    startup.deliver_te = int(delivers_before_anim.iloc[-1]["slice_te"])
                    startup.deliver_ts = int(delivers_before_anim.iloc[-1]["slice_ts"])
                    new_list.append(startup)
            else:
                new_list.append(startup)

        return new_list

    def _get_launcher_view_frames(
        self,
        startup_states: list[StartupAnalyseState],
        from_app_upid: int,
        start_time: int,
        end_time: int,
    ):
        """获取launcher绘制的动画帧的信息"""

        # 新建应用进程的actual timeline的表以及对应的sf进程的actual timeline的表
        try:
            self.table_handler.table_launcher_actual_timelines(
                from_app_upid, start_time, end_time
            )
            self.table_handler.table_sf_actual_timelines()
        except Exception as e:
            self.logger.e(f"建立联系actual timeline的表失败：{e}")
            return

        for startup in startup_states:
            animator_ts, animator_te = startup.animator_time

            if animator_ts == -1 or animator_te == -1:
                continue

            # 获取动画帧率
            if startup.animator_fps == -1:
                animator_fps = self._get_fps(animator_ts, animator_te)
                startup.animator_fps = animator_fps

            try:
                range_sql = self.sqls.query_range_timelines(
                    start_time=animator_ts, end_time=animator_te
                )
                startup_timelines = self.tp.query(range_sql)

                if startup_timelines.empty:
                    self.logger.w(
                        f"该次 {startup.new_package} 的 actual timelines 为空"
                    )
                    continue
            except Exception as e:
                self.logger.e(f"获取 {startup.new_package} actual timelines 失败：{e}")
                continue

            # 1. 算响应时延
            if startup.deliver_ts != -1:
                first_sf_ts = startup_timelines.iloc[0]["sf_te"]
                startup.response_time = int((first_sf_ts - startup.deliver_ts) / 1e6)

            # 2. 算帧间隔 (矢量化计算，丢弃无效的 NaN，过滤重复帧)
            startup_timelines["sf_te"] = startup_timelines["sf_te"].astype(float)
            startup_timelines["diff"] = startup_timelines["sf_te"].diff() / 1_000_000
            startup_timelines = startup_timelines.dropna(subset=["diff"])
            startup_timelines = startup_timelines.loc[startup_timelines["diff"] > 0]

            startup.animation_frames = startup_timelines["diff"].round(2).tolist()

    def _get_transaction_frames(
        self, startup_states: list[StartupAnalyseState], start_time: int, end_time: int
    ):
        """获取动效引擎的绘制帧信息
        荣耀机型查询 surfaceflinger 的 transition-leash 图层
        竞品机型可能没有 transition-leash，会返回空，不影响主流程
        """

        if not startup_states:
            return

        transaction_sql = self.sqls.quick_transaction(
            start_time=start_time, end_time=end_time
        )

        try:
            transaction_data = self.tp.query(transaction_sql).copy()
        except Exception as e:
            self.logger.d(f"transaction 查询失败：{e}")
            return

        if transaction_data.empty:
            self.logger.w("transaction is empty")
            return

        transaction_data[["apply_ts", "apply_te"]] = transaction_data[
            ["apply_ts", "apply_te"]
        ].astype(float)

        for startup in startup_states:
            animator_ts, animator_te = startup.animator_time
            if animator_ts == -1 or animator_te == -1:
                continue

            # 获取动画帧率
            if startup.animator_fps == -1:
                animator_fps = self._get_fps(animator_ts, animator_te)
                startup.animator_fps = animator_fps

            try:
                mask = (transaction_data["apply_ts"] >= animator_ts) & (
                    transaction_data["apply_te"] <= animator_te
                )
                startup_transaction = transaction_data.loc[mask].copy()

                if startup_transaction.empty:
                    self.logger.w(f"{startup.new_package} transaction is empty")
                    continue
            except Exception as e:
                self.logger.e(f"{startup.new_package} transaction failed: {e}")
                continue

            try:
                startup_transaction["diff"] = (
                    startup_transaction["apply_te"].diff() / 1_000_000
                )
                startup_transaction = startup_transaction.dropna(subset=["diff"])
                startup_transaction = startup_transaction.loc[
                    startup_transaction["diff"] > 0
                ]

                frames = startup_transaction["diff"].round(2).tolist()
                startup.transaction_frames = frames
            except Exception as e:
                self.logger.e(f"match sf_frames failed: {e}")
                continue

    def _get_startup_spend(self, startup_states: list[StartupAnalyseState]):
        """获取启动耗时"""

        for i, startup in enumerate(startup_states):
            launching_dur = startup.launching_dur

            if not launching_dur:
                continue

            if launching_dur[0] == -1 or launching_dur[1] == -1:
                continue

            launching_ts = startup.launching_dur[0]
            launching_te = startup.launching_dur[1]

            startup.spend_time = int((launching_te - launching_ts) / 1e6)

        # 获取启动耗时期间的线程状态
        self._get_thread_states(startup_states)

    def _get_thread_states(self, startup_states: list[StartupAnalyseState]):
        """
        获取线程在启动过程中的状态。
        按新版 Perfetto 逻辑通过 startup_id 关联 android_startup_processes、
        android_startup_threads 和 thread_state_extended，再基于 SPAN_JOIN 结果聚合。
        """
        if not startup_states:
            return

        try:
            self.table_handler.table_launch_thread_state_io_wait_dur_sum()
        except Exception as e:
            self.logger.e(f"创建 startup thread_state 表失败: {e}")
            return

        for startup in startup_states:
            if startup.startup_id == -1:
                startup.thread_states = {}
                continue

            try:
                thread_state_dict = self.state_query.startup_thread_state_by_startup_id(
                    startup.startup_id
                )
            except Exception as e:
                self.logger.e(
                    f"获取 startup_id={startup.startup_id} thread_state 失败: {e}"
                )
                startup.thread_states = {}
                continue

            startup.thread_states = thread_state_dict

    def _get_fps(self, start_time: int, end_time: int) -> int:
        """
        根据vsync-sf推荐动画范围内的帧率和帧间隔
        """
        vsync_sql = self.sqls.query_vsync_sf(start_time, end_time)
        vsync_df = self.tp.query(vsync_sql)

        timestamps = vsync_df["ts"].to_numpy(dtype="int64")
        durations = np.diff(timestamps) / 1e6  # ns -> ms

        # 3. 预定义分级阈值
        FPS_BINS = [
            (175, 185),
            (150, 165),
            (130, 144),
            (100, 120),
            (70, 90),
            (44, 60),
            (0, 30),
        ]

        # 4. 快速分箱统计
        hist = np.zeros(len(FPS_BINS), dtype=int)
        fps_values = 1000 / durations

        for i, (lower, _) in enumerate(FPS_BINS):
            if i == 0:
                mask = fps_values >= lower
            else:
                prev_lower = FPS_BINS[i - 1][0]
                mask = (fps_values >= lower) & (fps_values < prev_lower)
            hist[i] = np.sum(mask)

        # 5. 快速确定主频段
        dominant_idx = np.argmax(hist)
        target_fps = FPS_BINS[dominant_idx][1]
        return target_fps
