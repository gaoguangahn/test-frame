"""
应用退出动效分析模块

功能说明:
- 测量应用退出过程的launcher动效卡顿和动效引擎卡顿
- 支持时间段多次应用退出场景分析

版本: v1.2.0
"""

import numpy as np
import pandas as pd

from metric_parser.trace.base.base_analyser import BaseTraceAnalyse
from metric_parser.trace.base.constants import HonorMachines
from metric_parser.trace.base.registry import AnalyseRegistry
from metric_parser.trace.base.sqls import SqlFactory
from metric_parser.trace.models.app_exit_data import (
    AppExitData,
    ExitAnimationResult,
)
from metric_parser.trace.parsers.utils.util import is_all_none


@AnalyseRegistry.register("exit_animation")
class ExitAnimation(BaseTraceAnalyse):
    """获取应用退出动画卡顿的指标"""

    def __init__(self, context):
        super().__init__(context)
        self.sqls = SqlFactory.get_sql_class(self.device_brand)

    def analyse(self, start=None, end=None, **kwargs):
        """解析应用退出动画，统一的对外分析接口"""

        try:
            exits = self._analyse_internal(start, end)
        except Exception as e:
            self.logger.e(f"应用退出动效分析失败: {e}")
            return self.fail(f"应用退出动效分析失败: {e}")

        # 组装强类型返回结果
        results: list[ExitAnimationResult] = []
        for exit_slice in exits:
            if not exit_slice.animation_frames:
                continue

            results.append(
                ExitAnimationResult(
                    name=exit_slice.name,
                    op_start=start if start else exit_slice.launching_time[0],
                    animator_time=round(
                        (exit_slice.animator_time[1] - exit_slice.animator_time[0])
                        / 1_000_000,
                        2,
                    ),
                    animator_fps=exit_slice.animator_fps,
                    animation_frames=exit_slice.animation_frames,
                    transaction_frames=exit_slice.transaction_frames,
                )
            )

        return self.success(results)

    def _analyse_internal(
        self,
        start_time: int | None = None,
        end_time: int | None = None,
    ) -> list[AppExitData]:
        """执行公共步骤，返回状态列表"""

        exits: list[AppExitData] = []

        # 解析/校验时间范围
        actual_start_time, actual_end_time = self._validate_time_range(
            start_time, end_time
        )
        if actual_start_time is None or actual_end_time is None:
            self.logger.e("获取trace检测时间段失败")
            raise ValueError("获取trace检测时间段失败")

        # 1) 获取应用退出到桌面退出次数
        self._get_launching_desktop(
            exits, start_time=actual_start_time, end_time=actual_end_time
        )

        # 2) 获取锁屏解锁到桌面的次数
        self._get_unlock(exits, start_time=actual_start_time, end_time=actual_end_time)

        if len(exits) == 0:
            self.logger.e("没有识别到应用退出")
            return exits

        # 3) 获取动画起止时间戳
        self._get_animator_time(
            exits, start_time=actual_start_time, end_time=actual_end_time
        )

        # 4) 获取launcher帧间隔
        self._get_launcher_view_frames(
            exits, start_time=actual_start_time, end_time=actual_end_time
        )

        # 5) 获取动效引擎帧间隔
        if self.device_brand in HonorMachines.HONOR_BRANDS:
            self._get_transaction_frames(
                exits, start_time=actual_start_time, end_time=actual_end_time
            )

        return exits

    def _get_launching_desktop(
        self, exits: list[AppExitData], start_time: int, end_time: int
    ):
        """获取launching: launcher的事件"""
        try:
            self.table_handler.view_android_startups()
        except Exception as e:
            self.logger.e(f"创建 android_startups 表失败：{e}")
            return

        sql = self.sqls.query_exit_desktop(start_time=start_time, end_time=end_time)
        df_exit = self.tp.query(sql)

        if df_exit.empty:
            return

        # 填充默认值
        df_exit = df_exit.fillna(
            {
                "package": "unknown",
                "ts": -1,
                "ts_end": -1,
                "dur": -1,
                "upid": -1,
                "pid": -1,
                "startup_type": "unknown",
            }
        )

        for _, row in df_exit.iterrows():
            pkg_name = row["package"]
            upid = row.get("upid", -1)
            if pd.isna(upid):
                upid = -1
            else:
                upid = int(upid)

            exits.append(
                AppExitData(
                    name=pkg_name,
                    upid=upid,
                    launching_time=(row["ts"], row["ts_end"]),
                    type="launching",
                )
            )

    def _get_unlock(self, exits: list[AppExitData], start_time: int, end_time: int):
        """获取解锁到桌面的退出次数（仅荣耀设备支持）"""
        try:
            unlock_sql = self.sqls.query_unlock_animation_flag(
                start_time=start_time, end_time=end_time
            )
            unlock_data = self.tp.query(unlock_sql)
        except Exception:
            # 竞品设备无解锁动画打点，跳过
            return

        if unlock_data.empty:
            return

        # 单独获取桌面的upid
        launcher_upid_sql = self.sqls.query_process_upid(
            process_name=self.sqls.launcher_process
        )
        upid_data = self.tp.query(launcher_upid_sql)
        launcher_upid = int(upid_data.iloc[0]["upid"]) if not upid_data.empty else -1

        pairs = []
        temp_begin = None
        for row in unlock_data.itertuples(index=False):
            name = str(row.name)
            if name.startswith("BeginFluencyDetect"):
                temp_begin = row
            elif name.startswith("EndFluencyDetect") and temp_begin:
                pairs.append((temp_begin, row))
                temp_begin = None  # 重置，等待下一个 begin

        for begin, end in pairs:
            exits.append(
                AppExitData(
                    name="unlock",
                    upid=launcher_upid,
                    launching_time=(int(begin.ts), int(end.te)),
                    type="unlock",
                )
            )

    def _query_animator(self, start_time, end_time, process_name):
        """查询并过滤 animator 数据（退出场景使用 query_exit_animator）"""
        try:
            animator_sql = self.sqls.query_exit_animator(
                start_time=start_time, end_time=end_time, process_name=process_name
            )
            data = self.tp.query(animator_sql)
            if len(data) > 0 and not is_all_none(data):
                data = data.loc[
                    data["slice_dur"].notnull() & (data["slice_dur"] > 100000000)
                ]
            return data
        except Exception as e:
            self.logger.e(f"查询退出动画时间SQL失败：{e}")
            return None

    def _get_animator_time(
        self, exits: list[AppExitData], start_time: int, end_time: int
    ):
        """获取动画器(Animator)的开始和结束时间戳"""
        if len(exits) == 0:
            return

        for i, exit_slice in enumerate(exits):
            if exit_slice.launching_time == (-1, -1):
                continue
            if exit_slice.type == "unlock":
                exit_slice.animator_time = exit_slice.launching_time
                continue

            # 1. 确定时间边界
            pre_launching_te = exits[i - 1].launching_time[1] if i > 0 else start_time
            next_exit_ts = (
                exits[i + 1].launching_time[0] if i < len(exits) - 1 else end_time
            )
            if next_exit_ts == -1:
                next_exit_ts = end_time

            animator_ts, animator_te = -1, -1

            # 2. 荣耀专属：FluencyDetect 打点
            if self.device_brand in HonorMachines.HONOR_BRANDS:
                try:
                    sql = self.sqls.query_exit_animation_flag(
                        pre_launching_te, next_exit_ts
                    )
                    df = self.tp.query(sql)
                    if not df.empty and not is_all_none(df):
                        ts, te = int(df["ts"].iloc[0]), int(df["te"].iloc[0])
                        if te - ts >= 100_000_000:
                            animator_ts, animator_te = ts, te
                except Exception as e:
                    self.logger.d(f"FluencyDetect 查询失败：{e}")

            # 3. 通用兜底与竞品逻辑
            if animator_ts == -1 or animator_te == -1:
                animator_ts, animator_te = self._get_exit_fallback_animator(
                    exit_slice.launching_time[0], exit_slice.launching_time[1]
                )

            # 4. 最终赋值
            exit_slice.animator_time = (animator_ts, animator_te)

    def _get_exit_fallback_animator(self, start_time: int, end_time: int):
        """退出场景的通用兜底与竞品 Animator 查询逻辑"""
        try:
            sql = self.sqls.query_animator(
                start_time,
                end_time,
                self.sqls.exit_animator_process,
                self.sqls.exit_animator_name,
            )
            df = self.tp.query(sql)

            if not df.empty:
                df = df[df["slice_dur"] > 100_000_000]

            if df.empty:
                return -1, -1

            if self.device_brand in ["Xiaomi", "Honor"]:
                return int(df.iloc[0]["slice_ts"]), int(df.iloc[0]["slice_te"])
            else:
                temp_ts, temp_te = (
                    int(df.iloc[0]["slice_ts"]),
                    int(df.iloc[0]["slice_te"]),
                )
                for _, row in df.iterrows():
                    row_ts, row_te = int(row["slice_ts"]), int(row["slice_te"])
                    if row_ts > temp_te:
                        temp_ts, temp_te = row_ts, row_te
                    elif row_ts > temp_ts and row_te > temp_te:
                        temp_te = row_te
                return temp_ts, temp_te

        except Exception as e:
            self.logger.e(f"退出通用 animator 查询失败：{e}")
            return -1, -1

    def _get_launcher_view_frames(
        self, exits: list[AppExitData], start_time: int, end_time: int
    ):
        """获取launcher绘制的动画帧的信息"""
        if len(exits) == 0:
            return

        launcher_upid = -1
        for exit_slice in exits:
            if exit_slice.upid != -1:
                launcher_upid = exit_slice.upid
                break

        if launcher_upid == -1:
            self.logger.e("未获取 launcher upid")
            return

        try:
            self.table_handler.table_launcher_actual_timelines(
                launcher_upid, start_time, end_time
            )
            self.table_handler.table_sf_actual_timelines()
        except Exception as e:
            self.logger.e(f"建立launcher实际timeline表失败：{e}")
            return

        for exit_slice in exits:
            animator_ts, animator_te = exit_slice.animator_time
            if animator_ts == -1 or animator_te == -1:
                continue

            if exit_slice.animator_fps == -1:
                animator_fps = self._get_fps(animator_ts, animator_te)
                exit_slice.animator_fps = animator_fps

            try:
                range_sql = self.sqls.query_range_timelines(
                    start_time=animator_ts, end_time=animator_te
                )
                exit_timelines = self.tp.query(range_sql)

                if exit_timelines.empty:
                    self.logger.w(
                        f"该次 {exit_slice.name} 的 actual timelines is empty"
                    )
                    continue
            except Exception as e:
                self.logger.e(f"获取 {exit_slice.name} actual timelines 失败：{e}")
                continue
            try:
                exit_timelines["sf_te"] = exit_timelines["sf_te"].astype(float)
                exit_timelines["diff"] = exit_timelines["sf_te"].diff() / 1_000_000
                exit_timelines = exit_timelines.dropna(subset=["diff"])
                exit_timelines = exit_timelines.loc[exit_timelines["diff"] > 0]

                exit_slice.animation_frames = exit_timelines["diff"].round(2).tolist()
            except Exception as e:
                self.logger.e(f"diff calculation failed: {e}")

    def _get_transaction_frames(
        self, exits: list[AppExitData], start_time: int, end_time: int
    ):
        """获取动效引擎帧间隔"""
        try:
            transaction_sql = self.sqls.quick_transaction(
                start_time=start_time, end_time=end_time
            )
            transaction_data = self.tp.query(transaction_sql)
        except Exception as e:
            self.logger.d(f"transaction 查询失败：{e}")
            return

        if transaction_data.empty:
            self.logger.w("查询动效引擎 transaction 为空")
            return

        transaction_data[["apply_ts", "apply_te"]] = transaction_data[
            ["apply_ts", "apply_te"]
        ].astype(float)

        for exit_slice in exits:
            animator_ts, animator_te = exit_slice.animator_time
            if animator_ts == -1 or animator_te == -1:
                continue

            # 获取动画帧率
            if exit_slice.animator_fps == -1:
                animator_fps = self._get_fps(animator_ts, animator_te)
                exit_slice.animator_fps = animator_fps

            try:
                mask = (transaction_data["apply_ts"] >= animator_ts) & (
                    transaction_data["apply_te"] <= animator_te
                )
                exit_transaction = transaction_data.loc[mask].copy()

                if exit_transaction.empty:
                    self.logger.w(f"{exit_slice.name} 查询动效引擎 transaction 为空")
                    continue
            except Exception as e:
                self.logger.e(f"{exit_slice.name} 查询动效引擎 transaction 失败: {e}")
                continue

            try:
                exit_transaction["diff"] = (
                    exit_transaction["apply_te"].diff() / 1_000_000
                )
                exit_transaction = exit_transaction.dropna(subset=["diff"])
                exit_transaction = exit_transaction.loc[exit_transaction["diff"] > 0]
                frames = exit_transaction["diff"].round(2).tolist()
                exit_slice.transaction_frames = frames
            except Exception as e:
                self.logger.e(f"查询动效引擎匹配 sf_frames 失败: {e}")
                continue

    def _get_fps(self, start_time, end_time):
        """根据vsync-sf推荐动画范围内的帧率和帧间隔"""
        vsync_sql = self.sqls.query_vsync_sf(start_time, end_time)
        vsync_df = self.tp.query(vsync_sql)

        timestamps = vsync_df["ts"].to_numpy(dtype="int64")
        durations = np.diff(timestamps) / 1e6  # ns -> ms

        # 3. 预定义分级阈值
        FPS_BINS = [
            (175, 185),
            (150, 165),
            (130, 144),
            (100, 120),
            (70, 90),
            (44, 60),
            (0, 30),
        ]

        # 4. 快速分箱统计
        hist = np.zeros(len(FPS_BINS), dtype=int)
        fps_values = 1000 / durations

        for i, (lower, _) in enumerate(FPS_BINS):
            if i == 0:
                mask = fps_values >= lower
            else:
                prev_lower = FPS_BINS[i - 1][0]
                mask = (fps_values >= lower) & (fps_values < prev_lower)
            hist[i] = np.sum(mask)

        # 5. 快速确定主频段
        dominant_idx = np.argmax(hist)
        target_fps = FPS_BINS[dominant_idx][1]
        return target_fps
