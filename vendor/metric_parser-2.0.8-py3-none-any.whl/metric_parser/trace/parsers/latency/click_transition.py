﻿"""
应用内点击延迟分析模块

功能说明:
- 测量从触摸事件到UI响应的完整处理链路耗时
- 支持时间段单次点击场景分析

版本: v1.1.0
"""

from pathlib import Path

import pandas as pd
import yaml

from metric_parser.trace.base.base_analyser import BaseTraceAnalyse
from metric_parser.trace.base.constants import HonorMachines
from metric_parser.trace.base.registry import AnalyseRegistry
from metric_parser.trace.base.sqls import SqlFactory
from metric_parser.trace.models.click_transition_data import (
    ClickTransitionData,
    ClickTransitionResult,
)
from metric_parser.trace.parsers.utils.thread_state import StateQuery
from metric_parser.trace.parsers.utils.util import is_all_none


@AnalyseRegistry.register("click_transition")
class ClickTransition(BaseTraceAnalyse):
    """获取应用内转场时间"""

    def __init__(self, context):
        super().__init__(context)
        self.state_query = StateQuery(self.tp)
        self.sqls = SqlFactory.get_sql_class(self.device_brand)

        # 加载白名单
        config_path = (
            Path(__file__).resolve().parent.parent.parent
            / "configs"
            / "click_whitelist.yaml"
        )

        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}
            self.white_list = config.get("white_list", [])
        except Exception as e:
            self.logger.w(f"加载白名单失败: {e}")
            self.white_list = []

    def analyse(self, start=None, end=None, **kwargs):
        """统一的对外分析接口，返回应用内点击的相关信息"""

        try:
            transitions = self._analyse_internal(start, end)
        except Exception as e:
            self.logger.e(f"应用内点击分析失败: {e}")
            return self.fail(f"应用内点击分析失败: {e}")

        results: list[ClickTransitionResult] = []
        for transition in transitions:
            if transition.transition_time < 0:
                continue

            results.append(
                ClickTransitionResult(
                    new_activity=transition.new_activity,
                    new_process=transition.new_process or "unknown",
                    op_start=start if start else transition.deliver_ts,
                    startup_type=transition.startup_type or "unknown",
                    launching_dur=round(
                        (transition.launching_te - transition.launching_ts) / 1e6, 2
                    ),
                    response_time=transition.transition_time,
                    wmshell=transition.wmshell,
                    thread_state=transition.thread_state,
                )
            )

        return self.success(results)

    def _analyse_internal(
        self, start_time: int | None, end_time: int | None
    ) -> list[ClickTransitionData]:
        """获取应用内点击响应的相关metric"""

        # 解析/校验时间范围（使用父类统一逻辑）
        actual_start_time, actual_end_time = self._validate_time_range(
            start_time, end_time
        )
        if actual_start_time is None or actual_end_time is None:
            raise ValueError("获取trace检测时间段失败")

        # 1) 识别 activity 启动
        transitions = self._get_launching_activity(
            start_time=actual_start_time, end_time=actual_end_time
        )

        if not transitions:
            self.logger.w("未找到Activity跳转")
            return []

        # 2) 获取 deliverInputEvent
        self._get_deliver_input(transitions, start_time=actual_start_time)

        # 3) 计算转场时间与线程状态
        try:
            self.table_handler.table_launch_thread_state_io_wait_dur_sum()
        except Exception as e:
            self.logger.e(f"创建 startup thread_state 表失败: {e}")

        for transition in transitions:
            launching_dur = (transition.launching_te - transition.launching_ts) / 1e6
            final_dur = launching_dur
            calc_start_ts = transition.launching_ts
            calc_end_ts = transition.launching_te
            use_startup_id_thread_state = True

            # 仅荣耀机型 且 在白名单中的应用，执行 wmshell 首帧修正逻辑
            if (
                self.device_brand in HonorMachines.HONOR_BRANDS
                and transition.new_process in self.white_list
            ):
                self._get_wmshell_first_time(transition, end_time=actual_end_time)

                if transition.wmframe_sf_te > transition.deliver_ts:
                    wmframe_dur = (
                        transition.wmframe_sf_te - transition.deliver_ts
                    ) / 1e6
                    if wmframe_dur < launching_dur:
                        final_dur = wmframe_dur
                        calc_start_ts = transition.deliver_ts
                        calc_end_ts = transition.wmframe_sf_te
                        use_startup_id_thread_state = False
                        transition.wmshell = True

            # 所有机型通用的赋值
            transition.transition_time = int(final_dur)
            transition.thread_state = self._get_thread_states(
                transition=transition,
                start_ts=calc_start_ts,
                end_ts=calc_end_ts,
                use_startup_id=use_startup_id_thread_state,
            )

        return transitions

    def _get_launching_activity(
        self, start_time: int, end_time: int
    ) -> list[ClickTransitionData]:
        """
        判断本次点击有没有启动新的 activity，并尽量确定主进程。
        复用新版 startup 表：android_startups 记录 Activity 启动/切换，
        android_startup_processes 按 activityResume > 0 确认目标 upid/startup_type。
        """

        transitions: list[ClickTransitionData] = []

        try:
            self.table_handler.view_android_startups()
        except Exception as e:
            self.logger.e(f"构建 android_startups 失败: {e}")
            return transitions

        sql = self.sqls.query_activity_transitions(
            start_time=start_time, end_time=end_time
        )
        activity_start_df = self.tp.query(sql)

        if activity_start_df.empty:
            self.logger.d("没有识别到activity启动")
            return transitions

        for _, activity in activity_start_df.iterrows():
            # 记录启动/切换时间
            startup_id = activity.get("startup_id", -1)
            launching_ts = int(activity["ts"])
            launching_te = int(activity["ts_end"])
            package = activity.get("package")
            startup_type = activity.get("startup_type")
            new_upid = activity.get("upid", -1)
            new_pid = activity.get("pid", -1)

            if pd.isna(startup_id):
                startup_id = -1
            else:
                startup_id = int(startup_id)

            if pd.isna(new_upid) or int(new_upid) == -1:
                self.logger.d(
                    f"startup_id={startup_id}, package={package} 未匹配到目标 upid，跳过"
                )
                continue
            new_upid = int(new_upid)

            if pd.isna(new_pid):
                new_pid = -1
            else:
                new_pid = int(new_pid)

            if not package:
                self.logger.w("无法确定进程名，终止解析")
                continue

            # performResume 只用于定位 Activity 名称/utid，进程由 android_startup_processes 确认。
            perform_resume_sql = self.sqls.query_click_activity_resume_by_upid(
                start_time=launching_ts, end_time=launching_te, upid=new_upid
            )

            resume_df = self.tp.query(perform_resume_sql)
            if resume_df.empty:
                self.logger.w(
                    f"startup_id={startup_id}, upid={new_upid} 未识别到 performResume，跳过"
                )
                continue

            # 取第一条，保持和历史逻辑一致
            first_resume = resume_df.iloc[0]
            new_utid = first_resume.get("utid", -1)
            resume_ts = first_resume.get("slice_ts", -1)
            resume_te = first_resume.get("slice_te", -1)
            resume_name = first_resume["slice_name"]

            # 形如 "performResume:com.xxx.Activity"
            if isinstance(resume_name, str) and ":" in resume_name:
                new_activity = resume_name.split(":", 1)[1]
            else:
                new_activity = resume_name or ""
            new_process = first_resume.get("process_name", None)

            transitions.append(
                ClickTransitionData(
                    name=resume_name,
                    startup_id=startup_id,
                    startup_type=startup_type,
                    new_process=new_process,
                    new_utid=int(new_utid) if not pd.isna(new_utid) else -1,
                    new_upid=new_upid,
                    new_pid=new_pid,
                    launching_ts=launching_ts,
                    launching_te=launching_te,
                    resume_ts=resume_ts,
                    resume_te=resume_te,
                    new_activity=new_activity,
                )
            )

        return transitions

    def _get_deliver_input(
        self, transitions: list[ClickTransitionData], start_time: int
    ):
        """获取输入事件的时间戳（deliverInputEvent）"""

        for transition in transitions:
            if transition.resume_ts == -1 or transition.new_process is None:
                continue

            start_ts = start_time
            end_ts = transition.launching_ts

            deliver_sql = self.sqls.query_all_deliver(
                start_time=start_ts, end_time=end_ts
            )
            deliver_data = self.tp.query(deliver_sql)
            if deliver_data.empty:
                self.logger.w("没有找到 deliverInputEvent")
                return

            # 使用最后一条作为最近的点击
            transition.deliver_ts = int(deliver_data.iloc[-1]["slice_ts"])
            transition.deliver_te = int(deliver_data.iloc[-1]["slice_te"])

        return

    def _get_wmshell_first_time(self, transition: ClickTransitionData, end_time: int):
        """白名单内的应用，首帧时间用 wmshell 的 doframe"""
        if not transition.new_process or transition.deliver_te == -1:
            return

        first_doframe_sql = self.sqls.query_thread_first_frame(
            thread_name=self.sqls.wmshell_anim,
            start_time=transition.deliver_te,
            end_time=end_time,
        )
        first_doframe_data = self.tp.query(first_doframe_sql)

        if first_doframe_data.empty or is_all_none(first_doframe_data):
            self.logger.w("未找到wmshell.anim的非-1 doframe")
            return

        target_frame = first_doframe_data.iloc[0]
        doframe_name = target_frame["doframe_name"]
        doframe_id = doframe_name.split(" ")[-1]

        if int(doframe_id) == -1:
            return

        match_timeline_sql = self.sqls.query_same_name_timeline(
            frame_id=doframe_id, start_time=transition.deliver_te, end_time=end_time
        )
        match_timeline_data = self.tp.query(match_timeline_sql)

        if match_timeline_data.empty or is_all_none(match_timeline_data):
            self.logger.w("未找到wmshell.anim的对应timeline")
            return

        timeline_id = match_timeline_data.iloc[0]["id"]
        sf_map_sql = self.sqls.frame_token_map(slice_id=timeline_id)
        sf_map_data = self.tp.query(sf_map_sql)

        if sf_map_data.empty or is_all_none(sf_map_data):
            self.logger.w("未找到wmshell.anim的对应sf timeline")
            return

        target_df = sf_map_data.iloc[0]
        transition.wmframe_sf_ts = target_df["UISliceStartTs"]
        transition.wmframe_sf_te = target_df["UISliceEndTs"]

    def _get_thread_states(
        self,
        transition: ClickTransitionData,
        start_ts: int,
        end_ts: int,
        use_startup_id: bool = True,
    ):
        """
        获取线程在转场过程中的状态。
        非白名单默认使用 startup_id 对齐新版 Perfetto startup 线程状态口径；
        白名单发生 wmshell 首帧修正后，使用 new_upid + 自定义区间。
        """

        if use_startup_id and transition.startup_id != -1:
            try:
                return self.state_query.startup_thread_state_by_startup_id(
                    transition.startup_id
                )
            except Exception as e:
                self.logger.e(
                    f"获取 startup_id={transition.startup_id} thread_state 失败: {e}",
                )

        upid = transition.new_upid
        if upid == -1:
            return {}

        try:
            return self.state_query.startup_thread_state(upid, start_ts, end_ts)
        except Exception as e:
            self.logger.e(
                f"获取线程状态失败 upid={upid}, start={start_ts}, end={end_ts}: {e}",
            )
            return {}

    @staticmethod
    def normalize_pkg(p: str) -> str:
        if not isinstance(p, str) or not p:
            return ""
        # 去除首尾空格与引号，过滤子进程名（":xxx"）
        p = p.strip().strip('"').strip("'")
        if ":" in p:
            # 只取主进程前缀
            p = p.split(":", 1)[0]
        return p


