"""
线程状态分析模块

功能说明:
- 测量时间段内的线程状态分布

版本: v1.1.0
"""

from metric_parser.trace.base.trace_processor_handler import TraceProcessorHandler


class StateQuery:
    def __init__(self, tp: TraceProcessorHandler):
        self.tp = tp

    @staticmethod
    def _build_main_thread_state_result(df_state):
        """将 thread_state 聚合结果转换为对外统一字段。"""

        def safe_sum(df, cond):
            return int(df.loc[cond, "total_dur"].sum() or 0)

        return {
            "running_dur_ns": safe_sum(df_state, df_state["state"] == "Running"),
            "runnable_dur_ns": safe_sum(
                df_state, (df_state["state"] == "R") | (df_state["state"] == "R+")
            ),
            "uninterruptible_sleep_dur_ns": safe_sum(
                df_state, df_state["state"] == "D"
            ),
            "interruptible_sleep_dur_ns": safe_sum(df_state, df_state["state"] == "S"),
            "uninterruptible_io_sleep_dur_ns": safe_sum(
                df_state, (df_state["state"] == "D") & (df_state["io_wait"] == 1)
            ),
            "uninterruptible_non_io_sleep_dur_ns": safe_sum(
                df_state, (df_state["state"] == "D") & (df_state["io_wait"] == 0)
            ),
        }

    def startup_thread_state(self, upid, start_ts, end_ts):
        """
        获取指定进程upid在应用启动间隔时，线程的状态转换情况。
        :param upid: 进程upid
        :param start_ts: 开始时间
        :param end_ts: 结束时间
        """
        sql = f"""
            SELECT
              ts.ts as ts,
              SUM(
               CASE
                 WHEN dur=-1 THEN
                   MIN(trace_end(), {end_ts}) - MAX(ts.ts, {start_ts})
                 ELSE
                   MIN(ts.ts + ts.dur, {end_ts}) - MAX(ts.ts, {start_ts})
               END
              ) as total_dur,
              ts.state as state,
              ts.io_wait as io_wait
            FROM thread_state AS ts
            JOIN thread ON thread.utid = ts.utid
            WHERE thread.upid = {upid}
              AND is_main_thread
              AND ts.ts <= {end_ts}
              AND (
                (ts.dur != -1 AND ts.ts + ts.dur >= {start_ts})
                OR (ts.dur = -1)
              )
            GROUP BY ts.state, ts.io_wait;
        """
        df_state = self.tp.query(sql)
        return self._build_main_thread_state_result(df_state)

    def startup_thread_state_by_startup_id(self, startup_id: int):
        """
        按新版 Perfetto startup 线程状态链路获取 main_thread_by_task_state。

        依赖调用方预先创建 launch_thread_state_io_wait_dur_sum，链路为：
        android_startup_processes -> android_startup_threads ->
        SPAN_JOIN(android_startup_threads, thread_state_extended) ->
        launch_thread_state_io_wait_dur_sum。
        :param startup_id: android_startups.startup_id
        """
        sql = f"""
            SELECT
              state,
              io_wait,
              SUM(dur) AS total_dur
            FROM launch_thread_state_io_wait_dur_sum
            WHERE startup_id = {startup_id}
              AND is_main_thread
            GROUP BY state, io_wait;
        """
        df_state = self.tp.query(sql)
        return self._build_main_thread_state_result(df_state)
