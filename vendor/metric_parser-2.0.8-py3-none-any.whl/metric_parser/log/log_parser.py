import metric_parser.log.parsers  # 触发注册表
from metric_parser.log.base.context import LogContext
from metric_parser.log.base.registry import AnalyseRegistry
from metric_parser.log.base.result import AnalyseResult
from metric_parser.utils.logger import ParseLogger


class LogParser:
    """
    Log 解析统一入口 (完全对齐 TraceParser)
    """

    def __init__(self, file_path: str, device_brand: str = "Honor"):
        self.logger = ParseLogger(self.__class__.__name__)
        self.file_path = file_path
        self.device_brand = device_brand
        self.context = None

    def __enter__(self):
        self.context = LogContext(self.file_path, self.device_brand)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.context = None

    def _run_analyser(self, metric_name: str, **kwargs) -> AnalyseResult:
        """私有方法：统一处理上下文检查、注册表获取和异常捕获"""
        if not self.context:
            raise RuntimeError(
                "LogParser 尚未初始化，请使用 'with LogParser(...) as parser:'"
            )

        analyser_class = AnalyseRegistry.get_analyser(metric_name)
        if not analyser_class:
            return AnalyseResult(success=False, error=f"未找到分析器: {metric_name}")

        try:
            analyser = analyser_class(self.context)
            return analyser.analyse(**kwargs)
        except Exception as e:
            self.logger.e(f"解析 {metric_name} 异常: {e}")
            return AnalyseResult(success=False, error=str(e))

    # ==========================================
    # 显式解析方法 (供业务脚本直接调用，提供 IDE 提示)
    # ==========================================

    def parse_io_measure(self, **kwargs) -> AnalyseResult:
        """解析 IO Measure 日志"""
        return self._run_analyser("io_measure", **kwargs)

    def parse_io_stat(self, **kwargs) -> AnalyseResult:
        """解析 IO Stat 采样数据"""
        return self._run_analyser("io_stat", **kwargs)

    def parse_adb_log(self, **kwargs) -> AnalyseResult:
        """解析 ADB iAware 日志"""
        return self._run_analyser("adb_log", **kwargs)

    def parse_jank_log(self, **kwargs) -> AnalyseResult:
        """解析 Jank 卡顿日志"""
        return self._run_analyser("jank_log", **kwargs)

    def parse_events_log(self, **kwargs) -> AnalyseResult:
        """解析 Event Log Activity 启动耗时"""
        return self._run_analyser("events_log", **kwargs)

    def parse_dumpsys_meminfo(self, **kwargs) -> AnalyseResult:
        """解析 dumpsys meminfo 输出，提取 Free RAM、DMA-BUF、GPU、Used RAM、ZRAM 等内存指标"""
        return self._run_analyser("dumpsys_meminfo", **kwargs)

    def parse_proc_memory(self, **kwargs) -> AnalyseResult:
        """解析 /proc/meminfo, /proc/vmstat 等系统内存指标"""
        return self._run_analyser("proc_memory", **kwargs)

    def parse_animation_jank(self, **kwargs) -> AnalyseResult:
        """解析性能雷达：动画卡顿 (ANIMATION_JANK_FRAME)"""
        return self._run_analyser("animation_jank", **kwargs)

    def parse_fling_jank(self, **kwargs) -> AnalyseResult:
        """解析性能雷达：滑动卡顿 (FLING_JANK_FRAME)"""
        return self._run_analyser("fling_jank", **kwargs)

    def parse_fluency_fling_jank(self, **kwargs) -> AnalyseResult:
        """解析性能雷达：流畅度滑动卡顿 (FLUENCY_FLING_JANK_FRAME)"""
        return self._run_analyser("fluency_fling_jank", **kwargs)


if __name__ == "__main__":
    # 测试用例
    log_file_path = r"D:\test_framework-agent\outputs\dynamic2\ABMK015B21000107\round_001\TestBaiduSearch_test_baidu_search\logs\actionstats_49.txt"
    with LogParser(log_file_path, device_brand="Honor") as parser:
        result = parser.parse_animation_jank()
        print(result)
