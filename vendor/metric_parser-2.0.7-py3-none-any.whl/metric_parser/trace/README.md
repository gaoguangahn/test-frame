# Trace Analysis

基于 Perfetto trace 的模块化性能分析框架。通过注册表模式动态调度各分析器，统一入口调用。

## 快速开始

```python
from metric_parser.trace.trace_analysis import TraceAnalysis

analyse_params = {
    "startup_transition": [
        {"from_app": "com.android.launcher", "start": 100000, "end": 500000}
    ],
    "click_response": [
        {"start": 100000, "end": 500000}
    ],
}

result, trace_length = TraceAnalysis.analysis_trace(
    trace_file_path="/path/to/trace.pftrace",
    analyse_params=analyse_params,
    device_brand="Honor"  # Honor / Xiaomi / Vivo / Oppo 等
)
```

`result` 结构：`{分析器名: [analyse() 返回值, ...]}`，每次参数调用对应列表中的一个元素。

## 可用分析器

### 启动类

#### `startup_transition` — 应用启动响应/动效分析

测量从桌面点击到应用首帧渲染的响应时间、动画帧率、线程状态等。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `from_app` | str | 否 | 发起启动的进程名，默认取 launcher |
| `start` | int | 否 | 分析起始时间戳 (ns) |
| `end` | int | 否 | 分析结束时间戳 (ns) |

返回字段：`name`, `new_activity`, `start_type`(cold/warm/hot), `response_time`(ms), `spend_time`(ms), `animator_fps`, `animation_frames`, `transaction_frames`, `thread_states`

```python
{
    "startup_transition": [
        {"from_app": "com.android.launcher", "start": 403391152632500, "end": 403398050965899}
    ]
}
```

#### `non_desk_start` — 非桌面启动分析

测量非桌面场景的启动（如相机启动相册、微信启动小程序），继承 `startup_transition` 逻辑。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `from_app` | str | **是** | 发起启动的源应用（如 `com.hihonor.camera`） |
| `start` | int | 否 | 分析起始时间戳 (ns) |
| `end` | int | 否 | 分析结束时间戳 (ns) |

```python
{
    "non_desk_start": [
        {"from_app": "com.hihonor.camera", "start": 523894651268999, "end": 523896130185999}
    ]
}
```

### 滑动类

#### `swipe_offScreen` — 离手滑动卡顿分析

测量应用内松手后的惯性滑动（fling）动效卡顿，支持 RVScroll 和 TargetBuf 两种判断策略。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `package` | str | **是** | 包名 |
| `activity` | str | **是** | Activity 名 |
| `detect_ts` | int | 否 | 检测起始时间戳 (ns) |
| `detect_te` | int | 否 | 检测结束时间戳 (ns) |

返回字段：`on_deliver_start`, `off_jank`(离手卡顿时刻/时长列表), `off_count`, `off_avg_fps`, `on_jank`(跟手卡顿), `on_count`, `on_avg_fps`

```python
{
    "swipe_offScreen": [
        {
            "package": "com.baidu.searchbox",
            "activity": "com.baidu.searchbox.MainActivity",
            "detect_ts": 403391152632500,
            "detect_te": 403398050965899
        }
    ]
}
```

#### `swipe_onScreen` — 跟手滑动卡顿分析

测量应用内手指不离屏滑动的动效卡顿。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `package` | str | **是** | 包名 |
| `activity` | str | **是** | Activity 名 |
| `start_ts` | int | **是** | 起始时间戳 (ns) |
| `end_ts` | int | **是** | 结束时间戳 (ns) |
| `vertical` | bool | 否 | 是否垂直滑动，默认 `True` |

```python
{
    "swipe_onScreen": [
        {
            "package": "com.taobao.taobao",
            "activity": "com.taobao.tao.MainActivity",
            "start_ts": 100000,
            "end_ts": 500000,
            "vertical": True
        }
    ]
}
```

### 点击延迟类

#### `click_response` — 应用内点击响应延迟

测量从触摸事件到 UI 首帧响应的完整处理链路耗时。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `start` | int | 否 | 分析起始时间戳 (ns) |
| `end` | int | 否 | 分析结束时间戳 (ns) |

返回字段：`new_activity`, `new_process`, `startup_type`(cold/warm/hot), `launching_dur`(ms), `response_time`(ms), `thread_state`

```python
{
    "click_response": [
        {"start": 100000, "end": 500000}
    ]
}
```

#### `click_transition` — 应用内点击转场时间

测量点击后新 Activity 启动的转场响应时间，支持 wmshell 首帧修正（荣耀白名单机型）。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `start` | int | 否 | 分析起始时间戳 (ns) |
| `end` | int | 否 | 分析结束时间戳 (ns) |

返回字段：`new_activity`, `new_process`, `startup_type`, `launching_dur`(ms), `response_time`(ms), `thread_state`

```python
{
    "click_transition": [
        {"start": 100000, "end": 500000}
    ]
}
```

### 动画类

#### `multi_task` — 多任务动效分析

测量进入多任务界面的动效卡顿。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `start` | int | 否 | 分析起始时间戳 (ns) |
| `end` | int | 否 | 分析结束时间戳 (ns) |

```python
{
    "multi_task": [
        {"start": 100000, "end": 500000}
    ]
}
```

#### `control_center` — 下拉控制中心/通知栏动效

测量下拉控制中心和通知栏展开的动效卡顿。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `start` | int | 否 | 分析起始时间戳 (ns) |
| `end` | int | 否 | 分析结束时间戳 (ns) |

```python
{
    "control_center": [
        {"start": 100000, "end": 500000}
    ]
}
```

#### `exit_animation` — 应用退出动画

测量应用退出的动效卡顿。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `start` | int | 否 | 分析起始时间戳 (ns) |
| `end` | int | 否 | 分析结束时间戳 (ns) |

```python
{
    "exit_animation": [
        {"start": 100000, "end": 500000}
    ]
}
```

### 场景类

#### `input_method` — 输入法弹窗动画

测量输入法弹出弹窗的动效。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `from_app` | str | 否 | 源应用名 |
| `start` | int | 否 | 分析起始时间戳 (ns) |
| `end` | int | 否 | 分析结束时间戳 (ns) |

```python
{
    "input_method": [
        {"from_app": "com.tencent.mm", "start": 100000, "end": 500000}
    ]
}
```

## 参数说明

- 所有时间戳单位为 **纳秒 (ns)**
- `start` / `end` 不传时，各分析器会使用 trace 文件的起止时间作为默认范围
- 多参数调用时，字典的 value 为列表，每个元素代表一次独立分析

```python
# 同一分析器多次执行
{
    "swipe_offScreen": [
        {"package": "pkg_a", "activity": "act_a", "detect_ts": 100, "detect_te": 200},
        {"package": "pkg_b", "activity": "act_b", "detect_ts": 300, "detect_te": 400},
    ]
}
```

## 返回结构

```python
{
    "startup_transition": [
        {"name": "com.example.app", "start_type": "cold", "response_time": 120, ...}
    ],
    "swipe_offScreen": [
        {"off_jank": [(ts1, dur1), ...], "off_count": 2, ...}
    ],
    "click_response": [
        {"new_activity": "MainActivity", "response_time": 85, ...}
    ]
}
```

每个分析器对应一个 key，value 为列表，列表长度等于传入的参数字典数量。解析失败时对应位置返回 `{"error": "错误信息"}`。
