# metric_parser/trace/core/registry.py


class AnalyseRegistry:
    """分析器注册表"""

    _registry: dict[str, type] = {}

    @classmethod
    def register(cls, metric_name: str):
        """装饰器：用于将分析器注册到全局"""

        def wrapper(analyser_class: type):
            cls._registry[metric_name] = analyser_class
            return analyser_class

        return wrapper

    @classmethod
    def get_analyser(cls, metric_name: str) -> type | None:
        return cls._registry.get(metric_name)
