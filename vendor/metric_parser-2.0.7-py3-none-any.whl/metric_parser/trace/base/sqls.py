class Common:
    launcher_process: str = "com.android.launcher3"
    system_process: str = "system_server"
    systemui_process: str = "com.android.systemui"
    sf_process: str = "/system/bin/surfaceflinger"

    animator_name: str = "animator"
    animator_type: str = "render"
    start_animator_process: str = "com.android.launcher3"

    @staticmethod
    def query_process_upid(process_name):
        """
        获取process_name对应的upid
        :param process_name: 进程名称
        """

        sql = f"""
            SELECT upid
            FROM process
            WHERE process.name = '{process_name}'
            UNION
            SELECT upid
            FROM process
            WHERE process.name LIKE '{process_name}'
            LIMIT 1;
        """
        return sql

    @classmethod
    def query_launching_slice(cls, start_time, end_time):
        """
        查询时间范围内 system_server 进程的 launching: 信息
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        sql = f"""
            SELECT 
                slice.ts AS slice_ts,
                (slice.dur + slice.ts) AS slice_te,
                slice.name AS slice_name
            FROM slice 
            JOIN process_track ON slice.track_id = process_track.id 
            JOIN process ON process_track.upid = process.upid 
            WHERE slice.name LIKE 'launching:%' 
              AND process.name = '{cls.system_process}' 
              AND slice.ts >= {start_time} 
              AND slice.ts < {end_time} 
            ORDER BY slice_ts ASC;
        """
        return sql

    @staticmethod
    def query_deliver_input(process_name, start_time, end_time):
        """
        查询时间范围内指定进程的 deliverInput 信息
        :param process_name: 进程名称
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        sql = f"""
            SELECT 
                slice.name AS slice_name, 
                slice.ts AS slice_ts, 
                slice.dur AS slice_dur, 
                (slice.dur + slice.ts) AS slice_te
            FROM slice 
            JOIN process_track ON slice.track_id = process_track.id
            JOIN process ON process_track.upid = process.upid
            WHERE slice_name = 'deliverInputEvent' 
              AND process.name = '{process_name}'
              AND slice.ts >= {start_time} 
              AND slice.ts < {end_time}
            ORDER BY slice_ts ASC;
        """
        return sql

    @staticmethod
    def query_all_deliver(start_time, end_time):
        """
        查询时间范围内的所有 deliverInput 信息
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        sql = f"""
            SELECT
                slice.name AS slice_name,
                slice.ts AS slice_ts,
                slice.dur AS slice_dur,
                (slice.dur + slice.ts) AS slice_te,
                process.name AS process_name,
                process.upid AS upid
            FROM slice
            LEFT JOIN process_track ON slice.track_id = process_track.id
            LEFT JOIN process ON process_track.upid = process.upid
            WHERE slice.name = 'deliverInputEvent'
              AND slice.ts >= {start_time}
              AND slice.ts < {end_time}
            ORDER BY slice_ts ASC;
        """
        return sql

    @staticmethod
    def query_vsync_sf(start_ts, end_ts):
        """
        查询时间范围内的vsync-sf信息
        :param start_ts: 查询的开始时间
        :param end_ts: 查询的结束时间
        """

        sql = f"""
            SELECT counter.ts, counter.value, process.name as pname, track.name 
            FROM counter 
            JOIN process_counter_track as track ON counter.track_id = track.id 
            JOIN process ON process.upid = track.upid 
            WHERE track.name = 'VSYNC-sf' 
            AND counter.ts BETWEEN {start_ts} AND {end_ts}
            ORDER BY counter.ts
        """

        return sql

    @staticmethod
    def query_android_startups(process_name, start_time, end_time):
        """
        从android_startups表中查询除了process_name的启动信息
        :param process_name: 进程名称
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        sql = f"""
            SELECT * 
            FROM android_startups
            WHERE ts >= {start_time} AND ts <= {end_time}
            AND package NOT LIKE '{process_name}'
            ORDER BY ts ASC
        """
        return sql

    @staticmethod
    def query_launching_package_slice(process_name, start_time, end_time):
        """
        当从android_startups表中没有launchingActivity时，尝试直接查launching:package_name
        :param process_name: 进程名称
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        sql = f"""
            SELECT 
                ts,
                dur,
                ts + dur as ts_end,
                TRIM(SUBSTR(name, 11)) AS package
            FROM slice
            WHERE 
                name GLOB 'launching:*'
                AND dur > 0
                AND ts >= {start_time}
                AND ts + dur <= {end_time}
                AND package != '{process_name}'
        """

        return sql

    @classmethod
    def query_exit_desktop(cls, start_time, end_time):
        """
        从android_startups表中查询桌面退出的信息
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """
        # 从_android_startups_raw中查询桌面的启动
        sql = f"""
            SELECT 
              _android_startups_raw.*, 
              process.upid
            FROM _android_startups_raw
            JOIN process ON process.name GLOB _android_startups_raw.package || '*'
            WHERE ts >= {start_time} AND ts <= {end_time}
            AND package = '{cls.launcher_process}'
            ORDER BY ts ASC
        """

        return sql

    @staticmethod
    def query_activity_start(start_time, end_time, process_name=None):
        """
        从android_activity_startups_raw中查询指定进程的启动信息
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        :param process_name: 进程名称, 默认为None
        """

        sql = f"""
            SELECT ts, ts_end, package, startup_type 
            FROM android_activity_startups_raw 
            WHERE ts >= {start_time} AND ts_end <= {end_time} 
            ORDER BY ts ASC 
        """
        if process_name is not None:
            sql = f"""
                SELECT ts, ts_end, package, startup_type 
                FROM android_activity_startups_raw 
                WHERE ts >= {start_time} AND ts_end <= {end_time} 
                AND package LIKE '{process_name}'
                ORDER BY ts ASC 
            """
        return sql

    @classmethod
    def query_sf_timeline(cls, start_time, end_time):
        """
        查询 surfaceflinger 的 Actual Timeline信息
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        sql = f"""
            SELECT DISTINCT
                slice.name AS slice_name,
                slice.id AS slice_id,
                slice.ts AS slice_ts,
                (slice.ts + slice.dur) AS slice_te,
                process.name AS process_name
            FROM
                slice
            JOIN process_track ON process_track.id = slice.track_id
            JOIN process ON process_track.upid = process.upid
            WHERE
                process_track.name = 'Actual Timeline'
                AND process.name = '{cls.sf_process}'
                AND slice.ts >= {start_time}
                AND slice.ts < {end_time}
            ORDER BY slice.ts ASC;
        """
        return sql

    @staticmethod
    def query_thread_first_frame(thread_name, start_time, end_time):
        """
        查询指定线程的第一帧非 -1 的 doframe 信息
        :param thread_name: 查询的指定线程
        :param start_time: 查询的开始时间
        :param end_time： 查询的结束时间
        """

        sql = f"""
          SELECT
            slice.ts AS ts,
            slice.ts + slice.dur AS te,
            slice.name AS doframe_name
          FROM slice
          JOIN thread_track tt ON slice.track_id = tt.id
          JOIN thread t USING (utid)
          WHERE
            t.name = '{thread_name}'
            AND slice.name GLOB 'Choreographer#doFrame [0-9]*'
            AND ts > {start_time}
            AND te < {end_time}
          ORDER BY slice.ts
          LIMIT 1;
        """
        return sql

    @staticmethod
    def query_same_name_timeline(frame_id, start_time, end_time):
        """根据 doframe xxxx 中的 xxx 序号找到对应的timeline的slice"""
        sql = f"""
            SELECT
                slice.id,
                slice.name,
                slice.ts
            FROM slice
            JOIN process_track pt ON pt.id = slice.track_id
            WHERE
                pt.name = 'Actual Timeline'
                AND slice.name = '{frame_id}'
                AND slice.ts >= {start_time}
                AND slice.ts < {end_time}
            ORDER BY slice.ts ASC
            LIMIT 1;
        """
        return sql

    @staticmethod
    def query_process_timeline(process_name, start_time, end_time, thread_filter):
        """
        查询指定进程的 Actual Timeline 信息
        :param process_name: 进程名称
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
         :param thread_filter: 线程过滤条件
        """

        sql = f"""
          SELECT DISTINCT
            slice.name AS slice_name,
            slice.ts AS slice_ts,
            slice.dur AS slice_dur,
            (slice.ts + slice.dur) AS slice_te
          FROM
            slice
          JOIN process_track ON process_track.id = slice.track_id
          JOIN process ON process_track.upid = process.upid
          JOIN thread ON process.upid = thread.upid
          WHERE
            process_track.name = 'Actual Timeline'
            AND process.name = '{process_name}'
            AND slice.ts >= {start_time}
            AND slice.ts < {end_time}
            {thread_filter}
          ORDER BY slice.ts ASC
        """
        return sql

    @staticmethod
    def query_first_frame_time(upid, start_time, end_time):
        """
        查询 surfaceflinger 和指定 upid 的view对应的第一帧 Actual Timeline 信息
        :param upid: 进程的 upid
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        sql = f"""
            WITH ui_frames AS (
              SELECT DISTINCT
                s.id AS ui_slice_id,
                s.ts AS ui_ts,
                (s.ts + s.dur) AS ui_te
              FROM slice s
              JOIN process_track pt ON pt.id = s.track_id
              JOIN process p ON pt.upid = p.upid
              WHERE
                pt.name = 'Actual Timeline'
                AND p.upid = {upid}
                AND s.ts >= {start_time}
                AND s.ts < {end_time}
              ORDER BY s.ts ASC
              LIMIT 60
            ),
            sf_map AS (
              SELECT
                uf.ui_slice_id AS ui_slice_id,
                f.slice_in AS sf_slice_id,
                uf.ui_ts AS ui_ts
              FROM ui_frames uf
              JOIN directly_connected_flow(uf.ui_slice_id) f
            ),
            sf_slices AS (
              SELECT
                sm.ui_slice_id,
                sm.sf_slice_id,
                sm.ui_ts,
                sl.name AS sf_name,
                sl.ts AS sf_ts,
                (sl.ts + sl.dur) AS sf_te
              FROM sf_map sm
              JOIN slice sl ON sm.sf_slice_id = sl.slice_id
            )
            SELECT
              ui_slice_id,
              ui_ts,
              sf_slice_id,
              sf_name,
              sf_ts,
              sf_te
            FROM sf_slices
            ORDER BY sf_ts ASC
            LIMIT 1;
        """
        return sql

    @staticmethod
    def frame_token_map(slice_id):
        """
        查询指定 slice_id 的 frame token 映射信息
        :param slice_id: 需要查询的 slice_id
        """

        sql = f"""
            SELECT
                f.slice_out AS SfSliceId,
                t2.name AS SfSliceName,
                t1.ts AS SfSliceStartTs,
                (t1.ts + t1.dur) AS SfSliceEndTs,
                f.slice_in AS UISliceId,
                t2.name AS UISliceName,
                t2.ts AS UISliceStartTs,
                (t2.ts + t2.dur) AS UISliceEndTs,
                f.id AS id
            FROM (
              SELECT * FROM directly_connected_flow({slice_id})
            ) f
                JOIN slice t1 ON f.slice_out = t1.slice_id
                JOIN slice t2 ON f.slice_in = t2.slice_id
                LEFT JOIN thread_track track_out ON track_out.id = t1.track_id
                LEFT JOIN thread_track track_in ON track_in.id = t2.track_id
        """
        return sql

    @staticmethod
    def query_range_timelines(start_time, end_time):
        """
        查询指定时间范围内的 sf Actual Timeline 信息
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """
        sql = f"""
            SELECT *
            FROM _sf_actual_timelines
            WHERE ui_ts >= {start_time} 
            AND sf_te <= {end_time}
            ORDER BY sf_ts ASC, ui_ts ASC
        """
        return sql

    @staticmethod
    def query_start_proc(process_name, start_time, end_time):
        """
        查询指定进程的启动信息
        :param process_name: 进程名称
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        sql = f"""
            SELECT
                slice.name AS slice_name,
                slice.ts AS slice_ts,
                (slice.ts + slice.dur) AS slice_te
            FROM slice
            JOIN thread_track ON thread_track.id = slice.track_id
            JOIN thread ON thread.utid = thread_track.utid
            WHERE
                slice.name LIKE 'Start Proc:%' AND slice.name LIKE '%{process_name}'
                AND thread.name = 'ActivityManager'
                AND slice.ts >= {start_time}
                AND slice.ts < {end_time}
            ORDER BY slice.ts ASC;
        """
        return sql
    
    @staticmethod
    def query_global_start_proc(start_time, end_time):
        """一次性查询全局所有的 Start Proc 事件"""
        return f"""
            SELECT
                slice.name AS slice_name,
                slice.ts AS slice_ts,
                (slice.ts + slice.dur) AS slice_te
            FROM slice
            JOIN thread_track ON thread_track.id = slice.track_id
            JOIN thread ON thread.utid = thread_track.utid
            WHERE
                slice.name LIKE 'Start Proc:%'
                AND thread.name = 'ActivityManager'
                AND slice.ts >= {start_time}
                AND slice.ts < {end_time}
            ORDER BY slice.ts ASC;
        """
    @staticmethod
    def query_bind_application(upid, start_time, end_time):
        """
        查询指定进程的 bindApplication 信息
        :param upid: 进程的 upid
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        sql = f"""
            SELECT
                slice.name AS slice_name,
                slice.ts AS slice_ts,
                (slice.ts + slice.dur) AS slice_te
            FROM slice
            JOIN thread_track ON thread_track.id = slice.track_id
            JOIN thread ON thread.utid = thread_track.utid
            WHERE slice.name = 'bindApplication'
                AND thread.upid = {upid}
                AND slice_ts >= {start_time}
                AND slice.ts < {end_time}
            ORDER BY slice_ts ASC;
        """
        return sql

    @staticmethod
    def query_activity_start_slice(upid, start_time, end_time):
        """
        查询指定进程的 activityStart 信息
        :param upid: 进程的 upid
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        sql = f"""
            SELECT
                slice.name AS slice_name,
                slice.ts AS slice_ts,
                (slice.ts + slice.dur) AS slice_te
            FROM slice
            JOIN thread_track ON thread_track.id = slice.track_id
            JOIN thread ON thread.utid = thread_track.utid
            WHERE
                slice.name = 'activityStart'
                AND thread.upid = {upid}
                AND slice_ts >= {start_time}
                AND slice.ts < {end_time}
            ORDER BY slice_ts ASC;
        """
        return sql

    @staticmethod
    def query_activity_resume_slice(upid, start_time, end_time):
        """
        查询指定进程的 activityResume 信息
        :param upid: 进程的 upid
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        sql = f"""
            SELECT
                slice.name AS slice_name,
                slice.ts AS slice_ts,
                (slice.ts + slice.dur) AS slice_te
            FROM slice
            JOIN thread_track ON thread_track.id = slice.track_id
            JOIN thread ON thread.utid = thread_track.utid
            WHERE
                slice.name = 'activityResume'
                AND thread.upid = {upid}
                AND slice_ts >= {start_time}
                AND slice.ts < {end_time}
            ORDER BY slice_ts ASC;
        """
        return sql
    
    @staticmethod
    def query_global_activity_resume(start_time, end_time):
        """
        一次性查询全局所有的 activityResume (performResume) 信息
        """
        sql = f"""
            SELECT 
              slice.ts AS slice_ts,
              (slice.dur + slice.ts) AS slice_te,
              slice.name AS slice_name,
              process.name AS process_name,
              process.upid AS upid,
              thread.utid AS utid
            FROM slice 
            JOIN thread_track ON slice.track_id = thread_track.id 
            JOIN thread ON thread_track.utid = thread.utid 
            JOIN process ON thread.upid = process.upid
            WHERE slice.name LIKE 'performResume:%' 
              AND slice.ts >= {start_time} 
              AND slice.ts < {end_time}
            ORDER BY slice_ts ASC
        """
        return sql
    
    @staticmethod
    def query_global_app_events(start_time, end_time):
        """一次性查询全局所有的 bindApplication, activityStart, activityResume"""
        return f"""
            SELECT
                slice.name AS slice_name,
                slice.ts AS slice_ts,
                (slice.ts + slice.dur) AS slice_te,
                thread.upid AS upid
            FROM slice
            JOIN thread_track ON thread_track.id = slice.track_id
            JOIN thread ON thread.utid = thread_track.utid
            WHERE slice.name IN ('bindApplication', 'activityStart', 'activityResume')
                AND slice.ts >= {start_time}
                AND slice.ts < {end_time}
            ORDER BY slice.ts ASC;
        """
    
    @staticmethod
    def query_click_activity_resume_name(start_time, end_time, package):
        """
        查询指定进程的应用内点击操作的 activityResume 启动的activity名称
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        :param package: 进程名称
        """
        sql = f"""
            SELECT 
              slice.ts AS slice_ts,
              (slice.dur + slice.ts) AS slice_te,
              slice.name AS slice_name,
              process.name AS process_name,
              process.upid AS upid,
              thread.utid AS utid
            FROM slice 
            JOIN thread_track ON slice.track_id = thread_track.id 
            JOIN thread ON thread_track.utid = thread.utid 
            JOIN process ON thread.upid = process.upid
            WHERE slice.name LIKE 'performResume:%' 
              AND slice.ts >= {start_time} 
              AND slice.ts < {end_time}
              AND process.name LIKE '{package}%' 
            ORDER BY slice_ts ASC
        """
        return sql

    @staticmethod
    def query_activity_resume_name(start_time, end_time, package):
        """
        查询指定进程的 activityResume 启动的activity名称
        :param start_time: 查询的开始时间
        :param package: 进程名称
        """
        sql = f"""
            SELECT 
              slice.ts AS slice_ts,
              (slice.dur + slice.ts) AS slice_te,
              slice.name AS slice_name,
              process.name AS process_name,
              process.upid AS upid,
              thread.utid AS utid
            FROM slice 
            JOIN thread_track ON slice.track_id = thread_track.id 
            JOIN thread ON thread_track.utid = thread.utid 
            JOIN process ON thread.upid = process.upid
            WHERE slice.name LIKE 'performResume:%' 
              AND slice.ts >= {start_time} 
              AND slice.ts < {end_time}
              AND process.name LIKE '{package}%' 
            ORDER BY slice_ts ASC
        """
        return sql

    @staticmethod
    def check_completed_frame(slice_start, slice_end):
        """
        检查指定时间范围内的帧是否完整
        :param slice_start: 查询的开始时间
         :param slice_end: 查询的结束时间
        """

        sql = f"""
          SELECT DISTINCT
              CASE
                  WHEN name LIKE '%animation%' THEN 'animation'
                  WHEN name LIKE '%measure%' THEN 'measure'
              END AS type
          FROM slice
          WHERE ts >= {slice_start}
            AND ts + dur <= {slice_end}
            AND (
                  name LIKE '%animation%'
               OR name LIKE '%measure%'
            )    
        """
        return sql

    @staticmethod
    def query_input_method_animator(process_name=None, start_time=None, end_time=None):
        process_filter = ""
        if process_name:
            process_filter = f"""
            AND COALESCE(process_from_process_track.name, process_from_thread_track.name) = "{process_name}"
            """

        sql = f"""
          SELECT
            slice.name AS name,
            slice.dur AS slice_dur,
            slice.ts AS slice_ts,
            (slice.ts + slice.dur) AS slice_te,
            COALESCE(process_from_process_track.name, process_from_thread_track.name) AS package,
            COALESCE(process_from_process_track.upid, process_from_thread_track.upid) AS upid
          FROM slice
          LEFT JOIN process_track ON process_track.id = slice.track_id
          LEFT JOIN process AS process_from_process_track
            ON process_from_process_track.upid = process_track.upid
          LEFT JOIN thread_track ON thread_track.id = slice.track_id
          LEFT JOIN thread ON thread.utid = thread_track.utid
          LEFT JOIN process AS process_from_thread_track
            ON process_from_thread_track.upid = thread.upid
          WHERE slice.name IN ("InsetsAnimation: ime", "InsetsAsyncAnimation: ime")
            AND (slice.ts + slice.dur) >= {start_time}
            AND slice.ts <= {end_time}
            {process_filter}
          ORDER BY slice.ts;
        """
        return sql

    @staticmethod
    def input_method_insert_async_animation_frames(process_name, start_time, end_time):
        sql = f"""
          SELECT
            slice.ts AS slice_ts,
            slice.dur AS slice_dur,
            (slice.dur + slice.ts) AS slice_te,
            slice.name AS slice_name
          FROM slice
          JOIN thread_track ON slice.track_id = thread_track.id
          JOIN thread USING(utid)
          JOIN process USING(upid)
          WHERE process.name = "{process_name}"
            AND thread.name = "InsetsAnimation"
            AND slice.name = "animation"
            AND slice.ts BETWEEN {start_time} AND {end_time}
          ORDER BY slice_ts;
        """
        return sql

    @classmethod
    def query_common_animator(cls, start_time, end_time, process_name):
        """
        通用 animator 查询逻辑（默认根据传入的 process_name 查询）
        如果个别厂商（如小米）不在目标进程而在 system_server，则在子类中重写此方法。
        """
        sql = f"""
          SELECT
            slice.ts AS slice_ts,
            slice.dur AS slice_dur,
            (slice.ts + slice.dur) AS slice_te,
            process.cmdline,
            process.upid AS upid
          FROM slice
          JOIN process_track ON slice.track_id = process_track.id
          JOIN process ON process.upid = process_track.upid
          WHERE process.cmdline = '{process_name}'
            AND slice.name = 'animator'
            AND slice_te >= {start_time}
            AND slice_ts <= {end_time}
          ORDER BY slice_ts ASC   
        """
        return sql

    @staticmethod
    def query_animator(start_time, end_time, process_name, animator_name):
        """
        通用 animator 查询逻辑（默认根据传入的 process_name 查询）
        如果个别厂商（如小米）不在目标进程而在 system_server，则在子类中重写此方法。
        """
        sql = f"""
          SELECT
            slice.ts AS slice_ts,
            slice.dur AS slice_dur,
            (slice.ts + slice.dur) AS slice_te,
            process.cmdline,
            process.upid AS upid
          FROM slice
          JOIN process_track ON slice.track_id = process_track.id
          JOIN process ON process.upid = process_track.upid
          WHERE process.cmdline = '{process_name}'
            AND slice.name = '{animator_name}'
            AND slice_te >= {start_time}
            AND slice_ts <= {end_time}
          ORDER BY slice_ts ASC   
        """
        return sql

    @staticmethod
    def query_action_up(start_time, end_time, process_name):
        """
        查询指定进程的 dispatchInputEvent MotionEvent ACTION_UP 信息
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        :param process_name: 进程名称
        """

        sql = f"""
          SELECT
            slice.ts AS slice_ts,
            slice.dur AS slice_dur,
            (slice.ts + slice.dur) AS slice_te,
            process.cmdline,
            process.upid AS upid
          FROM slice
            JOIN thread_track ON slice.track_id = thread_track.id
            JOIN thread ON thread.utid = thread_track.utid
            JOIN process ON process.upid = thread.upid
          WHERE process.cmdline = '{process_name}'
            AND thread.is_main_thread = 1
            AND slice.name LIKE 'dispatchInputEvent MotionEvent ACTION_UP%'
            AND slice_ts >= {start_time}
            AND slice_ts <= {end_time}
          ORDER BY slice_ts ASC   
        """
        return sql

    @staticmethod
    def query_all_animator(start_time, end_time, process_name):
        """
        查询指定进程的 animator 动效信息
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        :param process_name: 进程名称
        """
        animator_tracks = [
            "animator",
            "animator:alpha",
            "animator:scaleX",
            "animator:scaleY",
            "animator:alpha,scaleX,scaleY",
            "animator:translationX",
            "animator:translationY",
        ]
        one_second_ns = 1_000_000_000

        track_conditions = " OR ".join(
            [f"slice.name = '{track}'" for track in animator_tracks]
        )
        time_conditions = f"AND slice.ts < ({start_time} + {one_second_ns})"

        sql = f"""
          SELECT
            MIN(slice.ts) AS min_slice_ts,
            MAX(slice.ts + slice.dur) AS max_slice_te,
            MAX(slice.dur) AS slice_dur,
            process.cmdline,
            process.upid AS upid
          FROM slice
          JOIN process_track ON slice.track_id = process_track.id
          JOIN process ON process.upid = process_track.upid
          WHERE process.cmdline = '{process_name}'
            AND ({track_conditions})
            AND (slice.ts + slice.dur) >= {start_time}
            AND slice.ts <= {end_time}
            {time_conditions}
          ORDER BY min_slice_ts  ASC   
        """
        return sql

    @classmethod
    def query_start_activity_inner(cls, start_time, end_time):
        """
        查询指定时间范围内的 startActivityInner 的slice
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        sql = f"""
            SELECT 
              slice.ts AS slice_ts,
              (slice.dur + slice.ts) AS slice_te,
              slice.name AS slice_name,
              process.name AS process_name,
              thread.utid AS utid
            FROM slice 
            JOIN thread_track ON slice.track_id = thread_track.id 
            JOIN thread ON thread_track.utid = thread.utid 
            JOIN process ON thread.upid = process.upid
            WHERE slice.name = 'startActivityInner' 
              AND slice.ts >= {start_time} 
              AND slice.ts < {end_time}
              AND process.name = '{cls.system_process}' 
            ORDER BY slice_ts ASC
            LIMIT 1;
        """
        return sql

    @staticmethod
    def get_binder_source_process(start_ts, end_ts, utid):
        """
        获取 binder 的 source process
        :param start_ts: 查询的开始时间
        :param end_ts: 查询的结束时间
        :param utid: 线程 utid
        """

        sql = f"""
            WITH binder_reply AS (
                SELECT s.id AS slice_id
                FROM slice s
                JOIN thread_track tt ON s.track_id = tt.id
                WHERE s.name = 'binder reply'
                  AND tt.utid = {utid}
                  AND s.ts <= {start_ts}
                  AND (s.ts + s.dur) >= {end_ts}
                LIMIT 1
            )
            SELECT p.name AS process_name
            FROM directly_connected_flow((SELECT slice_id FROM binder_reply)) f
            JOIN slice s ON f.slice_out = s.id
            JOIN thread_track tt ON s.track_id = tt.id
            JOIN thread t ON tt.utid = t.utid
            JOIN process p ON t.upid = p.upid
            LIMIT 1;
        """
        return sql

    @staticmethod
    def check_deliver_input(deliver_input_ts, deliver_input_te):
        """
        检测是不是有异常的 deliverInput 事件 (滑动事件)
        """
        sql = f"""
            SELECT 1
            FROM slice 
            WHERE (name LIKE 'BeginFluencyDetect%' OR name LIKE 'EndFluencyDetect%')
                AND name LIKE '%LAUNCHER_SLIDE_ANIMATION%'
                AND ts > {deliver_input_ts} 
                AND ts < {deliver_input_te}
            LIMIT 1
        """
        return sql

    @staticmethod
    def get_deliver_process(start_ts, end_ts):
        """
        获取时间段内存在 deliverInputEvent 的 source process
        :param start_ts: 查询的开始时间
        :param end_ts: 查询的结束时间
        """

        sql = f"""
            SELECT 
                process.name as process_name,
                process.upid as upid
            FROM slice
            JOIN process_track ON slice.track_id = process_track.id
            JOIN process ON process.upid = process_track.upid
            WHERE slice.name = 'deliverInputEvent'
                AND slice.ts >= {start_ts}
                AND slice.ts < {end_ts}
            ORDER BY slice.ts ASC;
        """
        return sql


class Honor(Common):
    """荣耀机型"""

    launcher_process: str = "com.hihonor.android.launcher"
    system_process: str = "system_server"
    systemui_process: str = "com.android.systemui"
    sf_process: str = "/system/bin/surfaceflinger"
    start_animator_name: str = "animator"
    exit_animator_name: str = "animator"
    animator_type: str = "render"
    start_animator_process: str = "com.hihonor.android.launcher"
    exit_animator_process: str = "com.hihonor.android.launcher"

    photo_process: str = "com.hihonor.photos"
    camera_process: str = "com.hihonor.camera"
    wmshell_anim: str = "wmshell.anim"

    @staticmethod
    def query_startup_animation_flag(start_time, end_time):
        """
        查询指定时间范围内的启动动效标志位
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """
        # 查询动效范围打点
        sql = f"""
            SELECT
              min(ts) AS ts,
              max(te) AS te,
              (max(te) - min(ts)) AS dur
            FROM (
              SELECT ts, (ts + dur) AS te
              FROM slice
              WHERE
                  (
                    name = 'BeginFluencyDetect: HOME_TO_APP_ANIMATION' OR
                    name = 'EndFluencyDetect: HOME_TO_APP_ANIMATION' OR
                    name LIKE 'Thumbnail animation start' OR
                    name LIKE 'Thumbnail animation end'
                  )
                AND ts >= {start_time}
                AND ts < {end_time}
              ORDER BY ts
              LIMIT 2
            )
        """
        return sql

    @staticmethod
    def query_exit_animation_flag(start_time, end_time):
        """
        查询指定时间范围内的退出动效标志位
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        sql = f"""
          SELECT
            min(ts) AS ts,
            max(te) AS te,
            (max(te) - min(ts)) AS dur,
            name
          FROM (
            SELECT ts, (ts + dur) AS te, name
            FROM slice
            WHERE 
              (
                name = 'BeginFluencyDetect: APP_TO_HOME_ANIMATION' OR
                name = 'EndFluencyDetect: APP_TO_HOME_ANIMATION' OR
                name LIKE 'Thumbnail animation start' OR
                name LIKE 'Thumbnail animation end'
              )
              AND ts >= {start_time}
              AND ts < {end_time}
            ORDER BY ts
            LIMIT 2
          )
        """
        return sql

    @staticmethod
    def query_camera_photo_animation_flag(start_time, end_time):
        """
        查询指定时间范围内的相机启动图库动效标志位
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """
        # 查询动效范围打点
        sql = f"""
            SELECT
              min(ts) AS ts,
              max(te) AS te,
              (max(te) - min(ts)) AS dur
            FROM (
              SELECT ts, (ts + dur) AS te
              FROM slice
              WHERE
                name LIKE 'Thumbnail animation start' OR name LIKE 'Thumbnail animation end'
                AND ts >= {start_time}
                AND ts < {end_time}
              ORDER BY ts
              LIMIT 2
            )
        """
        return sql

    @staticmethod
    def query_multi_animation_flag(start_time, end_time, key_name):
        """
        查询指定时间范围内的多任务动效标志位
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        :param key_name: 动效名称
        """
        sql = f"""
              SELECT ts, (ts + dur) AS te, name
              FROM slice
              WHERE
                (name = 'BeginFluencyDetect: {key_name}' OR name = 'EndFluencyDetect: {key_name}')
                AND ts >= {start_time}
                AND ts < {end_time}
              ORDER BY ts
        """
        return sql

    @staticmethod
    def query_ctct_animation_flag(start_time, end_time):
        """
        查询指定时间范围内的下拉控制中心和通知栏动效标志位
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        sql = f"""
              SELECT ts, (ts + dur) AS te, name
              FROM slice
              WHERE
                (name = 'BeginFluencyDetect: APP_NOTIFICATION_PANEL' OR name = 'EndFluencyDetect: APP_NOTIFICATION_PANEL')
                AND ts >= {start_time}
                AND ts < {end_time}
              ORDER BY ts
        """
        return sql

    @classmethod
    def window_focus(cls, start_time, end_time):
        """
        查询指定时间范围内的下拉控制中心和通知栏的MSG_WINDOW_FOCUS_CHANGE标志位
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        sql = f"""
            SELECT slice.ts, (slice.ts + slice.dur) AS te, slice.name AS slice_name, process.upid AS upid
            FROM slice
                JOIN thread_track ON thread_track.id = slice.track_id
                JOIN thread ON thread.utid = thread_track.utid
                JOIN process ON process.upid = thread.upid
            WHERE
                slice.name LIKE '%MSG_WINDOW_FOCUS_CHANGE%'
                AND process.name = '{cls.systemui_process}'
                AND ts >= {start_time}
                AND ts < {end_time}
            ORDER BY ts
        """
        return sql

    @staticmethod
    def query_unlock_animation_flag(start_time, end_time):
        """
        查询指定时间范围内的解锁动效标志位
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """
        sql = f"""
            SELECT ts, (ts + dur) AS te, name
            FROM slice
            WHERE 
              (name LIKE 'BeginFluencyDetect%' OR name LIKE 'EndFluencyDetect%') 
              AND name LIKE '%UNLOCK_LAUNCHER_ANIMATION'
              AND ts >= {start_time}
              AND ts < {end_time}
            ORDER BY ts
        """
        return sql

    @classmethod
    def physics_motion(cls, start_time, end_time):
        """
        查询指定时间范围内的 PhysicsMotion 的slice
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        process_name = cls.launcher_process

        sql = f"""
            SELECT
              slice.name AS slice_name,
              slice.ts AS slice_ts,
              (slice.ts + slice.dur) AS slice_te
            FROM slice
            JOIN process_track ON process_track.id = slice.track_id
            JOIN process ON process.upid = process_track.upid
            WHERE
              slice.name LIKE 'PhysicsMotion recent.%'
              AND process.name LIKE '%{process_name}%'
              AND slice.ts >= {start_time}
              AND slice.ts < {end_time}
            ORDER BY slice_ts ASC
        """
        return sql

    @classmethod
    def pre_start_anim(cls, start_time, end_time):
        """
        查询指定时间范围内的 PreStartAnim PhysicsMotion recent.appRemoteAnim isBack:false 的slice
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        process_name = cls.launcher_process

        sql = f"""
            SELECT
              slice.name AS slice_name,
              slice.ts AS slice_ts,
              (slice.ts + slice.dur) AS slice_te
            FROM slice
            JOIN process_track ON process_track.id = slice.track_id
            JOIN process ON process.upid = process_track.upid
            WHERE
              slice.name LIKE '%PhysicsMotion recent.appRemoteAnim isBack:false%'
              AND process.name LIKE '%{process_name}%'
              AND slice.ts >= {start_time}
              AND slice.ts < {end_time}
            ORDER BY slice_ts ASC
            LIMIT 1
        """
        return sql

    @staticmethod
    def transaction(start_time, end_time):
        """
        动效引擎生效时，查询sf中有无对应的leash图层信息，并查询对应的compose编号
        """

        sql = f"""
            SELECT
                apply_slice.ts AS apply_ts,
                apply_slice.ts + apply_slice.dur AS apply_te,
                apply_slice.name AS apply_name,
                commit_slice.name AS commit_name
            FROM slice AS apply_slice
            JOIN thread_track AS apply_track ON apply_slice.track_id = apply_track.id
            JOIN thread AS apply_thread ON apply_track.utid = apply_thread.utid
            JOIN slice AS commit_slice
                ON commit_slice.track_id = apply_slice.track_id
                AND commit_slice.name GLOB 'commit [0-9]*'
                AND apply_slice.ts >= commit_slice.ts
                AND apply_slice.ts + apply_slice.dur <= commit_slice.ts + commit_slice.dur
            WHERE apply_thread.name = 'surfaceflinger'
                AND apply_slice.name LIKE 'ApplyTransaction:Surface%transition-leash%'
                AND apply_slice.ts >= {start_time}
                AND apply_slice.ts < {end_time};   
        """
        return sql

    @staticmethod
    def quick_transaction(start_time, end_time):
        """
        动效引擎生效时，仅查询sf中有无对应的leash图层信息（有的版本sf主线程没有name）
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        sql = f"""
        WITH apply_slices AS (
          SELECT
            flush_slice.id AS flush_id,
            apply_slice.ts AS apply_ts,
            apply_slice.ts + apply_slice.dur AS apply_te,
            apply_slice.name AS apply_name,
            ROW_NUMBER() OVER (
              PARTITION BY flush_slice.id
              ORDER BY apply_slice.ts DESC
            ) AS rn
          FROM slice AS apply_slice
          JOIN slice AS flush_slice
            ON apply_slice.parent_id = flush_slice.id
          JOIN thread_track AS apply_track ON apply_slice.track_id = apply_track.id
          JOIN thread AS apply_thread ON apply_track.utid = apply_thread.utid
          JOIN process ON process.upid = apply_thread.upid
          WHERE process.name = '/system/bin/surfaceflinger'
            AND apply_thread.is_main_thread = 1
            AND flush_slice.name = 'TransactionHandler:flushTransactions'
            AND apply_slice.name LIKE 'ApplyTransaction:Surface%transition-leash%'
            AND apply_slice.ts >= {start_time}
            AND apply_slice.ts < {end_time}
        )
        
        SELECT
          apply_ts,
          apply_te,
          apply_name
        FROM apply_slices
        WHERE rn = 1
        ORDER BY apply_ts ASC;
        """
        return sql


class Honor_sink(Common):
    """荣耀机型（下沉动效）"""

    launcher_process: str = "com.hihonor.android.launcher"
    system_process: str = "system_server"
    systemui_process: str = "com.android.systemui"
    sf_process: str = "/system/bin/surfaceflinger"
    start_animator_name: str = "animator"
    exit_animator_name: str = "animator"
    animator_type: str = "SetSurfaceFlingerAnimation"
    start_animator_process: str = "com.hihonor.android.launcher"
    exit_animator_process: str = "com.hihonor.android.launcher"

    photo_process: str = "com.hihonor.photos"
    camera_process: str = "com.hihonor.camera"
    wmshell_anim: str = "wmshell.anim"

    @staticmethod
    def query_startup_animation_flag(start_time, end_time):
        """
        查询指定时间范围内的启动动效标志位
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """
        sql = f"""
            SELECT
              min(ts) AS ts,
              max(te) AS te,
              (max(te) - min(ts)) AS dur
            FROM (
              SELECT ts, (ts + dur) AS te
              FROM slice
              WHERE
                  (
                    name = 'BeginFluencyDetect: HOME_TO_APP_ANIMATION' OR
                    name = 'EndFluencyDetect: HOME_TO_APP_ANIMATION' OR
                    name LIKE 'Thumbnail animation start' OR
                    name LIKE 'Thumbnail animation end'
                  )
                AND ts >= {start_time}
                AND ts < {end_time}
              ORDER BY ts
              LIMIT 2
            )
        """
        return sql

    @staticmethod
    def query_exit_animation_flag(start_time, end_time):
        """
        查询指定时间范围内的退出动效标志位
        :param start_time: 查询的开始时间
        :param end_time: 查询的结束时间
        """

        sql = f"""
          SELECT
            min(ts) AS ts,
            max(te) AS te,
            (max(te) - min(ts)) AS dur,
            name
          FROM (
            SELECT ts, (ts + dur) AS te, name
            FROM slice
            WHERE 
              (
                name = 'BeginFluencyDetect: APP_TO_HOME_ANIMATION' OR
                name = 'EndFluencyDetect: APP_TO_HOME_ANIMATION' OR
                name LIKE 'Thumbnail animation start' OR
                name LIKE 'Thumbnail animation end'
              )
              AND ts >= {start_time}
              AND ts < {end_time}
            ORDER BY ts
            LIMIT 2
          )
        """
        return sql

    @staticmethod
    def animation_sink(start_time, end_time):
        # 查询动效下沉中sf中的绘制slice
        sql = f"""
            SELECT
                slice.name as slice_name,
                slice.id as slice_id,
                slice.ts as slice_ts,
                (slice.ts + slice.dur) as slice_te,
                slice.depth as slice_depth,
                thread.name as thread_name,
                thread.is_main_thread
            FROM slice
            JOIN thread_track on slice.track_id = thread_track.id
            JOIN thread on thread.utid = thread_track.utid
            WHERE slice.name like "com.hihonor.android.launcher/com.hihonor.android.launcher.unihome.UniHomeLauncher#%"
                AND thread.name = "surfaceflinger"
                AND slice_ts >= {start_time}
                AND slice_ts <= {end_time}
            ORDER BY slice_ts ASC
        """
        return sql


# ============================================================
# 竞品机型 SQL 类
# ============================================================


class Xiaomi(Common):
    """小米机型"""

    launcher_process: str = "com.miui.home"
    system_process: str = "system_server"
    systemui_process: str = "com.android.systemui"
    sf_process: str = "/system/bin/surfaceflinger"
    start_animator_name: str = "animating"
    exit_animator_name: str = "animator"
    animator_type: str = "render"
    start_animator_process: str = "system_server"
    exit_animator_process: str = "com.miui.home"


class Vivo(Common):
    """Vivo机型"""

    launcher_process: str = "com.bbk.launcher2"
    system_process: str = "system_server"
    systemui_process: str = "com.android.systemui"
    sf_process: str = "/system/bin/surfaceflinger"
    start_animator_name: str = "openApp_Window"
    exit_animator_name: str = "animator:App To Home"
    animator_type: str = "render"
    start_animator_process: str = "com.bbk.launcher2"
    exit_animator_process: str = "com.bbk.launcher2"

    @classmethod
    def query_animator_fallback(cls, start_time, end_time):
        """Vivo 专属降级逻辑：当带进程名查不到时，不限制进程名再查一次"""
        sql = f"""
          SELECT
            slice.ts AS slice_ts,
            slice.dur AS slice_dur,
            (slice.ts + slice.dur) AS slice_te
          FROM slice
          WHERE slice.name = '{cls.start_animator_name}'
            AND slice_te >= {start_time}
            AND slice_ts <= {end_time}
          ORDER BY slice_ts ASC   
        """
        return sql


class Oppo(Common):
    """Oppo机型"""

    launcher_process: str = "com.android.launcher"
    system_process: str = "system_server"
    systemui_process: str = "com.android.systemui"
    sf_process: str = "/system/bin/surfaceflinger"
    start_animator_name: str = "window_animation: LAUNCH_APP"
    exit_animator_name: str = "Task Animation"
    animator_type: str = "render"
    start_animator_process: str = "com.android.launcher"
    exit_animator_process: str = "com.android.launcher"


class Huawei(Common):
    """华为机型"""

    launcher_process: str = "com.huawei.android.launcher"
    system_process: str = "system_server"
    systemui_process: str = "com.android.systemui"
    sf_process: str = "/system/bin/surfaceflinger"
    start_animator_name: str = "animator"
    exit_animator_name: str = "animator"
    animator_type: str = "render"
    start_animator_process: str = "com.huawei.android.launcher"
    exit_animator_process: str = "com.huawei.android.launcher"


class HarmonyOS_NEXT(Common):
    """华为NEXT机型"""

    launcher_process: str = "com.huawei.android.launcher"
    system_process: str = "system_server"
    systemui_process: str = "com.android.systemui"
    sf_process: str = "/system/bin/surfaceflinger"
    start_animator_name: str = "animator"
    exit_animator_name: str = "animator"
    animator_type: str = "render_node"
    start_animator_process: str = "com.huawei.android.launcher"
    exit_animator_process: str = "com.huawei.android.launcher"

    @staticmethod
    def query_deliver_input(process_name, start_time, end_time):
        """
        重写：NEXT 系统的触控打点完全不同
        """
        sql = f"""
            SELECT 
                slice.id AS slice_id, 
                slice.name AS slice_name, 
                slice.ts AS slice_ts, 
                slice.dur AS slice_dur, 
                (slice.dur + slice.ts) AS slice_te
            FROM slice 
            JOIN thread_track ON slice.track_id = thread_track.id 
            JOIN thread ON thread.utid = thread_track.utid 
            WHERE slice.name LIKE 'H:DispatchTouchEvent id:%, pointX=% pointY=% type=1%' 
              AND thread.name = 'ohos.sceneboard'
              AND slice.ts >= {start_time} 
              AND slice.ts < {end_time}
            ORDER BY slice_ts ASC;
        """
        return sql

    @staticmethod
    def query_commit_layer(start_time, end_time):
        """
        新增：NEXT 系统的渲染帧获取逻辑 (替代安卓的 Actual Timeline)
        """
        sql = f"""
            SELECT 
                slice.name as slice_name, 
                slice.id as slice_id, 
                slice.ts as slice_ts, 
                (slice.ts + slice.dur) as slice_te, 
                slice.depth as slice_depth, 
                thread.name as thread_name, 
                thread.is_main_thread 
            FROM slice 
            JOIN thread_track ON slice.track_id = thread_track.id 
            JOIN thread ON thread.utid = thread_track.utid 
            WHERE slice.name LIKE 'H:RSScreenRenderNodeDrawable CommitLayer%' 
              AND thread.name = 'RSUniRenderThre'
              AND slice.ts >= {start_time}
              AND slice.ts <= {end_time}
            ORDER BY slice_ts ASC;
        """
        return sql

    @staticmethod
    def query_startup_animation_flag(start_time, end_time):
        """
        重写：NEXT 系统的动效标志位
        """
        sql = f"""
            SELECT min(ts) as ts, max(te) as te, (max(te) - min(ts)) as dur 
            FROM (
                SELECT ts, (ts + dur) as te 
                FROM slice 
                WHERE (
                    name LIKE "H:EVENT_REPORT_RESPONSE_RS sceneId = LAUNCHER_APP_LAUNCH_FROM_%, uniqueId = %" 
                    OR name LIKE "H:EVENT_REPORT_JANK_RS sceneId = LAUNCHER_APP_LAUNCH_FROM_%, uniqueId = %"
                )
                AND ts >= {start_time}
                AND ts < {end_time}
                ORDER BY ts LIMIT 2
            )
        """
        return sql


class Samsung(Common):
    """三星机型"""

    launcher_process: str = "com.sec.android.app.launcher"
    system_process: str = "system_server"
    systemui_process: str = "com.android.systemui"
    sf_process: str = "/system/bin/surfaceflinger"
    start_animator_name: str = "animator"
    animator_type: str = "render"
    start_animator_process: str = "com.sec.android.app.launcher"
    exit_animator_name: str = "animator"
    exit_animator_process: str = "com.sec.android.app.launcher"


class Flip(Common):
    """传音(Flip)机型"""

    launcher_process: str = "com.transsion.hilauncher"
    system_process: str = "system_server"
    systemui_process: str = "com.android.systemui"
    sf_process: str = "/system/bin/surfaceflinger"
    start_animator_name: str = "animator"
    animator_type: str = "render"
    start_animator_process: str = "com.transsion.hilauncher"
    exit_animator_name: str = "animator"
    exit_animator_process: str = "com.transsion.hilauncher"


class Google(Common):
    """Google/AOSP机型"""

    launcher_process: str = "com.android.launcher3"
    system_process: str = "system_server"
    systemui_process: str = "com.android.systemui"
    sf_process: str = "/system/bin/surfaceflinger"
    start_animator_name: str = "animator"
    animator_type: str = "render"
    start_animator_process: str = "com.android.launcher3"
    exit_animator_name: str = "animator"
    exit_animator_process: str = "com.android.launcher3"


class SqlFactory:
    """根据机器类型返回对应的类实例"""

    @staticmethod
    def get_sql_class(device_brand):
        mapping = {
            "Common": Common,
            "Honor": Honor,
            "Honor_sink": Honor_sink,
            "Xiaomi": Xiaomi,
            "Vivo": Vivo,
            "Oppo": Oppo,
            "Huawei": Huawei,
            "HarmonyOS_NEXT": HarmonyOS_NEXT,
            "Samsung": Samsung,
            "Flip": Flip,
            "Google": Google,
        }
        if device_brand not in mapping:
            raise ValueError(f"未知的设备品牌: {device_brand}")
        return mapping[device_brand]()
