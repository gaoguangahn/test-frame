import os

import pandas
from perfetto.trace_processor import TraceProcessor, TraceProcessorConfig

from metric_parser.utils.logger import ParseLogger


class TraceProcessorHandler:
    """
    TraceProcessor 处理器
    一个实例对应一个 trace 文件，构造时加载
    不再需要锁，因为每个实例只处理一个 trace
    """

    def __init__(self, binary: str, trace_file: str):
        """
        初始化并加载 trace 文件
        :param binary: trace_processor_shell.exe 的绝对路径
        :param trace_file: 要加载的 trace 文件路径
        """
        if not os.path.isfile(binary):
            raise FileNotFoundError(f"trace_processor_shell.exe not found: {binary}")
        if not trace_file:
            raise ValueError("trace_file 未指定")
        if not os.path.isfile(trace_file):
            raise FileNotFoundError(f"trace 文件不存在：{trace_file}")

        self.exe_file = binary
        self.trace_file = trace_file
        self.logger = ParseLogger("TraceProcessorHandler")

        # 创建 TraceProcessor 并加载 trace
        self.trace_config = TraceProcessorConfig(bin_path=binary)
        self.trace_processor = TraceProcessor(
            trace=trace_file, config=self.trace_config
        )

    def __enter__(self):
        """支持 with 语句"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """退出 with 语句时自动关闭"""
        self.close()
        return False

    def get_exe(self):
        return self.exe_file

    def get_file(self):
        return self.trace_file

    def query(self, sql) -> pandas.DataFrame:
        """
        执行 SQL 查询并返回 pandas.DataFrame。
        """
        if self.trace_processor is None:
            raise RuntimeError("TraceProcessor 已关闭")
        data_frame = self.trace_processor.query(sql).as_pandas_dataframe()
        return data_frame

    def metric(self, metrics):
        """
        计算指标，透传给 TraceProcessor.metric。
        """
        if self.trace_processor is None:
            raise RuntimeError("TraceProcessor 已关闭")
        return self.trace_processor.metric(metrics)

    def get_trace_bounds(self) -> tuple[int, int]:
        """
        查询 trace 的起始和终止时间（单位同原始 trace），失败返回 (-1, -1)。
        """
        if self.trace_processor is None:
            raise RuntimeError("TraceProcessor 已关闭")

        sql = "select start_ts, end_ts from trace_bounds"
        try:
            df = self.trace_processor.query(sql).as_pandas_dataframe()

            if df.empty:
                return -1, -1

            start_ts = (
                int(df["start_ts"].iloc[0]) if df["start_ts"].iloc[0] is not None else 0
            )
            end_ts = (
                int(df["end_ts"].iloc[0]) if df["end_ts"].iloc[0] is not None else 0
            )
            return start_ts, end_ts

        except Exception as e:
            self.logger.e(f"查询 trace_bounds 失败：{e}")
            return -1, -1

    def close(self):
        if self.trace_processor is not None:
            try:
                proc = getattr(self.trace_processor, "subprocess", None)

                self.trace_processor.close()

                if proc and proc.poll() is None:
                    try:
                        proc.kill()
                        proc.wait(timeout=2)
                    except Exception:
                        pass

            finally:
                self.trace_processor = None
