from typing import Optional

from metric_parser.trace.base.context import TraceContext
from metric_parser.trace.base.result import AnalyseResult
from metric_parser.utils.logger import ParseLogger


class BaseTraceAnalyse:
    """重构后的分析器基类"""
    def __init__(self, context: 'TraceContext'):
        self.context = context
        # 为了兼容旧代码，可以直接把 context 里的属性提出来
        self.tp = context.tp
        self.table_handler = context.table_handler
        self.device_brand = context.device_brand
        self.logger = ParseLogger(self.__class__.__name__)

    def analyse(self, start=None, end=None, **kwargs) -> AnalyseResult:
        """统一的标准化入口方法，子类必须实现"""
        raise NotImplementedError("子类必须实现 analyse 方法")

    def success(self, data) -> AnalyseResult:
        return AnalyseResult(success=True, data=data)

    def fail(self, error) -> AnalyseResult:
        return AnalyseResult(success=False, error=str(error))


    def _validate_time_range(self, start_ts: Optional[int], end_ts: Optional[int]):
        """统一时间范围校验逻辑"""
        if start_ts is None or end_ts is None:
            trace_start = self.context.trace_start
            trace_end = self.context.trace_end
            
            if trace_start == -1 or trace_end == -1:
                return None, None
                
            start_ts = trace_start if start_ts is None else start_ts
            end_ts = trace_end if end_ts is None else end_ts
            
        return start_ts, end_ts
