class HonorMachines:
    HONOR_BRANDS = [
        "Honor"
    ]

class CompetitorMachines:
    COMPETITOR_BRANDS = [
        "Xiaomi", "Vivo", "Oppo", "Huawei", "Samsung", "Flip", "Google"
    ]

class StartupConstants:
    KEYS_TO_KEEP = [
        "package",
        "startup_type",
        "deliver_te",
        "first_frame",
        "spend_time",
        "running_dur_ns",
        "runnable_dur_ns",
        "uninterruptible_sleep_dur_ns",
        "interruptible_sleep_dur_ns",
        "uninterruptible_io_sleep_dur_ns",
        "uninterruptible_non_io_sleep_dur_ns"
    ]