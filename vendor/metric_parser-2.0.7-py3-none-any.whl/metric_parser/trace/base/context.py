from metric_parser.trace.base.trace_processor_handler import TraceProcessorHandler
from metric_parser.trace.table.create_table import TableHandler


class TraceContext:
    """
    Trace 上下文环境
    只负责管理 TraceProcessor 和 TableHandler，按需提供给 Analyser
    """

    def __init__(self, exe_path: str, trace_file: str, device_brand: str = "Honor"):
        self.exe_path = exe_path
        self.trace_file = trace_file
        self.device_brand = device_brand

        # 初始化引擎
        self.tp = TraceProcessorHandler(exe_path, trace_file)
        self.table_handler = TableHandler(self.tp)

        self.trace_start, self.trace_end = self.tp.get_trace_bounds()

        if self.trace_start != -1 and self.trace_end != -1:
            self.trace_length = round(
                float(self.trace_end - self.trace_start) / 1000_000_000, 2
            )
        else:
            self.trace_length = 0.0

    def close(self):
        if self.tp:
            self.tp.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False
