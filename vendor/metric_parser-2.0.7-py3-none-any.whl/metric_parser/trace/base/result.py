from dataclasses import asdict, dataclass
from typing import TypeVar

# 定义一个泛型变量 T
T = TypeVar("T")


@dataclass
class AnalyseResult[T]:
    success: bool
    data: T | None = None
    error: str = ""

    def to_dict(self):
        return asdict(self)
