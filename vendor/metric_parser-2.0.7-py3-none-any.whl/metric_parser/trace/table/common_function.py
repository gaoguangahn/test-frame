"""
SQL函数

版本: v1.1.0
"""

# 函数: 根据传入的进程信息获取进程对应的包名、版本号、是否debuggable
FUNCTION_PACKAGE_FOR_PROCESS = """
    CREATE PERFETTO FUNCTION _android_package_for_process(
        uid LONG,
        uid_count LONG,
        process_name STRING
    )
    RETURNS TABLE (
      package_name STRING,
      version_code LONG,
      debuggable BOOL
    ) AS
    WITH
      min_distance AS (
        SELECT
          min(length($process_name) - length(package_name)),
          package_name,
          version_code,
          debuggable
        FROM package_list
        WHERE
          (
            (
              $uid = uid
              AND (
                $uid_count = 1
                OR $process_name GLOB package_name || '*'
              )
            )
            OR (
              $uid >= 90000
              AND $uid < 100000
              AND str_split($process_name, ':', 0) GLOB package_name || '*'
            )
          )
      )
    SELECT
      package_name,
      version_code,
      debuggable
    FROM min_distance; 
    """

# 函数: 判断是否是内核线程
FUNCTION_IS_KERNEL_TASK = """
    CREATE PERFETTO FUNCTION android_is_kernel_task(
        upid LONG
    )
    RETURNS BOOL AS
    SELECT
      EXISTS(
        SELECT
          TRUE
        FROM _android_kernel_tasks
        WHERE
          upid = $upid
      );
    """

# 函数: 获取_startup_indicator_slices表中的关键切片数量
FUNCTION_STARTUP_INDICATOR_SLICE_COUNT = """
    CREATE PERFETTO FUNCTION _startup_indicator_slice_count(
        start_ts TIMESTAMP,
        end_ts TIMESTAMP,
        utid LONG,
        name STRING
    )
    RETURNS LONG AS
    SELECT
      count(1)
    FROM thread_track AS t
    JOIN _startup_indicator_slices AS s
      ON s.track_id = t.id
    WHERE
      t.utid = $utid AND s.ts >= $start_ts AND s.ts < $end_ts AND s.name = $name;
  """