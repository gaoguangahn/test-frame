"""
下拉控制中心和通知栏分析模块

功能说明:
- 测量下拉控制中心和通知栏过程的动效卡顿
- 支持时间段多次下拉场景分析

版本: v1.2.0
"""

import numpy as np
import pandas as pd

from metric_parser.trace.base.base_analyser import BaseTraceAnalyse
from metric_parser.trace.base.registry import AnalyseRegistry
from metric_parser.trace.base.sqls import SqlFactory
from metric_parser.trace.models.control_center_data import (
    ControlCenterData,
    ControlCenterResult,
)
from metric_parser.trace.parsers.utils.util import is_all_none


@AnalyseRegistry.register("control_center")
class ControlCenter(BaseTraceAnalyse):
    """获取下拉控制中心和通知栏的动效"""

    def __init__(self, context):
        super().__init__(context)
        self.sqls = SqlFactory.get_sql_class(self.device_brand)

    def analyse(self, start=None, end=None, **kwargs):
        """统一的对外分析接口，解析下拉控制中心和通知栏的动效"""

        try:
            ctcts = self._analyse_internal(start, end)
        except Exception as e:
            self.logger.e(f"下拉控制中心/通知栏分析失败: {e}")
            return self.fail(f"下拉控制中心/通知栏分析失败: {e}")

        # 组装强类型返回结果
        results: list[ControlCenterResult] = []
        for ctct_slice in ctcts:
            if not ctct_slice.animation_frames:
                continue

            results.append(
                ControlCenterResult(
                    op_start=start if start else ctct_slice.animator_time[0],
                    animator_time=ctct_slice.animator_time[0],
                    animator_fps=ctct_slice.animator_fps,
                    animation_frames=ctct_slice.animation_frames,
                )
            )

        return self.success(results)

    def _analyse_internal(
        self, start_time: int | None, end_time: int | None
    ) -> list[ControlCenterData]:
        """解析下拉控制中心和通知栏的动效，返回状态列表"""

        ctcts: list[ControlCenterData] = []

        # 解析/校验时间范围
        actual_start_time, actual_end_time = self._validate_time_range(
            start_time, end_time
        )
        if actual_start_time is None or actual_end_time is None:
            self.logger.e("获取trace检测时间段失败")
            raise ValueError("获取trace检测时间段失败")

        try:
            # 获取动画起止时间戳
            self._get_animator_time(ctcts, actual_start_time, actual_end_time)
        except Exception as e:
            self.logger.e(f"获取下拉控制中心/通知栏间隔失败：{e}")
            return ctcts

        if len(ctcts) == 0:
            self.logger.e("没有识别到下拉控制中心/通知栏")
            return ctcts

        # 获取多任务区间的动效
        self._get_view_frames(
            ctcts, start_time=actual_start_time, end_time=actual_end_time
        )

        return ctcts

    def _get_animator_time(
        self, ctcts: list[ControlCenterData], start_time: int, end_time: int
    ):
        """获取多任务的动效起止时间，来确定进入多任务的次数
        根据不同的设备类型，使用不同的SQL查询策略获取动画时间范围
        """
        animator_pairs: list[tuple[int, int]] = []
        upid = -1

        # 荣耀设备处理逻辑
        # 查询打点事件（优先使用）
        animator_key_data = self._query_ctct_keys(
            start_time=start_time, end_time=end_time
        )

        if animator_key_data is not None and not animator_key_data.empty:
            animator_pairs = self._pair_ctct_keys(animator_key_data)

        # 如果打点匹配不到动画时间，兜底查 animator，前提是必须有输入时间，否则判断不准
        if not animator_pairs and start_time is not None and end_time is not None:
            animator_data = self._query_animator(
                start_time, end_time, self.sqls.systemui_process
            )
            if animator_data is not None and not animator_data.empty:
                first_animator = animator_data.iloc[0]
                animator_start = first_animator["min_slice_ts"]
                animator_end = first_animator["max_slice_te"]
                # 查询MSG_WINDOW_FOCUS_CHANGE，作为动效起始点
                window_sql = self.sqls.window_focus(
                    start_time=animator_start, end_time=animator_end
                )
                window_data = self.tp.query(window_sql)
                if not window_data.empty:
                    animator_start = window_data.iloc[0]["ts"]
                    upid = window_data.iloc[0]["upid"]
                animator_pairs.append((animator_start, animator_end))

        for pair in animator_pairs:
            ctcts.append(ControlCenterData(upid=upid, animator_time=pair))

    def _query_ctct_keys(self, start_time: int, end_time: int) -> pd.DataFrame | None:
        """按优先级查询多任务动效打点事件"""
        try:
            animator_key_sql = self.sqls.query_ctct_animation_flag(
                start_time=start_time,
                end_time=end_time,
            )
            data = self.tp.query(animator_key_sql)
            if not data.empty:
                return data
            return None
        except Exception as e:
            self.logger.e(f"查询多任务动效打点SQL失败：{e}")
            return None

    def _query_animator(self, start_time, end_time, process_name):
        """查询并过滤 animator 数据"""
        try:
            animator_sql = self.sqls.query_common_animator(
                start_time=start_time, end_time=end_time, process_name=process_name
            )
            data = self.tp.query(animator_sql)
            if len(data) > 0 and not is_all_none(data):
                data = data.loc[
                    data["slice_dur"].notnull() & (data["slice_dur"] > 100000000)
                ]
            return data
        except Exception as e:
            self.logger.e(f"查询animator时间SQL失败：{e}")
            return None

    @staticmethod
    def _pair_ctct_keys(data: pd.DataFrame) -> list[tuple[int, int]]:
        """将查询到的下拉通知栏打点匹配成对"""
        pairs = []
        begin_flag = False
        begin_ts = -1

        for idx, key in data.iterrows():
            name = str(key["name"])
            if "BeginFluencyDetect: " in name:
                ts = key["ts"]
                begin_ts = ts
                begin_flag = True
            elif "EndFluencyDetect: " in name:
                te = key["te"]
                if begin_flag:
                    end_ts = te
                    pairs.append((begin_ts, end_ts))
                    begin_ts = -1
                    begin_flag = False
        return pairs

    def _get_view_frames(
        self, ctcts: list[ControlCenterData], start_time: int, end_time: int
    ):
        """获取systemui绘制的动画帧的信息"""
        if len(ctcts) == 0:
            return

        # 获取systemui的upid
        ui_upid = -1
        for ctct in ctcts:
            if ctct.upid != -1:
                # 获取动画发生的upid，这里可能是systemui/launcher
                ui_upid = ctct.upid
                break

        if ui_upid == -1:
            upid_sql = self.sqls.query_process_upid(
                process_name=self.sqls.systemui_process
            )
            upid_data = self.tp.query(upid_sql)

            if not upid_data.empty:
                ui_upid = upid_data.iloc[0]["upid"]

        if ui_upid == -1:
            self.logger.e("未获取 systemui upid")
            return

        # 建立联系actual timeline的表
        try:
            self.table_handler.table_launcher_actual_timelines(
                ui_upid, start_time, end_time
            )
            self.table_handler.table_sf_actual_timelines()
        except Exception as e:
            self.logger.e(f"建立联系actual timeline的表失败：{e}")
            return

        for ctct_slice in ctcts:
            animator_ts, animator_te = ctct_slice.animator_time
            if animator_ts == -1 or animator_te == -1:
                continue

            # 获取动画帧率
            if ctct_slice.animator_fps == -1:
                animator_fps = self._get_fps(animator_ts, animator_te)
                ctct_slice.animator_fps = animator_fps

            try:
                range_sql = self.sqls.query_range_timelines(
                    start_time=animator_ts, end_time=animator_te
                )
                exit_timelines = self.tp.query(range_sql)

                if exit_timelines.empty:
                    self.logger.w("该次下滑通知栏/控制中心的 actual timelines is empty")
                    continue
            except Exception as e:
                self.logger.e(
                    f"获取该次下滑通知栏/控制中心的 actual timelines 失败：{e}"
                )
                continue
            try:
                exit_timelines["diff"] = exit_timelines["sf_te"] - exit_timelines[
                    "sf_te"
                ].shift(1)
                exit_timelines = exit_timelines.loc[exit_timelines["diff"] != 0]
                exit_timelines["diff"] = (
                    exit_timelines["diff"].apply(lambda x: x / 1000000).fillna(0)
                )
                ctct_slice.animation_frames = [
                    round(x, 2) for x in exit_timelines["diff"].tolist()
                ]
            except Exception as e:
                self.logger.e(f"diff calculation failed: {e}")

    def _get_fps(self, start_time: int, end_time: int) -> int:
        """根据vsync-sf推荐动画范围内的帧率和帧间隔"""
        vsync_sql = self.sqls.query_vsync_sf(start_time, end_time)
        vsync_df = self.tp.query(vsync_sql)

        timestamps = vsync_df["ts"].to_numpy(dtype="int64")
        durations = np.diff(timestamps) / 1e6  # ns -> ms

        # 3. 预定义分级阈值
        FPS_BINS = [
            (175, 185),
            (150, 165),
            (130, 144),
            (100, 120),
            (70, 90),
            (44, 60),
            (0, 30),
        ]

        # 4. 快速分箱统计
        hist = np.zeros(len(FPS_BINS), dtype=int)
        fps_values = 1000 / durations

        for i, (lower, _) in enumerate(FPS_BINS):
            if i == 0:
                mask = fps_values >= lower
            else:
                prev_lower = FPS_BINS[i - 1][0]
                mask = (fps_values >= lower) & (fps_values < prev_lower)
            hist[i] = np.sum(mask)

        # 5. 快速确定主频段
        dominant_idx = np.argmax(hist)
        target_fps = FPS_BINS[dominant_idx][1]
        return target_fps
