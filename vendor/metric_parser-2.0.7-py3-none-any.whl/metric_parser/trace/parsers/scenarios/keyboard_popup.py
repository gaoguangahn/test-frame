import numpy as np
import pandas as pd

from metric_parser.trace.base.base_analyser import BaseTraceAnalyse
from metric_parser.trace.base.registry import AnalyseRegistry
from metric_parser.trace.base.sqls import SqlFactory
from metric_parser.trace.models.keyboard_popup_data import (
    KeyboardPopupData,
    KeyboardPopupResult,
)
from metric_parser.trace.parsers.utils.thread_state import StateQuery


@AnalyseRegistry.register("input_method")
class KeyboardPopup(BaseTraceAnalyse):
    """输入法弹出响应和动效丢帧"""

    def __init__(self, context):
        super().__init__(context)
        self.state_query = StateQuery(self.tp)
        self.sqls = SqlFactory.get_sql_class(self.device_brand)

    def analyse(self, from_app=None, start=None, end=None, **kwargs):
        """统一的对外分析接口，返回输入法弹窗动画相关数据"""

        try:
            popups = self._analyse_internal(from_app, start, end)
        except Exception as e:
            self.logger.e(f"输入法弹出分析失败: {e}")
            return self.fail(f"输入法弹出分析失败: {e}")

        # 组装强类型返回结果
        results: list[KeyboardPopupResult] = []
        for s in popups:
            if s.response_time == -1:
                continue

            results.append(
                KeyboardPopupResult(
                    name=s.package_name,
                    op_start=start if start else s.animator_time[0],
                    animator_type=s.animator_type,
                    response_time=s.response_time,
                    animator_time=s.animator_time[0],
                    animator_fps=s.animator_fps,
                    animation_frames=s.animation_frames,
                )
            )

        return self.success(results)

    def _analyse_internal(
        self, from_app, start_time, end_time
    ) -> list[KeyboardPopupData]:
        """获取输入法弹出的相关metric，返回状态列表"""

        popups: list[KeyboardPopupData] = []

        # 1) 先获取实际的分析时间范围
        actual_start_time, actual_end_time = self._validate_time_range(
            start_time, end_time
        )
        if actual_start_time is None or actual_end_time is None:
            self.logger.e("获取trace检测时间段失败")
            raise ValueError("获取trace检测时间段失败")

        # 3) 获取输入法弹出列表。from_app 允许为空：为空时全局扫描
        # InsetsAnimation: ime / InsetsAsyncAnimation: ime，并从 slice 所属进程反推应用进程。
        self._get_input_method_popup_list(
            popups,
            from_app=from_app,
            start_time=actual_start_time,
            end_time=actual_end_time,
        )
        if len(popups) == 0:
            self.logger.w("没有识别到输入法弹出")
            return popups

        # 4) 获取各次输入法弹出前的触控时间戳 (过滤并返回新的列表)
        popups = self._get_deliver_input(
            popups, start_time=actual_start_time, end_time=actual_end_time
        )
        self._get_animations_frames(
            popups,
            start_time=actual_start_time,
            end_time=actual_end_time,
        )

        return popups

    def _get_input_method_popup_list(
        self,
        popups: list[KeyboardPopupData],
        from_app: str,
        start_time: int,
        end_time: int,
    ):
        sql = self.sqls.query_input_method_animator(
            process_name=from_app,
            start_time=start_time,
            end_time=end_time,
        )
        df_input_method_popup = self.tp.query(sql)

        if df_input_method_popup.empty:
            return

        # 填充默认值
        df_input_method_popup = df_input_method_popup.fillna(
            {
                "package": "unknown",
                "slice_ts": -1,
                "slice_te": -1,
                "slice_dur": -1,
                "upid": -1,
            }
        )

        for idx, row in df_input_method_popup.iterrows():
            pkg_name = row["package"]

            if pd.isna(pkg_name):
                pkg_name = "unknown"

            # 如果 upid 缺失或者为默认值 -1，则补充
            if row.get("upid", -1) == -1 and pkg_name != "unknown":
                upid_sql = self.sqls.query_process_upid(process_name=pkg_name)
                upid_df = self.tp.query(upid_sql)
                # 如果查到 upid，则赋值
                if not upid_df.empty and "upid" in upid_df.columns:
                    df_input_method_popup.at[idx, "upid"] = int(upid_df.iloc[0]["upid"])
                else:
                    # 查不到则保持为 -1
                    df_input_method_popup.at[idx, "upid"] = -1

            if not pkg_name or pkg_name == "unknown":
                self.logger.w("输入法弹出动效缺少进程名，跳过")
                continue

            popups.append(
                KeyboardPopupData(
                    package_name=pkg_name,
                    upid=int(df_input_method_popup.at[idx, "upid"]),
                    animator_type=df_input_method_popup.at[idx, "name"],
                    animator_time=(int(row["slice_ts"]), int(row["slice_te"])),
                )
            )

    def _get_deliver_input(
        self, popups: list[KeyboardPopupData], start_time: int, end_time: int
    ) -> list[KeyboardPopupData]:
        """获取输入的时间戳根据两次动效之间有无触控数据，做一步筛选"""
        if len(popups) == 0:
            return []

        new_popups: list[KeyboardPopupData] = []

        deliver_input_sql = self.sqls.query_all_deliver(
            start_time=start_time, end_time=end_time
        )

        deliver_input_data = self.tp.query(deliver_input_sql)

        if deliver_input_data.empty:
            return new_popups

        if "process_name" in deliver_input_data.columns:
            process_deliver_input_data = deliver_input_data[
                deliver_input_data["process_name"].isin(
                    {popup.package_name for popup in popups if popup.package_name}
                )
            ]
            if not process_deliver_input_data.empty:
                deliver_input_data = process_deliver_input_data

        for i, input_method in enumerate(popups):
            # 查找animator_ts之前最近的deliver
            pre_animator_te = popups[i - 1].animator_time[1] if i > 0 else start_time
            # 找到满足：pre_animator_te < iq_input_ts < animator_ts 的所有触控
            delivers_in_range = deliver_input_data[
                (deliver_input_data["slice_ts"] > pre_animator_te)
                & (deliver_input_data["slice_ts"] < input_method.animator_time[0])
            ]
            if delivers_in_range.empty:
                # 连续 Activity 启动或无输入，跳过
                continue

            nearest_deliver = delivers_in_range.iloc[-1]

            input_method.deliver_ts = nearest_deliver["slice_ts"]
            input_method.deliver_te = nearest_deliver["slice_te"]
            input_method.deliver_data = delivers_in_range

            # 保存一下两次启动间的deliver数据，方便在后面获取到动效范围后做修正
            new_popups.append(input_method)

        return new_popups

    def _get_animations_frames(
        self,
        popups: list[KeyboardPopupData],
        start_time: int,
        end_time: int,
    ):
        """
        获取动效帧间隔
        InsetsAnimation:
        InsetsAsyncAnimation: InsetsAnimation线程的animation间隔
        """
        actual_timeline_upid = None

        for input_method_popup in popups:
            if input_method_popup.animator_type not in [
                "InsetsAnimation: ime",
                "InsetsAsyncAnimation: ime",
            ]:
                continue

            animator_ts, animator_te = input_method_popup.animator_time
            if animator_ts == -1 or animator_te == -1:
                continue

            # 获取动画帧率
            animator_fps = self._get_fps(animator_ts, animator_te)
            input_method_popup.animator_fps = animator_fps

            input_method_popup_timelines = None
            try:
                if input_method_popup.animator_type == "InsetsAnimation: ime":
                    if input_method_popup.upid == -1:
                        self.logger.e(
                            f"{input_method_popup.package_name} 缺少 upid，无法创建 Actual Timeline 表"
                        )
                        continue

                    if actual_timeline_upid != input_method_popup.upid:
                        try:
                            self.table_handler.table_launcher_actual_timelines(
                                input_method_popup.upid, start_time, end_time
                            )
                            self.table_handler.table_sf_actual_timelines()
                            actual_timeline_upid = input_method_popup.upid
                        except Exception as e:
                            self.logger.e(
                                f"创建 InsetsAnimation 表失败：{e}",
                            )
                            continue

                    range_sql = self.sqls.query_range_timelines(
                        start_time=animator_ts, end_time=animator_te
                    )
                    input_method_popup_timelines = self.tp.query(range_sql)

                elif input_method_popup.animator_type == "InsetsAsyncAnimation: ime":
                    sql = self.sqls.input_method_insert_async_animation_frames(
                        process_name=input_method_popup.package_name,
                        start_time=animator_ts,
                        end_time=animator_te,
                    )
                    input_method_popup_timelines = self.tp.query(sql)

                    # 将 slice_te 列重命名为 sf_te，以便与后续的通用逻辑兼容
                    if not input_method_popup_timelines.empty:
                        input_method_popup_timelines = (
                            input_method_popup_timelines.rename(
                                columns={"slice_te": "sf_te"}
                            )
                        )
                else:
                    self.logger.e(
                        f"未知的 input_method_popup.animator_type: {input_method_popup.animator_type}"
                    )
                    continue

                if input_method_popup_timelines.empty:
                    self.logger.w(
                        f"该次 {input_method_popup.package_name} 的 actual timelines 为空",
                    )
                    continue

            except Exception as e:
                self.logger.e(
                    f"获取 {input_method_popup.package_name} actual timelines 失败：{e}",
                )
                continue

            if input_method_popup.animator_type == "InsetsAsyncAnimation: ime":
                # Async 场景没有 UI/SF frame timeline 关联，用 InsetsAnimation 线程上的
                # animation slice 起点间隔作为帧间隔，保持与历史 AnalyseIme.py 逻辑一致。
                input_method_popup_timelines["diff"] = input_method_popup_timelines[
                    "slice_ts"
                ] - input_method_popup_timelines["slice_ts"].shift(1)
            else:
                input_method_popup_timelines["diff"] = input_method_popup_timelines[
                    "sf_te"
                ] - input_method_popup_timelines["sf_te"].shift(1)

            input_method_popup_timelines = input_method_popup_timelines.loc[
                input_method_popup_timelines["diff"] != 0
            ]
            input_method_popup_timelines["diff"] = (
                input_method_popup_timelines["diff"]
                .apply(lambda x: x / 1000000)
                .fillna(0)
            )

            # 响应时间
            if (
                input_method_popup.deliver_ts != -1
                and not input_method_popup_timelines.empty
            ):
                first_sf_ts = input_method_popup_timelines.iloc[0]["sf_te"]
                input_method_popup.response_time = int(
                    (first_sf_ts - input_method_popup.deliver_ts) / 1e6
                )

            input_method_popup.animation_frames = [
                round(x, 2) for x in input_method_popup_timelines["diff"].tolist()
            ]

    def _get_fps(self, start_time, end_time):
        """根据vsync-sf推荐动画范围内的帧率和帧间隔"""
        vsync_sql = self.sqls.query_vsync_sf(start_time, end_time)
        vsync_df = self.tp.query(vsync_sql)

        if vsync_df.empty or "ts" not in vsync_df.columns or len(vsync_df) < 2:
            return 0

        timestamps = vsync_df["ts"].to_numpy(dtype="int64")
        durations = np.diff(timestamps) / 1e6  # ns -> ms

        # 3. 预定义分级阈值
        FPS_BINS = [
            (175, 185),
            (150, 165),
            (130, 144),
            (100, 120),
            (70, 90),
            (44, 60),
            (0, 30),
        ]

        # 4. 快速分箱统计
        hist = np.zeros(len(FPS_BINS), dtype=int)
        fps_values = 1000 / durations

        for i, (lower, _) in enumerate(FPS_BINS):
            if i == 0:
                mask = fps_values >= lower
            else:
                prev_lower = FPS_BINS[i - 1][0]
                mask = (fps_values >= lower) & (fps_values < prev_lower)
            hist[i] = np.sum(mask)

        # 5. 快速确定主频段
        dominant_idx = np.argmax(hist)
        target_fps = FPS_BINS[dominant_idx][1]
        return target_fps
