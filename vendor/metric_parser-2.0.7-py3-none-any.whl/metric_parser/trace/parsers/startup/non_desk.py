"""
非桌面应用启动响应/应用启动动效分析模块

功能说明:
- 测量非桌面场景（如相机启动相册、微信启动小程序）的启动响应和动效
- 继承自 StartupTransition，复用底层 Trace 解析逻辑

版本: v1.1.0
"""

from metric_parser.trace.base.registry import AnalyseRegistry
from metric_parser.trace.models.start_transition_data import StartupAnalyseState
from metric_parser.trace.parsers.startup.transition import StartupTransition


@AnalyseRegistry.register("non_desk_start")
class NonDeskStart(StartupTransition):
    """非桌面应用启动响应/应用启动动效分析模块"""

    def analyse(self, from_app=None, start=None, end=None, **kwargs):
        """返回非桌面启动的响应、耗时、动效、线程状态等"""

        # 强制要求输入 from_app
        if not from_app:
            self.logger.e("非桌面启动必须明确指定启动所在的app (from_app)")
            return self.fail("缺少 from_app 参数，非桌面启动必须指定起始进程")

        # 调用父类的 analyse，它会自动调用当前类重写的 _analyse_internal，并统一封装返回格式
        return super().analyse(from_app=from_app, start=start, end=end, **kwargs)

    def _analyse_internal(
        self, from_app: str | None, start: int | None, end: int | None
    ) -> list[StartupAnalyseState]:
        """重写内部解析流程，按需裁剪不需要的步骤"""

        startup_states: list[StartupAnalyseState] = []

        # 1. 获取实际的分析时间范围
        actual_start_time, actual_end_time = self._validate_time_range(start, end)
        if actual_start_time is None or actual_end_time is None:
            raise ValueError("获取trace检测时间段失败")

        # 2. 获取 from_app 的 upid
        from_upid_sql = self.sqls.query_process_upid(process_name=from_app)
        from_upid_data = self.tp.query(from_upid_sql)
        from_app_upid = (
            int(from_upid_data.iloc[0]["upid"]) if not from_upid_data.empty else -1
        )
        if from_app_upid == -1:
            raise ValueError(f"获取 {from_app} upid失败")

        # 3. 获取本次启动的包名列表
        startup_states = self._get_launching_pkgs(actual_start_time, actual_end_time)
        if not startup_states:
            return startup_states

        # 4. 获取触控时间戳
        startup_states = self._get_deliver_input(
            startup_states, from_app, actual_start_time, actual_end_time
        )

        # 5. 获取启动类型
        self._get_start_type(startup_states, actual_start_time, actual_end_time)

        # 6. 获取动画起止时间戳
        self._get_animator_time(startup_states, actual_end_time)

        # 7. 输入事件的修正
        startup_states = self._correct_iq_input(startup_states)

        # 8. 获取起始应用的帧间隔 (复用 launcher_view_frames 逻辑)
        self._get_launcher_view_frames(
            startup_states, from_app_upid, actual_start_time, actual_end_time
        )

        # 9. 获取启动耗时 (内部会调用 _get_thread_states)
        self._get_startup_spend(startup_states)

        return startup_states
