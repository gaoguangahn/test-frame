"""
应用内点击延迟分析模块

功能说明:
- 测量从触摸事件到UI响应的完整处理链路耗时
- 支持时间段单次点击场景分析

版本: v1.1.0
"""

from pathlib import Path

import yaml

from metric_parser.trace.base.base_analyser import BaseTraceAnalyse
from metric_parser.trace.base.constants import HonorMachines
from metric_parser.trace.base.registry import AnalyseRegistry
from metric_parser.trace.base.sqls import SqlFactory
from metric_parser.trace.models.click_transition_data import (
    ClickTransitionData,
    ClickTransitionResult,
)
from metric_parser.trace.parsers.utils.thread_state import StateQuery
from metric_parser.trace.parsers.utils.util import is_all_none


@AnalyseRegistry.register("click_transition")
class ClickTransition(BaseTraceAnalyse):
    """获取应用内转场时间"""

    def __init__(self, context):
        super().__init__(context)
        self.state_query = StateQuery(self.tp)
        self.sqls = SqlFactory.get_sql_class(self.device_brand)

        # 加载白名单
        config_path = (
            Path(__file__).resolve().parent.parent.parent
            / "configs"
            / "click_whitelist.yaml"
        )

        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}
            self.white_list = config.get("white_list", [])
        except Exception as e:
            self.logger.w(f"加载白名单失败: {e}")
            self.white_list = []

    def analyse(self, start=None, end=None, **kwargs):
        """统一的对外分析接口，返回应用内点击的相关信息"""

        try:
            transitions = self._analyse_internal(start, end)
        except Exception as e:
            self.logger.e(f"应用内点击分析失败: {e}")
            return self.fail(f"应用内点击分析失败: {e}")

        results: list[ClickTransitionResult] = []
        for transition in transitions:
            if transition.transition_time < 0:
                continue

            results.append(
                ClickTransitionResult(
                    new_activity=transition.new_activity,
                    new_process=transition.new_process or "unknown",
                    op_start=start if start else transition.deliver_ts,
                    startup_type=transition.startup_type or "unknown",
                    launching_dur=round(
                        (transition.launching_te - transition.launching_ts) / 1e6, 2
                    ),
                    response_time=transition.transition_time,
                    thread_state=transition.thread_state,
                )
            )

        return self.success(results)

    def _analyse_internal(
        self, start_time: int | None, end_time: int | None
    ) -> list[ClickTransitionData]:
        """获取应用内点击响应的相关metric"""

        # 解析/校验时间范围（使用父类统一逻辑）
        actual_start_time, actual_end_time = self._validate_time_range(
            start_time, end_time
        )
        if actual_start_time is None or actual_end_time is None:
            raise ValueError("获取trace检测时间段失败")

        # 1) 识别 activity 启动
        transitions = self._get_launching_activity(
            start_time=actual_start_time, end_time=actual_end_time
        )

        if not transitions:
            self.logger.w("未找到Activity跳转")
            return []

        # 2) 获取 deliverInputEvent
        self._get_deliver_input(transitions, start_time=actual_start_time)

        # 3) 获取 start_type
        self._get_start_type(transitions)

        # 4) 提前响应时间
        for transition in transitions:
            launching_dur = (transition.launching_te - transition.launching_ts) / 1e6
            final_dur = launching_dur
            calc_start_ts = transition.launching_ts
            calc_end_ts = transition.launching_te

            # 仅荣耀机型 且 在白名单中的应用，执行 wmshell 首帧修正逻辑
            if (
                self.device_brand in HonorMachines.HONOR_BRANDS
                and transition.new_process in self.white_list
            ):
                self._get_wmshell_first_time(transition, end_time=actual_end_time)

                if transition.wmframe_sf_te > transition.deliver_ts:
                    wmframe_dur = (
                        transition.wmframe_sf_te - transition.deliver_ts
                    ) / 1e6
                    if wmframe_dur < launching_dur:
                        final_dur = wmframe_dur
                        calc_start_ts = transition.deliver_ts
                        calc_end_ts = transition.wmframe_sf_te

            # 所有机型通用的赋值
            transition.transition_time = int(final_dur)
            transition.thread_state = self._get_thread_states(
                transition.new_upid, calc_start_ts, calc_end_ts
            )

        return transitions

    def _get_launching_activity(
        self, start_time: int, end_time: int
    ) -> list[ClickTransitionData]:
        """
        判断本次点击有没有启动新的 activity，并尽量确定主进程
        依赖 table_handler.table_activity_startups() 已创建 android_activity_startups_raw
        """

        transitions: list[ClickTransitionData] = []

        # 建表android_activity_startups_raw，储存所有的activity启动信息，有应用启动和同进程点击
        try:
            self.table_handler.table_activity_startups()
        except Exception as e:
            self.logger.e(f"构建 android_activity_startups_raw 失败: {e}")
            return transitions

        # 范围内首个 activity 启动信息，限制下LIMIT 1，多任务点击
        sql = self.sqls.query_activity_start(start_time=start_time, end_time=end_time)
        activity_start_df = self.tp.query(sql)

        if activity_start_df.empty:
            self.logger.d("没有识别到activity启动")
            return transitions

        for idx, activity in activity_start_df.iterrows():
            # 记录首条启动时间
            launching_ts = int(activity["ts"])
            launching_te = int(activity["ts_end"])
            package = activity.get("package")
            startup_type = activity.get("startup_type")

            if not package:
                self.logger.w("无法确定进程名，终止解析")
                continue

            # performResume查询，根据包名模糊查询
            perform_resume_sql = self.sqls.query_click_activity_resume_name(
                start_time=launching_ts, end_time=launching_te, package=package
            )

            resume_df = self.tp.query(perform_resume_sql)
            if resume_df.empty:
                self.logger.w("没有识别到 performResume")
                continue

            # 取第一条
            first_resume = resume_df.iloc[0]
            new_utid = first_resume.get("utid", -1)
            new_upid = first_resume.get("upid", -1)
            resume_ts = first_resume.get("slice_ts", -1)
            resume_te = first_resume.get("slice_te", -1)
            resume_name = first_resume["slice_name"]

            # 形如 "performResume:com.xxx.Activity"
            if isinstance(resume_name, str) and ":" in resume_name:
                new_activity = resume_name.split(":", 1)[1]
            else:
                new_activity = resume_name or ""
            new_process = first_resume.get("process_name", None)

            transitions.append(
                ClickTransitionData(
                    name=resume_name,
                    startup_type=startup_type,
                    new_process=new_process,
                    new_utid=new_utid,
                    new_upid=new_upid,
                    launching_ts=launching_ts,
                    launching_te=launching_te,
                    resume_ts=resume_ts,
                    resume_te=resume_te,
                    new_activity=new_activity,
                )
            )

        return transitions

    def _get_deliver_input(
        self, transitions: list[ClickTransitionData], start_time: int
    ):
        """获取输入事件的时间戳（deliverInputEvent）"""

        for transition in transitions:
            if transition.resume_ts == -1 or transition.new_process is None:
                continue

            start_ts = start_time
            end_ts = transition.launching_ts

            deliver_sql = self.sqls.query_all_deliver(
                start_time=start_ts, end_time=end_ts
            )
            deliver_data = self.tp.query(deliver_sql)
            if deliver_data.empty:
                self.logger.w("没有找到 deliverInputEvent")
                return

            # 使用最后一条作为最近的点击
            transition.deliver_ts = int(deliver_data.iloc[-1]["slice_ts"])
            transition.deliver_te = int(deliver_data.iloc[-1]["slice_te"])

        return

    def _get_start_type(self, transitions: list[ClickTransitionData]):
        """获取启动类型"""
        for transition_data in transitions:
            if transition_data.startup_type is not None:
                continue

            package_name = transition_data.new_process
            upid = transition_data.new_upid
            prev_te = transition_data.deliver_te
            cur_te = transition_data.launching_te

            if prev_te == -1 or cur_te <= prev_te:
                continue

            # 1. 查询是否有新建线程或app初始化 (Cold)
            start_proc = self.tp.query(
                self.sqls.query_start_proc(package_name, prev_te, cur_te)
            )
            bind_app = self.tp.query(
                self.sqls.query_bind_application(upid, prev_te, cur_te)
            )

            if (not start_proc.empty and not is_all_none(start_proc.columns)) or (
                not bind_app.empty and not is_all_none(bind_app.columns)
            ):
                transition_data.startup_type = "cold"
                continue

            # 2. 查询是否有 activity 新建 (Warm)
            activity_start = self.tp.query(
                self.sqls.query_activity_start_slice(upid, prev_te, cur_te)
            )
            if not activity_start.empty and not is_all_none(activity_start.columns):
                transition_data.startup_type = "warm"
                continue

            # 3. 查询是否有 activity resume (Hot)
            activity_resume = self.tp.query(
                self.sqls.query_activity_resume_slice(upid, prev_te, cur_te)
            )
            if not activity_resume.empty and not is_all_none(activity_resume.columns):
                transition_data.startup_type = "hot"
            else:
                transition_data.startup_type = "unknown"

    def _get_wmshell_first_time(self, transition: ClickTransitionData, end_time: int):
        """白名单内的应用，首帧时间用 wmshell 的 doframe"""
        if not transition.new_process or transition.deliver_te == -1:
            return

        first_doframe_sql = self.sqls.query_thread_first_frame(
            thread_name=self.sqls.wmshell_anim,
            start_time=transition.deliver_te,
            end_time=end_time,
        )
        first_doframe_data = self.tp.query(first_doframe_sql)

        if first_doframe_data.empty or is_all_none(first_doframe_data):
            self.logger.w("未找到wmshell.anim的非-1 doframe")
            return

        target_frame = first_doframe_data.iloc[0]
        doframe_name = target_frame["doframe_name"]
        doframe_id = doframe_name.split(" ")[-1]

        if int(doframe_id) == -1:
            return

        match_timeline_sql = self.sqls.query_same_name_timeline(
            frame_id=doframe_id, start_time=transition.deliver_te, end_time=end_time
        )
        match_timeline_data = self.tp.query(match_timeline_sql)

        if match_timeline_data.empty or is_all_none(match_timeline_data):
            self.logger.w("未找到wmshell.anim的对应timeline")
            return

        timeline_id = match_timeline_data.iloc[0]["id"]
        sf_map_sql = self.sqls.frame_token_map(slice_id=timeline_id)
        sf_map_data = self.tp.query(sf_map_sql)

        if sf_map_data.empty or is_all_none(sf_map_data):
            self.logger.w("未找到wmshell.anim的对应sf timeline")
            return

        target_df = sf_map_data.iloc[0]
        transition.wmframe_sf_ts = target_df["UISliceStartTs"]
        transition.wmframe_sf_te = target_df["UISliceEndTs"]

    def _get_thread_states(self, upid, start_ts, end_ts):
        """获取线程在启动过程中的状态"""

        try:
            thread_state_dict = self.state_query.startup_thread_state(
                upid, start_ts, end_ts
            )
        except Exception as e:
            self.logger.e(
                f"获取线程状态失败 upid={upid}, start={start_ts}, end={end_ts}: {e}",
            )
            return {}
        return thread_state_dict

    @staticmethod
    def normalize_pkg(p: str) -> str:
        if not isinstance(p, str) or not p:
            return ""
        # 去除首尾空格与引号，过滤子进程名（":xxx"）
        p = p.strip().strip('"').strip("'")
        if ":" in p:
            # 只取主进程前缀
            p = p.split(":", 1)[0]
        return p
