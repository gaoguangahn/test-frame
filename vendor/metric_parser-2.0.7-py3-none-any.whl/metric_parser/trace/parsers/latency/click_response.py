"""
应用内点击延迟分析模块

功能说明:
- 测量从触摸事件到UI响应的完整处理链路耗时
- 支持时间段单次点击场景分析

版本: v1.1.0
"""

from pathlib import Path

import yaml

from metric_parser.trace.base.base_analyser import BaseTraceAnalyse
from metric_parser.trace.base.registry import AnalyseRegistry
from metric_parser.trace.base.sqls import SqlFactory
from metric_parser.trace.models.click_response_data import (
    ClickResponseData,
    ClickResponseResult,
)
from metric_parser.trace.parsers.utils.thread_state import StateQuery
from metric_parser.trace.parsers.utils.util import is_all_none


@AnalyseRegistry.register("click_response")
class ClickResponse(BaseTraceAnalyse):
    """获取应用内点击的响应时间"""

    def __init__(self, context):
        super().__init__(context)

        self.state_query = StateQuery(self.tp)
        self.sqls = SqlFactory.get_sql_class(self.device_brand)

        # 加载白名单
        config_path = (
            Path(__file__).resolve().parent.parent.parent
            / "configs"
            / "click_whitelist.yaml"
        )

        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config = yaml.safe_load(f) or {}
            self.white_list = config.get("white_list", [])
        except Exception as e:
            self.logger.w(f"加载白名单失败: {e}")
            self.white_list = []

    def analyse(self, start=None, end=None, **kwargs):
        """返回应用内点击的相关信息"""

        try:
            clicks = self._analyse_internal(start, end)
        except Exception as e:
            self.logger.e(f"应用内点击响应分析失败: {e}")
            return self.fail(f"应用内点击响应分析失败: {e}")

        # 组装强类型返回结果
        results: list[ClickResponseResult] = []
        for click in clicks:
            if click.response_time < 0:
                continue
            if click.new_process is not None:
                results.append(
                    ClickResponseResult(
                        new_activity=click.new_activity,
                        new_process=click.new_process,
                        op_start=start if start else click.deliver_te,
                        startup_type=click.startup_type or "unknown",
                        launching_dur=round(
                            (click.launching_te - click.launching_ts) / 1e6, 2
                        ),
                        response_time=click.response_time,
                        thread_state=click.thread_state,
                    )
                )

        return self.success(results)

    def _analyse_internal(
        self, start_time: int | None, end_time: int | None
    ) -> list[ClickResponseData]:
        """获取应用内点击响应的相关metric"""

        # 解析/校验时间范围
        actual_start_time, actual_end_time = self._validate_time_range(
            start_time, end_time
        )
        if actual_start_time is None or actual_end_time is None:
            self.logger.e("获取trace检测时间段失败")
            raise ValueError("获取trace检测时间段失败")

        # 1) 识别 activity 启动（如有）
        clicks = self._get_launching_activity(
            start_time=actual_start_time, end_time=actual_end_time
        )

        # 必须确定 process，后续查询依赖
        if not clicks:
            self.logger.w("未找到点击Activity跳转")
            return clicks

        # 2) 获取 deliverInputEvent
        self._get_deliver_input(clicks, start_time=actual_start_time)

        # 3) 获取 start_type
        self._get_start_type(clicks)

        # 4) 首帧完成时间
        for click in clicks:
            if click.new_process in self.white_list:
                self._get_wmshell_first_time(click, end_time=actual_end_time)
            else:
                self._get_first_time(click, end_time=actual_end_time)

        return clicks

    def _get_launching_activity(
        self, start_time: int, end_time: int
    ) -> list[ClickResponseData]:
        """判断本次点击有没有启动新的 activity，并尽量确定主进程"""
        clicks: list[ClickResponseData] = []

        try:
            self.table_handler.table_activity_startups()
        except Exception as e:
            self.logger.e(f"构建 android_activity_startups_raw 失败: {e}")
            return clicks

        sql = self.sqls.query_activity_start(start_time=start_time, end_time=end_time)
        activity_start_df = self.tp.query(sql)

        if activity_start_df.empty:
            self.logger.d("没有识别到activity启动")
            return clicks

        for idx, activity in activity_start_df.iterrows():
            launching_ts = int(activity["ts"])
            launching_te = int(activity["ts_end"])
            package = activity.get("package")
            startup_type = activity.get("startup_type")

            if not package:
                self.logger.w("无法确定进程名，终止解析")
                continue

            perform_resume_sql = self.sqls.query_click_activity_resume_name(
                start_time=launching_ts, end_time=launching_te, package=package
            )

            resume_df = self.tp.query(perform_resume_sql)
            if resume_df.empty:
                self.logger.w("没有识别到 performResume")
                continue

            first_resume = resume_df.iloc[0]
            new_utid = first_resume.get("utid", -1)
            new_upid = first_resume.get("upid", -1)
            resume_ts = first_resume.get("slice_ts", -1)
            resume_te = first_resume.get("slice_te", -1)
            resume_name = first_resume["slice_name"]

            if isinstance(resume_name, str) and ":" in resume_name:
                new_activity = resume_name.split(":", 1)[1]
            else:
                new_activity = resume_name or ""
            new_process = first_resume.get("process_name", None)

            click_data = ClickResponseData(
                name=resume_name,
                startup_type=startup_type,
                new_process=new_process,
                new_utid=new_utid,
                new_upid=new_upid,
                launching_ts=launching_ts,
                launching_te=launching_te,
                resume_ts=resume_ts,
                resume_te=resume_te,
                new_activity=new_activity,
            )
            clicks.append(click_data)

        return clicks

    def _get_deliver_input(self, clicks: list[ClickResponseData], start_time: int):
        """获取输入事件的时间戳（deliverInputEvent）"""
        self._get_deliver_process(clicks, start_time=start_time)

        for click in clicks:
            if click.resume_ts == -1 or click.new_process is None:
                continue

            click_process = click.click_process
            start_ts = start_time
            end_ts = click.launching_ts

            deliver_sql = self.sqls.query_deliver_input(
                process_name=click_process, start_time=start_ts, end_time=end_ts
            )
            deliver_data = self.tp.query(deliver_sql)
            if deliver_data.empty:
                self.logger.w("没有找到 deliverInputEvent")
                continue

            deliver_te = int(deliver_data.iloc[-1]["slice_te"])
            if end_ts - deliver_te >= 2000_000_000:
                continue
            click.deliver_te = deliver_te

    def _get_deliver_process(self, clicks: list[ClickResponseData], start_time: int):
        def query_deliver_process(start_ts, end_ts):
            handle_sql = self.sqls.get_deliver_process(start_ts=start_ts, end_ts=end_ts)
            handle_df = self.tp.query(handle_sql)
            if not handle_df.empty:
                return handle_df.iloc[-1]["process_name"]
            return None

        for click in clicks:
            if click.resume_ts == -1 or click.new_process is None:
                continue

            start_inner_sql = self.sqls.query_start_activity_inner(
                click.launching_ts, click.launching_te
            )
            start_inner_df = self.tp.query(start_inner_sql)

            if start_inner_df.empty:
                process_name = query_deliver_process(start_time, click.launching_ts)
                if process_name:
                    click.click_process = process_name
                else:
                    click.click_process = click.new_process
                    self.logger.d("启动范围内未找到 startActivityInner")
                continue

            start_activity_ts = start_inner_df.iloc[0]["slice_ts"]
            start_activity_te = start_inner_df.iloc[0]["slice_te"]
            start_activity_utid = start_inner_df.iloc[0]["utid"]

            binder_sql = self.sqls.get_binder_source_process(
                start_activity_ts, start_activity_te, start_activity_utid
            )
            binder_df = self.tp.query(binder_sql)

            if not binder_df.empty:
                click.click_process = binder_df.iloc[0]["process_name"]
            else:
                process_name = query_deliver_process(start_time, click.launching_ts)
                if process_name:
                    click.click_process = process_name
                else:
                    click.click_process = click.new_process
                    self.logger.d("启动范围内未找到 binder source process")

    def _get_start_type(self, clicks: list[ClickResponseData]):
        """获取启动类型"""
        for click_data in clicks:
            if click_data.startup_type is not None:
                continue
            package_name = click_data.new_process
            upid = click_data.new_upid

            prev_te = click_data.deliver_te
            cur_te = click_data.launching_te
            if prev_te == -1 or cur_te <= prev_te:
                continue

            start_proc_sql = self.sqls.query_start_proc(
                process_name=package_name, start_time=prev_te, end_time=cur_te
            )
            start_proc = self.tp.query(start_proc_sql)

            bind_app_sql = self.sqls.query_bind_application(
                upid=upid, start_time=prev_te, end_time=cur_te
            )
            bind_app = self.tp.query(bind_app_sql)

            if (not start_proc.empty and not is_all_none(start_proc.columns)) or (
                not bind_app.empty and not is_all_none(bind_app.columns)
            ):
                click_data.startup_type = "cold"
            else:
                activity_start_sql = self.sqls.query_activity_start_slice(
                    upid=upid, start_time=prev_te, end_time=cur_te
                )
                activity_start = self.tp.query(activity_start_sql)
                if not activity_start.empty and not is_all_none(activity_start.columns):
                    click_data.startup_type = "warm"
                else:
                    activity_resume_sql = self.sqls.query_activity_resume_slice(
                        upid=upid, start_time=prev_te, end_time=cur_te
                    )
                    activity_resume = self.tp.query(activity_resume_sql)
                    if not activity_resume.empty and not is_all_none(
                        activity_resume.columns
                    ):
                        click_data.startup_type = "hot"
                    else:
                        click_data.startup_type = "unknown"

    def _get_first_time(self, click: ClickResponseData, end_time: int):
        """获取首帧完成时间（ns）"""
        if (
            not click.new_process
            or click.deliver_te == -1
            or click.new_utid == -1
            or click.resume_te == -1
        ):
            return

        thread_filter = f"AND thread.utid = {click.new_utid}"

        do_frames_sql = self.sqls.query_process_timeline(
            process_name=click.new_process,
            start_time=click.resume_te,
            end_time=end_time,
            thread_filter=thread_filter,
        )

        do_frames_data = self.tp.query(do_frames_sql)
        if do_frames_data.empty or is_all_none(do_frames_data):
            self.logger.w("启动范围内未找到帧的绘制")
            return

        target_frame = do_frames_data.iloc[0]
        target_name = target_frame["slice_name"]

        filtered_frames = do_frames_data.loc[
            do_frames_data["slice_name"] == target_name
        ]

        same_name_frames = filtered_frames.sort_values(
            by=["slice_dur"],
            ascending=False,
        )

        target_frame = same_name_frames.iloc[0]
        target_frame_te = target_frame["slice_te"]
        click.first_frame = target_frame_te
        click.response_time = round((target_frame_te - click.deliver_te) / 1_000_000, 2)

        click.thread_state = self._get_thread_states(
            click.new_upid, click.deliver_te, target_frame_te
        )

    def _get_wmshell_first_time(self, click: ClickResponseData, end_time: int):
        """白名单内的应用，首帧时间用 wmshell 的 doframe"""
        if not click.new_process or click.deliver_te == -1:
            return

        first_doframe_sql = self.sqls.query_thread_first_frame(
            thread_name=self.sqls.wmshell_anim,
            start_time=click.deliver_te,
            end_time=end_time,
        )
        first_doframe_data = self.tp.query(first_doframe_sql)

        if first_doframe_data.empty or is_all_none(first_doframe_data):
            self.logger.w("未找到wmshell.anim的非-1 doframe")
            return

        target_frame = first_doframe_data.iloc[0]
        doframe_name = target_frame["doframe_name"]
        doframe_id = doframe_name.split(" ")[-1]

        if int(doframe_id) == -1:
            return

        match_timeline_sql = self.sqls.query_same_name_timeline(
            frame_id=doframe_id, start_time=click.deliver_te, end_time=end_time
        )
        match_timeline_data = self.tp.query(match_timeline_sql)

        if match_timeline_data.empty or is_all_none(match_timeline_data):
            self.logger.w("未找到wmshell.anim的对应timeline")
            return

        timeline_id = match_timeline_data.iloc[0]["id"]
        sf_map_sql = self.sqls.frame_token_map(slice_id=timeline_id)
        sf_map_data = self.tp.query(sf_map_sql)

        if sf_map_data.empty or is_all_none(sf_map_data):
            self.logger.w("未找到wmshell.anim的对应sf timeline")
            return

        target_df = sf_map_data.iloc[0]
        target_sf_te = target_df["UISliceEndTs"]

        click.response_time = round((target_sf_te - click.deliver_te) / 1_000_000, 2)
        click.thread_state = self._get_thread_states(
            click.new_upid, click.deliver_te, target_sf_te
        )

    def _get_thread_states(self, upid, start_ts, end_ts):
        """获取线程在启动过程中的状态"""
        try:
            thread_state_dict = self.state_query.startup_thread_state(
                upid, start_ts, end_ts
            )
        except Exception as e:
            self.logger.e(
                f"获取线程状态失败 upid={upid}, start={start_ts}, end={end_ts}: {e}",
            )
            return {}
        return thread_state_dict

    @staticmethod
    def normalize_pkg(p: str) -> str:
        if not isinstance(p, str) or not p:
            return ""
        p = p.strip().strip('"').strip("'")
        if ":" in p:
            p = p.split(":", 1)[0]
        return p
