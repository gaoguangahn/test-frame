"""
应用内滑动动效分析的工具类

版本: v1.1.0
"""

import math
import re

import pandas as pd

from metric_parser.trace.base.trace_processor_handler import TraceProcessorHandler
from metric_parser.utils.logger import ParseLogger


class SwipeParserUtils:
    """
    解析滑动trace的一些通用方法
    """

    def __init__(self, tp: TraceProcessorHandler):
        self.logger = ParseLogger("SwipeCommonMethods")
        self.tp = tp

    def get_pkg_info(self, package=None, activity=None, start_ts=None, end_ts=None):
        """
        获取滑动trace对应包名，activity名信息
        不允许没有包名、但是有activity的情况
        """
        package_name, activity_name, process_name, bufferTx = (
            package,
            activity,
            None,
            None,
        )

        if package and activity:
            where_clause = f" WHERE ct.name like 'BufferTX - %{package}/{activity}%#%'"
        elif package and not activity:
            # 部分界面只有package信息，没有activity信息
            where_clause = f" WHERE ct.name like 'BufferTX - %{package}%#%'"
        elif activity and not package:
            self.logger.e("没有包名信息，无法获取信息")
            return package_name, activity_name, process_name, bufferTx
        else:
            # 两条信息都缺失
            where_clause = " WHERE ct.name like 'BufferTX -%/%#%'"

        # 如果有时间范围，拼接时间条件
        time_condition = ""
        if start_ts is not None and end_ts is not None:
            time_condition = f" AND c.ts BETWEEN {start_ts} AND {end_ts}"

        # 查出时间范围内的满足格式的拥有最多buffer的那一条bufferTx
        sql = f"""
            SELECT ct.id, ct.name, ct.type, COUNT(c.id) AS counter_count
            FROM counter_track ct
            LEFT JOIN counter c ON c.track_id = ct.id
            {where_clause}
            {time_condition}
            GROUP BY ct.id, ct.name, ct.type
            ORDER BY counter_count DESC
            LIMIT 1
        """

        bufferTx_infos = self.tp.query(sql)

        if not bufferTx_infos.empty:
            bufferTx = bufferTx_infos.iloc[0]["name"]
        else:
            self.logger.w("未找到BufferTX相关包名信息")

            return (package_name, activity_name, process_name, bufferTx)

        try:
            # 去掉 "BufferTX - " 前缀
            name_part = bufferTx.replace("BufferTX - ", "", 1).strip()

            if name_part.startswith("VRI-"):
                name_part = name_part[4:]  # 截取掉 "VRI-" 这4个字符

            if "/" in name_part:
                # 有 activity
                package_part, activity_part = name_part.split("/", 1)
                package_name = re.split(r"#", package_part)[0].strip()
                activity_name = re.split(r"#", activity_part)[0].strip()
            else:
                # 只有 package
                package_name = re.split(r"#", name_part)[0].strip()
                activity_name = None
        except Exception:
            self.logger.e("解析BufferTX包名信息失败")

        if package_name:
            process_name_sql = f"""
                SELECT p.upid, p.name AS process_name, pk.package_name
                FROM process p
                JOIN package_list pk ON p.uid = pk.uid
                WHERE pk.package_name = '{package_name}'
            """
            process_name_infos = self.tp.query(process_name_sql)
            if process_name_infos.empty:
                process_name = package_name
            else:
                match = process_name_infos[
                    process_name_infos["process_name"] == package_name
                ]
                if not match.empty:
                    process_name = match.iloc[0]["process_name"]
                else:
                    process_name = process_name_infos.iloc[0]["process_name"]
        # 下面处理特殊情况
        if process_name == "com.hihonor.android.totemweather":
            process_name = "com.hihonor.android.totemweather:ui"

        return package_name, activity_name, process_name, bufferTx

    def get_buffer(
        self, package=None, activity=None, bufferTx=None, start_ts=None, end_ts=None
    ) -> tuple[pd.DataFrame, pd.DataFrame]:
        """
        根据传入的包名和activity，获取到对应的buffer信息
        """
        if bufferTx is None:
            if package and activity:
                where_clause = (
                    f" where track.name like 'BufferTX - {package}/{activity}%#%'"
                )
            elif package:
                where_clause = f" where track.name like 'BufferTX - {package}%#%'"
            else:
                self.logger.w("未提供 package/activity/bufferTx，无法获取 buffer 信息")
                return pd.DataFrame(), pd.DataFrame()

        else:
            where_clause = f" WHERE track.name like '{bufferTx}'"

        # 如果有时间范围，拼接时间条件
        time_condition = ""
        if start_ts is not None and end_ts is not None:
            time_condition = f" AND c.ts BETWEEN {start_ts} AND {end_ts}"

        sql = f"""
            SELECT c.ts, c.track_id, c.value, c.arg_set_id, process.name as pname, process.pid, track.name as tname
            FROM counter c
            JOIN process_counter_track as track ON c.track_id = track.id
            JOIN process ON process.upid = track.upid
            {where_clause}
            {time_condition}
            ORDER BY c.ts
        """
        buffer_counters = self.tp.query(sql)
        buffer_counters.loc[:, "diff"] = buffer_counters["value"] - buffer_counters[
            "value"
        ].shift(1)
        buffer_counters.loc[:, "diff"] = buffer_counters["diff"].fillna(0)
        # 取出buffer中被消费的value小于0的部分，即真正的buffer消耗，并计算间隔
        buffer_down_counters = buffer_counters[buffer_counters["diff"] < 0].copy()

        return buffer_counters, buffer_down_counters

    def get_deliverInput(
        self, process_name, upid, start_ts=None, end_ts=None
    ) -> pd.DataFrame:
        """
        获取包名所在进程的deliverInputEvent信息
        """
        package_delivers = {}
        if process_name:
            where_clause = f" AND p.name like '{process_name}' AND p.upid = {upid}"
        else:
            where_clause = ""
        # 如果有时间范围，拼接时间条件
        time_condition = ""
        if start_ts is not None and end_ts is not None:
            time_condition = f" AND s.ts BETWEEN {start_ts} AND {end_ts}"

        sql = f"""
            SELECT s.ts AS ts, s.name AS name, s.track_id, (s.ts + s.dur) AS te, s.depth as depth, p.name AS pname
            FROM slice s
            JOIN process_track AS track ON s.track_id = track.id 
            JOIN process p ON track.upid = p.upid
            WHERE track.name like 'deliverInputEvent'
            {where_clause}
            {time_condition}
            ORDER BY ts
        """
        sql_data = self.tp.query(sql)

        # if process_name:
        #     package_delivers[process_name] = sql_data
        # else:
        #     for track_id, delivers in sql_data.groupby('track_id'):
        #         pname = delivers.iloc[0]['pname']
        #         package_delivers[pname] = delivers

        return sql_data

    def get_pid_tid(self, process_name, start_ts=None, end_ts=None):
        """
        获取对应进程的pid，主线程tid等信息
        """
        upid, ui_utid, render_utid, sf_utid = -1, -1, -1, -1

        time_condition = ""
        if start_ts is not None and end_ts is not None:
            time_condition = f" AND slice.ts BETWEEN {start_ts} AND {end_ts}"

        # UI线程和进程ID
        ui_conditions = [
            f"WHERE process.pid = thread.tid and pname='{process_name}'",
            f"WHERE pname like '%{process_name}%' and slice.name like '%doFrame%'",
        ]

        ui_data = None
        for cond in ui_conditions:
            sql_ui = f"""
                SELECT thread.utid as utid, process.upid AS upid, process.name AS pname
                FROM slice
                JOIN thread_track ON slice.track_id = thread_track.id 
                JOIN thread ON thread_track.utid = thread.utid 
                JOIN process ON thread.upid = process.upid
                {cond}
                {time_condition}
                LIMIT 1
            """
            ui_data = self.tp.query(sql_ui)
            if not ui_data.empty:
                break
        if ui_data is not None and len(ui_data) > 0:
            upid, ui_utid = ui_data["upid"][0], ui_data["utid"][0]
        else:
            self.logger.e("未找到匹配的UI线程/进程，请检查包名或trace数据")
            return upid, ui_utid, render_utid, sf_utid

        # Render线程ID
        # 合并三种可能的条件
        render_conditions = [
            "WHERE slice.name LIKE 'eglSwapBuffersWithDamageKHR' AND thread.name = 'RenderThread'",
            "WHERE slice.name LIKE 'Vulkan finish frame'",
            "WHERE slice.name LIKE '%eglSwapBuffersWithDamageKHR%'",
            "WHERE slice.name LIKE '%eglSwapBuffers%'",
        ]
        render_data = None
        for cond in render_conditions:
            sql_render = f"""
                SELECT thread.utid as utid, process.upid AS upid, process.name AS pname
                FROM slice
                JOIN thread_track ON slice.track_id = thread_track.id 
                JOIN thread ON thread_track.utid = thread.utid 
                JOIN process ON thread.upid = process.upid
                {cond}
                {time_condition}
                 AND process.upid = {upid}
                LIMIT 1
            """
            render_data = self.tp.query(sql_render)
            if not render_data.empty:
                break
        if render_data is not None and len(render_data) > 0:
            render_utid = render_data["utid"][0]
        else:
            self.logger.e("未找到Render线程，请检查trace数据")
            render_utid = -1

        # SurfaceFlinger线程ID
        sf_conditions = [
            "WHERE thread.name = 'surfaceflinger' and process.pid = thread.tid",
            "WHERE pname like '%surfaceflinger%' and process.pid = thread.tid",
        ]

        sf_data = None
        for cond in sf_conditions:
            sql_sf = f"""
                SELECT thread.utid as utid, process.upid AS upid, process.name AS pname
                FROM slice
                JOIN thread_track ON slice.track_id = thread_track.id 
                JOIN thread ON thread_track.utid = thread.utid 
                JOIN process ON thread.upid = process.upid
                {cond}
                {time_condition}
                LIMIT 1
            """
            sf_data = self.tp.query(sql_sf)
            if not sf_data.empty:
                break
        if sf_data is not None and len(sf_data) > 0:
            sf_utid = sf_data["utid"][0]
        else:
            self.logger.e("未找到匹配的surfaceflinger线程，请检查包名或trace数据")
            sf_utid = -1

        return upid, ui_utid, render_utid, sf_utid

    def get_first_vsync_app(self, start_ts):
        """
        获取大于start_ts的第一帧vsync时间
        """
        sql = f"""
            SELECT counter.ts, counter.value
            FROM counter 
            JOIN process_counter_track as track ON counter.track_id = track.id 
            JOIN process ON process.upid = track.upid 
            WHERE track.name = 'VSYNC-app' 
             AND counter.ts >= {start_ts}
            ORDER BY counter.ts
            LIMIT 1
            """

        data = self.tp.query(sql)
        if not data.empty:
            first_vsync_app = data.iloc[0]["ts"]
        else:
            self.logger.e("未找到VSYNC-app时间戳，请检查trace数据")
            first_vsync_app = None

        return first_vsync_app

    def get_vsync_sf(self, start_ts=None, end_ts=None) -> pd.DataFrame:
        """
        获取VSYNC-sf时间戳序列，
        """
        # 如果有时间范围，拼接时间条件
        time_condition = ""
        if start_ts is not None and end_ts is not None:
            time_condition = f" AND counter.ts BETWEEN {start_ts} AND {end_ts}"

        sql = f"""
            SELECT counter.ts, counter.track_id, counter.value, process.name as pname, track.name 
            FROM counter 
            JOIN process_counter_track as track ON counter.track_id = track.id 
            JOIN process ON process.upid = track.upid 
            WHERE track.name = 'VSYNC-sf' 
            {time_condition}
            ORDER BY counter.ts
        """
        df_result = self.tp.query(sql)
        return df_result

    def get_vsync_app(self, start_ts=None, end_ts=None):
        """获取VSYNC-app时间戳序列"""
        # 如果有时间范围，拼接时间条件
        time_condition = ""
        if start_ts is not None and end_ts is not None:
            time_condition = f" AND counter.ts BETWEEN {start_ts} AND {end_ts}"

        sql = f"""
            SELECT counter.ts, counter.value, process.name as pname, track.name 
            FROM counter 
            JOIN process_counter_track as track ON counter.track_id = track.id 
            JOIN process ON process.upid = track.upid 
            WHERE track.name = 'VSYNC-app' 
            {time_condition}
            ORDER BY counter.ts
        """

        df_result = self.tp.query(sql)
        df_result["dur"] = df_result["ts"].shift(-1) - df_result["ts"]
        df_result["dur"] = df_result["dur"].fillna(df_result.iloc[0]["ts"] - start_ts)

        return df_result

    def get_vsync_sf_avg(self, start_ts=None, end_ts=None):
        """获取VSYNC-sf时间戳序列，并计算平均值"""
        # 如果有时间范围，拼接时间条件
        time_condition = ""
        if start_ts is not None and end_ts is not None:
            time_condition = f" AND counter.ts BETWEEN {start_ts} AND {end_ts}"

        sql = f"""
            SELECT counter.ts, counter.value, process.name as pname, track.name 
            FROM counter 
            JOIN process_counter_track as track ON counter.track_id = track.id 
            JOIN process ON process.upid = track.upid 
            WHERE track.name = 'VSYNC-sf' 
            {time_condition}
            ORDER BY counter.ts
        """

        df_result = self.tp.query(sql)
        if df_result.empty:
            return df_result, 8.33

        df_result["ts"] = pd.to_numeric(df_result["ts"], errors="coerce")
        df_result["dur"] = df_result["ts"].shift(-1) - df_result["ts"]

        safe_start_ts = float(start_ts) if start_ts else df_result.iloc[0]["ts"]
        df_result["dur"] = df_result["dur"].fillna(
            df_result.iloc[0]["ts"] - safe_start_ts
        )
        df_result["dur"] = pd.to_numeric(df_result["dur"], errors="coerce")
        df_result["dur"] /= 1e6

        # 过滤掉异常值（0~100ms以内视为有效刷新）
        valid_dur = df_result[(df_result["dur"] > 0) & (df_result["dur"] < 100)]["dur"]

        if not valid_dur.empty:
            rounded_dur = valid_dur.round(0)
            mode_int = rounded_dur.mode().iloc[0]
            vsync_sf_avg = round(valid_dur[rounded_dur == mode_int].mean(), 2)
        else:
            first_50 = df_result.head(50)
            dur_list_40 = first_50[(first_50["dur"] > 0) & (first_50["dur"] < 40)][
                "dur"
            ].tolist()

            if dur_list_40:
                vsync_sf_avg = round(sum(dur_list_40) / len(dur_list_40), 2)
            else:
                vsync_sf_avg = 8.33

        vsync_sf = df_result[["ts", "dur"]]

        return vsync_sf, vsync_sf_avg

    @staticmethod
    def get_fps_standards(vsync_sf_avg) -> tuple[int, float, float]:
        """帧率指标的计算"""
        fps = None

        if vsync_sf_avg >= 30:
            fps = 30
        elif vsync_sf_avg >= 16:
            fps = 60
        elif vsync_sf_avg >= 10:
            fps = 90
        elif vsync_sf_avg >= 8:
            fps = 120
        elif vsync_sf_avg >= 6.6:
            fps = 144
        elif vsync_sf_avg >= 6:
            fps = 165
        elif vsync_sf_avg >= 5:
            fps = 185
        else:
            fps = 185

        # 计算标准帧间隔和卡顿阈值
        frame_interval = round(1000.0 / fps, 2)
        jank_interval = round(frame_interval * 1.5, 2)

        return fps, frame_interval, jank_interval

    def get_length_slice(self, utid_list, start_ts, end_ts, threshold) -> bool:
        """查找tid_list中的线程是否存在长度大于等于threshold的 slice
        :param utid_list: 线程utid列表
        :param start_ts: 起始时间
        :param end_ts: 结束时间
        :param threshold: 长度阈值
        """

        threshold_ns = threshold * 1e6

        if utid_list:
            utid_str = ",".join(str(utid) for utid in utid_list)
        else:
            return False

        sql = f"""
            SELECT slice.ts, slice.dur
            FROM slice
            JOIN thread_track ON slice.track_id = thread_track.id 
            JOIN thread ON thread_track.utid = thread.utid 
            WHERE thread.utid in ({utid_str})
             AND slice.ts >= {start_ts} 
             AND slice.ts <= {end_ts}
             AND slice.dur >= {threshold}
            ORDER BY ts
            LIMIT 1
        """
        data = self.tp.query(sql)
        if not data.empty:
            return True
        return False

    def get_first_draw_frame(self, render_utid, start_ts):
        """查找tid_list中的线程是否存在长度大于等于threshold的 slice
        :param render_utid: 渲染线程utid
        :param start_ts: 起始时间
        """
        sql = f"""
            SELECT slice.ts, slice.dur
            FROM slice
            JOIN thread_track ON slice.track_id = thread_track.id 
            JOIN thread ON thread_track.utid = thread.utid 
            WHERE thread.utid = {render_utid}
             AND slice.ts >= {start_ts} 
             AND slice.name LIKE 'DrawFrame%'
            ORDER BY ts
            LIMIT 1
        """
        data = self.tp.query(sql)
        if data.empty:
            return None
        return data.iloc[0]["ts"]

    def error_trace(self, upid, ui_utid, render_utid) -> bool:
        """
        检查 RenderThread + UIThread 两个线程中 dur == -1 的 slice 总数，
        如果超过阈值则判定为无效 trace。
        """
        warning = False
        THRESHOLD = 30

        # 查询 RenderThread
        sql = f"""
            SELECT slice.dur
            FROM slice s
            JOIN thread_track ON slice.track_id = thread_track.id 
            JOIN thread ON thread_track.utid = thread.utid 
            JOIN process p ON thread.upid = p.upid
            WHERE p.upid = {upid} and thread.utid in ({render_utid}, {ui_utid})
             AND slice.dur = -1
            ORDER BY ts
        """
        data = self.tp.query(sql)

        # 统计 dur == -1 的数量
        invalid_count = len(data)

        if invalid_count > THRESHOLD:
            warning = True
        return warning

    def get_swipe_key(self, start_time, end_time):
        """获取时间范围内的滑动打点信息"""
        pairs = []

        sql = f"""
              SELECT ts, (ts + dur) AS te, name
              FROM slice
              WHERE
                (name = 'BeginFluencyDetect: FLING' OR name = 'EndFluencyDetect: FLING')
                AND ts >= {start_time}
                AND ts < {end_time}
              ORDER BY ts
        """
        data = self.tp.query(sql)

        for idx in range(len(data) - 1):
            current_name = data.iloc[idx]["name"]
            next_name = data.iloc[idx + 1]["name"]

            if (
                current_name == "BeginFluencyDetect: FLING"
                and next_name == "EndFluencyDetect: FLING"
            ):
                start_key = data.iloc[idx]["ts"]
                end_key = data.iloc[idx + 1]["te"]
                pairs.append((start_key, end_key))

        return pairs

    def get_TargetBuf(self, start_time, end_time, upid):
        """获取时间范围内的TargetBuf信息"""
        tgb_list = []

        sql = f"""
            SELECT 
             counter.ts, 
             counter.value, 
             LEAD(counter.ts) OVER (PARTITION BY counter.track_id ORDER BY counter.ts) AS te,
             pct.name
            FROM counter 
            JOIN process_counter_track AS pct on pct.id = counter.track_id 
            WHERE pct.name LIKE 'Targetbuf' 
             AND pct.upid = {upid}
             AND counter.ts >= {start_time} 
             AND counter.ts <= {end_time} 
            ORDER BY counter.ts
            """

        data = self.tp.query(sql)

        data["te"] = data["te"].fillna(end_time)
        # 筛选 value 大于 1 的记录
        filtered_data = data[data["value"] > 1].copy().reset_index(drop=True)
        # result = filtered_data[['ts', 'te', 'value']].values.tolist()

        return filtered_data

    def get_RVScroll(self, upid, utid, start_ts, end_ts):
        """
        查询UI线程中的所有RVScroll事件
        """

        sql = f"""
            SELECT slice.ts, slice.dur
            FROM slice
            JOIN thread_track ON slice.track_id = thread_track.id 
            JOIN thread ON thread_track.utid = thread.utid 
            JOIN process p ON thread.upid = p.upid
            WHERE p.upid = {upid} 
             AND thread.utid = {utid}
             AND slice.name = 'RV Scroll'
             AND slice.ts >= {start_ts} 
             AND slice.ts <= {end_ts}
            ORDER BY ts
        """
        data = self.tp.query(sql)

        # 计算 diff
        data["diff"] = data["ts"].diff().fillna(data["ts"] - start_ts) / 1e6

        return data

    def exist_RVScroll(self, upid, start_ts, end_ts):
        """
        判断有没有RVScroll参数
        """
        RVScroll_list = []
        if start_ts == 0 or end_ts == 0:
            self.logger.e("start_ts 或 end_ts 为 0，无法查询RVScroll参数")
            return False

        # 查询sql
        sql = f"""
            SELECT slice.ts, slice.dur, slice.name
            FROM slice
            JOIN thread_track ON slice.track_id = thread_track.id 
            JOIN thread ON thread_track.utid = thread.utid 
            JOIN process p ON thread.upid = p.upid
            WHERE p.upid = {upid} 
             AND thread.tid = p.pid
             AND slice.name LIKE 'RV Scroll'
             AND ts >= {start_ts} 
             AND ts <= {end_ts}
            ORDER BY ts
        """

        RV_Scroll = self.tp.query(sql)

        if not RV_Scroll.empty:
            return True

        return False

    def get_onscreen_ui_slices(self, upid, ui_utid, start_ts, end_ts):
        """获取对应deliver的ui线程的slice"""
        sql = f"""
             SELECT slice.ts, slice.dur, slice.name
             FROM slice
             JOIN thread_track ON slice.track_id = thread_track.id 
             JOIN thread ON thread_track.utid = thread.utid 
             JOIN process p ON thread.upid = p.upid
             WHERE p.upid = {upid} 
              AND thread.utid = {ui_utid}
              AND slice.name LIKE '%dt=%'
              AND slice.ts >= {start_ts} 
              AND slice.ts <= {end_ts}
             ORDER BY ts
         """

        data = self.tp.query(sql)

        return data

    def query_thread_state_range(self, start_ts, end_ts, utid):
        """
        查询时间段内的线程状态数据
        :param start_ts: 起始时间戳
        :param end_ts: 结束时间戳
        :param utid: 线程utid
        :return: DataFrame
        """
        sql = f"""
            SELECT Thread_state.state, Thread_state.ts, Thread_state.dur,
                   Thread.name, Thread.tid, process.name AS pname
            FROM thread_state
            JOIN Thread ON Thread_state.utid = Thread.utid
            JOIN process ON thread.upid = process.upid
            WHERE ts >= {start_ts} AND ts < {end_ts}
              AND Thread.utid = {utid}
            ORDER BY ts
        """

        data = self.tp.query(sql)

        return data

    def get_thread_state(
        self, start_ts, end_ts, all_ui_state_data, mode="S", all_render_state_data=None
    ):
        """
        从已加载的线程状态数据中判断状态（避免重复查询）
        :param start_ts: int, 起始时间戳
        :param end_ts: int, 结束时间戳
        :param mode: "S" 表示休眠优先判断, "Running" 表示运行优先判断
        :param all_ui_state_data: DataFrame, 所有UI线程状态数据
        :param all_render_state_data: DataFrame, 所有渲染线程状态数据
        :return: bool
        """

        data = all_ui_state_data[
            (all_ui_state_data["ts"] >= start_ts) & (all_ui_state_data["ts"] < end_ts)
        ]
        if data.empty:
            return False

        s_dur, d_dur, r_dur, running_dur = self._sum_state_durations(data)

        # 判断逻辑
        if mode == "S":
            if s_dur >= d_dur and s_dur >= r_dur and s_dur > running_dur:
                return True
            elif d_dur + r_dur + running_dur > (end_ts - start_ts) / 2:
                return False
            else:
                # 超高刷新时，有可能线程状态休眠小于其他，于是再次判断render线程状态
                if all_render_state_data is not None:
                    render_data = all_render_state_data[
                        (all_render_state_data["ts"] >= start_ts)
                        & (all_render_state_data["ts"] < end_ts)
                    ]
                    s_dur, d_dur, r_dur, running_dur = self._sum_state_durations(data)
                    if s_dur >= d_dur and s_dur >= r_dur and s_dur > running_dur:
                        return True
                    return False
                return False

        elif mode == "Running":
            if running_dur >= d_dur and running_dur >= r_dur and running_dur > s_dur:
                return True
            elif d_dur + r_dur + running_dur > (end_ts - start_ts) / 2:
                return True

        return False

    @staticmethod
    def _sum_state_durations(data: pd.DataFrame):
        """统计不同状态的总时长"""
        durations = data.groupby("state")["dur"].sum()
        return (
            durations.get("S", 0),
            durations.get("D", 0),
            durations.get("R", 0),
            durations.get("Running", 0),
        )

    @staticmethod
    def df_in_range(
        data: pd.DataFrame, time_range: tuple, copy=True, reset_index=False
    ) -> pd.DataFrame:
        """根据时间范围，切片获取 DataFrame"""
        start_time, end_time = time_range
        buffer_in_range = data.loc[(data["ts"] >= start_time) & (data["ts"] < end_time)]
        if copy:
            buffer_in_range = buffer_in_range.copy()
        if reset_index:
            buffer_in_range = buffer_in_range.reset_index(drop=True)
        return buffer_in_range

    @staticmethod
    def detect_stable_vsync_regions(
        timestamps: list[float],
        provide_intervals: bool = False,  # 若直接传间隔则设 True
        expected_period_ms: float | None = None,
        win: int = 5,  # 窗口半宽，实际窗口长度=2*win
        # 残差类阈值
        residual_tau_ms: float = 0.3,  # 异常判断阈值：|interval - ref| > tau 视为离群
        residual_p95_max_ms: float = 0.25,  # 窗口内残差的 P95 上限（敏感但不被单点主导）
        residual_max_max_ms: float = 1.0,  # 残差的绝对最大值上限（防止极端峰）
        outlier_ratio_max: float = 0.08,  # 残差超过 tau 的比例上限（8%）
        # 稳定区间最小时间长度（毫秒），用区间内间隔求和近似时间长度
        min_region_len_ms: float = 60.0,
    ) -> list[tuple[int, int]]:
        """
        基于残差敏感指标检测 VSYNC 稳定区间。
        - timestamps: VSYNC 时间戳（毫秒）或间隔（毫秒）
        - provide_intervals: True 表示 timestamps 实际上是间隔数组
        - expected_period_ms: 期望刷新周期（如 16.6 或 8.3），可选
        - 返回：
          - 稳定区间列表 [(start_idx, end_idx)]
        """
        # 1) 构造间隔序列
        if provide_intervals:
            intervals = timestamps[:]
        else:
            intervals = [
                timestamps[i] - timestamps[i - 1] for i in range(1, len(timestamps))
            ]
        n = len(intervals)
        if n < 2 * win:
            return []

        def median(x: list[float]) -> float:
            s = sorted(x)
            m = len(s) // 2
            return s[m] if len(s) % 2 == 1 else 0.5 * (s[m - 1] + s[m])

        def quantile(x: list[float], q: float) -> float:
            # 线性插值分位数，q in [0,1]
            xs = sorted(x)
            if not xs:
                return math.nan
            pos = (len(xs) - 1) * q
            lo = int(math.floor(pos))
            hi = int(math.ceil(pos))
            if lo == hi:
                return xs[lo]
            w = pos - lo
            return xs[lo] * (1 - w) + xs[hi] * w

        # 众数估计（容差聚类）：更适合锁定 VSYNC 主峰
        def mode_with_tolerance(values: list[float], tol: float = 1) -> float:
            if not values:
                return math.nan
            vals = sorted(values)
            clusters = []
            cur = [vals[0]]
            for v in vals[1:]:
                if abs(v - cur[-1]) <= tol:
                    cur.append(v)
                else:
                    clusters.append(cur)
                    cur = [v]
            clusters.append(cur)
            biggest = max(clusters, key=len)
            return sum(biggest) / len(biggest)

        # 2) 全局参考周期（优先 expected，其次众数，再次中位数）
        if expected_period_ms is not None:
            ref = expected_period_ms
        else:
            ref_mode = mode_with_tolerance(intervals, tol=1)
            if math.isnan(ref_mode):
                ref = median(intervals)
            else:
                ref = ref_mode

        # 3) 对每个窗口计算残差敏感指标并标记稳定/不稳定
        stable_flags = [False] * n
        residual_p95_list = [math.nan] * n
        residual_max_list = [math.nan] * n
        outlier_ratio_list = [math.nan] * n

        for k in range(n):
            L = max(0, k - win)
            R = min(n, k + win)  # R 为切片右边界
            w = intervals[L:R]
            if not w:
                continue
            # w = intervals[k - win:k + win]  # 2*win 长度窗口，提高稳健性

            # 残差
            res = [abs(v - ref) for v in w]
            res_p95 = quantile(res, 0.95)
            res_max = max(res) if res else math.nan
            out_ratio = (
                (sum(1 for r in res if r > residual_tau_ms) / len(res))
                if res
                else math.nan
            )

            residual_p95_list[k] = res_p95
            residual_max_list[k] = res_max
            outlier_ratio_list[k] = out_ratio

            # 稳定判定：更偏向残差敏感指标
            is_stable = (
                (res_p95 <= residual_p95_max_ms)
                and (res_max <= residual_max_max_ms)
                and (out_ratio <= outlier_ratio_max)
            )
            stable_flags[k] = is_stable

        # 4) 合并稳定窗口为区间
        regions: list[tuple[int, int]] = []
        in_reg = False
        start = 0
        for i in range(n):
            if stable_flags[i] and not in_reg:
                in_reg = True
                start = i
            elif not stable_flags[i] and in_reg:
                end = i - 1
                # 用区间内间隔和近似时间长度
                if sum(intervals[start:end]) >= min_region_len_ms:
                    regions.append((start, end))
                in_reg = False
        if in_reg:
            end = n - 1
            if sum(intervals[start : end + 1]) >= min_region_len_ms:
                regions.append((start, end))

        return regions
