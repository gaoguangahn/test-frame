"""
应用内离手滑动动效分析模块（原滑动模型）

功能说明:
- 测量应用内离手滑动的动效卡顿
- 支持时间段多次滑动场景分析

问题：
1. 确定滑动的最短和最大时长，高德地图这种滑动时间很短
2. 微信小程序的buffertx和进程名无关，需要单独写
3. 无根据判断滑动时长的时候，是不是要增加开始滑动到触控结束的间隔，uc浏览器出现触控后很久才两层buffer
4. 20251007_211402.point.pftrace 抖音直播的滑动，buffertx都是1
版本: v1.1.0
"""

import re
from typing import cast

import pandas as pd

from metric_parser.trace.base.base_analyser import BaseTraceAnalyse
from metric_parser.trace.base.registry import AnalyseRegistry
from metric_parser.trace.models.swipe_offscreen_data import (
    SwipeOffScreenData,
    SwipeOffScreenResult,
)
from metric_parser.trace.parsers.swipe.swipe_parser_utils import SwipeParserUtils
from metric_parser.trace.parsers.swipe.swipe_rv import RVScrollAnalyser
from metric_parser.trace.parsers.swipe.swipe_targrtbuf import TargetBufAnalyser

SWIPE_OFF_MAX_TIME = 3500
SWIPE_OFF_MIN_TIME = 2500


@AnalyseRegistry.register("swipe_offScreen")
class SwipeOffScreen(BaseTraceAnalyse):
    def __init__(self, context):
        super().__init__(context)

        # 选项开关
        self.swipe_key_option: bool = True
        self.targetBuf_option: bool = True
        self.RVScroll_option: bool = True

        # 是否卡顿分析
        self.diagnosis: bool = False

    def analyse(
        self,
        package: str,
        activity: str,
        start: int | None,
        end: int | None,
        **kwargs,
    ):
        """统一的对外分析接口，离手滑动分析"""

        try:
            results = self._analyse_internal(package, activity, start, end)
            return self.success(results)
        except Exception as e:
            self.logger.e(f"离手滑动分析失败: {e}")
            return self.fail(f"离手滑动分析失败: {e}")

    def _analyse_internal(
        self, package: str, activity: str, start: int | None, end: int | None
    ) -> list[SwipeOffScreenResult]:

        swipe_results: list[SwipeOffScreenResult] = []

        # 解析/校验时间范围
        start_time, end_time = self._validate_time_range(start, end)
        if start_time is None or end_time is None:
            return swipe_results

        # 每次请求实例化全新的上下文和子分析器，确保绝对无状态和并发安全
        swipe_data = SwipeOffScreenData()
        common = SwipeParserUtils(self.tp)
        rv_analyser = RVScrollAnalyser(common)
        targetBuf_analyser = TargetBufAnalyser(common)

        off_screen_segments, on_screen_segments, paired_segments = self.data_prepare(
            common, swipe_data, package, activity, start_time, end_time
        )

        if not paired_segments:
            self.logger.w("未匹配到有效滑动区间")
            return swipe_results

        # 传递 swipe_data 给子分析器
        rv_analyser.set_swipe_data(swipe_data)
        targetBuf_analyser.set_swipe_data(swipe_data)

        # 逐段分析
        for idx, (on_segment, off_segment) in enumerate(paired_segments):
            on_deliver_start, on_deliver_end = on_segment
            off_deliver_start, off_deliver_end = off_segment

            try:
                (
                    segment_effective,
                    off_jank_time,
                    off_jank_start,
                    off_jank_over_count,
                    off_avg_fps,
                ) = self.get_swipe_jank(
                    rv_analyser,
                    targetBuf_analyser,
                    swipe_data,
                    off_deliver_start,
                    off_deliver_end,
                )
            except Exception as e:
                self.logger.e(f"{off_deliver_start} 滑动区间解析失败: {e}")
                continue

            # 构造基础结果
            seg_result = SwipeOffScreenResult(
                package=package,
                activity=activity,
                op_start=start if start else on_deliver_start,
                on_deliver_start=on_deliver_start,
                off_jank=[],
                off_count=0,
                off_avg_fps=0.0,
                on_jank=[],
                on_count=0,
                on_avg_fps=0.0,
            )

            if segment_effective:
                seg_result.off_jank = [
                    (int(s), float(t)) for s, t in zip(off_jank_start, off_jank_time)
                ]
                seg_result.off_count = int(off_jank_over_count)
                seg_result.off_avg_fps = float(off_avg_fps)

                # 如果滑动片段有效，就多获取 on screen 的滑动卡顿结果
                try:
                    on_jank_time, on_jank_start, on_jank_over_count, on_avg_fps = (
                        self.get_swipe_frames_onscreen(
                            common, swipe_data, on_deliver_start, on_deliver_end
                        )
                    )
                    seg_result.on_jank = [
                        (int(s), float(t)) for s, t in zip(on_jank_start, on_jank_time)
                    ]
                    seg_result.on_count = int(on_jank_over_count)
                    seg_result.on_avg_fps = float(on_avg_fps)
                except Exception as e:
                    self.logger.e(
                        f"获取 {on_deliver_start} 开始的 On Screen 滑动区间卡顿失败, {e}",
                    )

            swipe_results.append(seg_result)

        return swipe_results

    def data_prepare(
        self,
        common: SwipeParserUtils,
        swipe_data: SwipeOffScreenData,
        package: str,
        activity: str,
        start_time: int,
        end_time: int,
    ):
        """数据准备：获取与滑动分析相关的各类数据源并组合为 on/off 区间对"""

        # Step 1: 根据包名和活动名获取相关信息
        package_name, activity_name, process_name, bufferTx = common.get_pkg_info(
            package, activity, start_time, end_time
        )
        if not process_name or not bufferTx:
            self.logger.w("pkg info 不完整，无法继续滑动分析")
            return [], [], []

        upid, ui_utid, render_utid, sf_utid = common.get_pid_tid(
            process_name, start_time, end_time
        )
        swipe_data.set_tids(upid, ui_utid, render_utid, sf_utid)

        # Step 2: 获取帧率、帧间隔标准、丢帧标准
        vsync_sf, get_vsync_sf_avg = common.get_vsync_sf_avg(start_time, end_time)

        # 计算丢帧标准: vsync sf 信息, 平均帧率
        fps, frame_interval, jank_interval = SwipeParserUtils.get_fps_standards(
            get_vsync_sf_avg
        )

        # 整个待检测区间vsync app 信息
        vsync_app = common.get_vsync_app(start_time, end_time)
        swipe_data.set_fps_info(fps, frame_interval, jank_interval)
        swipe_data.set_vsync(vsync_sf, vsync_app)

        # Step 3: 获取判定相关数据（打点、RVScroll、TargetBuf）
        swipe_key_pairs = common.get_swipe_key(start_time=start_time, end_time=end_time)
        all_RVScroll_data = common.get_RVScroll(upid, ui_utid, start_time, end_time)
        targetBuf = common.get_TargetBuf(start_time, end_time, upid)
        swipe_data.set_judge_data(swipe_key_pairs, all_RVScroll_data, targetBuf)

        # Step 4: 获取 bufferTx 数据与下降数据
        buffer_counters, buffer_down_counters = common.get_buffer(
            bufferTx=bufferTx, start_ts=start_time, end_ts=end_time
        )
        buffer_effective = (buffer_counters["value"] >= 2).sum() > 10
        if not buffer_effective:
            self.logger.w("bufferTx 数据不充分，可能影响结果准确性")

        swipe_data.set_buffer_counters(buffer_counters, buffer_down_counters)

        # Step 5: 获取触控数据与区间
        deliverInput_data = common.get_deliverInput(
            process_name, upid, start_time, end_time
        )
        if deliverInput_data.empty:
            self.logger.w("无法在指定线程获取触控数据")
            return [], [], []

        off_screen_segments, swipe_counts = self.get_off_screen_segments(
            deliverInput_data
        )
        on_screen_segments, onscreen_counts = self.get_on_screen_segments(
            deliverInput_data
        )
        paired_segments = self.pair_segments_by_time(
            on_screen_segments, off_screen_segments
        )

        return off_screen_segments, on_screen_segments, paired_segments

    def get_swipe_jank(
        self,
        rv_analyser: RVScrollAnalyser,
        targetBuf_analyser: TargetBufAnalyser,
        swipe_data: SwipeOffScreenData,
        off_deliver_start: int,
        off_deliver_end: int,
    ):
        """根据 off-screen 区间获取卡顿信息。优先使用 RVScroll，其次 TargetBuf。"""

        # 优先 RVScroll
        if self.RVScroll_option:
            # 检查swipe区间是否存在与RVScroll事件，存在的话进行RVScroll滑动分析
            rv_scroll_seg = rv_analyser.common.df_in_range(
                swipe_data.RVScroll_data,
                (off_deliver_start, off_deliver_end),
                True,
                True,
            )
            if not rv_scroll_seg.empty:
                (
                    segment_effective,
                    off_jank_time,
                    off_jank_start,
                    off_jank_over_count,
                    off_avg_fps,
                ) = rv_analyser.get_swipe_frames(off_deliver_start, off_deliver_end)

                # 如果 RVScroll 分析有效，直接返回
                if segment_effective:
                    return (
                        segment_effective,
                        off_jank_time,
                        off_jank_start,
                        off_jank_over_count,
                        off_avg_fps,
                    )

        # 其次 TargetBuf
        if self.targetBuf_option:
            # RV Scroll不存在的时候，检查swipe区间是否存在于Target Buffer中，存在的话进行利用Target buffer进行判断
            (
                segment_effective,
                off_jank_time,
                off_jank_start,
                off_jank_over_count,
                off_avg_fps,
            ) = targetBuf_analyser.get_swipe_frames(off_deliver_start, off_deliver_end)
            return (
                segment_effective,
                off_jank_time,
                off_jank_start,
                off_jank_over_count,
                off_avg_fps,
            )

        return False, [], [], 0, 0.0

    def get_swipe_frames_onscreen(
        self,
        common: SwipeParserUtils,
        swipe_data: SwipeOffScreenData,
        deliver_start: int,
        deliver_end: int,
    ):
        """获取在屏上滑动的帧间隔卡顿信息"""

        jank_time = []
        jank_start = []
        jank_over_count = 0

        start_ts, end_ts, buffer_down_in_range = self.onscreen_seg_correct(
            common, swipe_data, deliver_start, deliver_end
        )

        if start_ts is None or end_ts is None or buffer_down_in_range.empty:
            self.logger.w(f"{deliver_start} 开始的 onscreen 滑动片段无效")
            return (jank_time, jank_start, jank_over_count, 0.0)

        # 垂直滑动时，后续通过UI线程的slice进一步判断滑动距离来确定滑动片段
        ui_slices = common.get_onscreen_ui_slices(
            swipe_data.upid, swipe_data.ui_utid, start_ts, end_ts
        )

        prev_density: float | None = None
        prev_ts: int | None = None
        pattern = re.compile(r"\((\d+(?:\.\d+)?),\s*(\d+(?:\.\d+)?)\)")

        for idx, row in ui_slices.iterrows():
            slice_name = row["name"]

            match = pattern.search(slice_name)
            if not match:
                continue

            density = float(match.group(2))

            if prev_density is None:
                prev_density, prev_ts = density, row["ts"]
                continue

            if prev_density - density >= 25:
                if prev_ts is not None:
                    start_ts = prev_ts
                break

            prev_density, prev_ts = density, row["ts"]

        # 如果 start_ts 有变化更新下buffer_down_in_range
        buffer_down_in_range = common.df_in_range(
            buffer_down_in_range, (start_ts, end_ts), copy=True, reset_index=True
        )
        # 获取 Buffer 消费信息中的时间差, 是消费帧减去上一帧的时间差，第一帧就减去开始位置
        buffer_down_in_range.loc[:, "ts_diff"] = (
            buffer_down_in_range["ts"]
            .diff()
            .fillna(buffer_down_in_range["ts"].iloc[0] - start_ts)
            / 1e6
        )

        # 卡顿判断
        threshold = swipe_data.jank_interval
        over_threshold = buffer_down_in_range[
            buffer_down_in_range["ts_diff"] >= threshold
        ]

        for idx, row in over_threshold.iterrows():
            idx = cast(int, idx)
            # 第一帧暂时不去算卡顿，后续再确定怎么判断
            if idx == 0:
                continue

            exceed_amount = round(row["ts_diff"] - swipe_data.frame_interval, 2)
            jank_time.append(exceed_amount)

            # 取当前行的 ts 作为 jank_start
            prev_ts = buffer_down_in_range.loc[idx - 1]["ts"] if idx > 0 else start_ts
            jank_start.append(prev_ts)
            # 计数累加
            jank_over_count += int(exceed_amount / swipe_data.frame_interval)

            # # 发生卡顿，诊断原因
            # if self.diagnosis:
            #     self.common.get_jank_reason(prev_ts, row['ts'], row["ts_diff"])

        # 计算平均帧率
        buffer_nums = len(buffer_down_in_range)
        fps = (
            round(buffer_nums / ((end_ts - start_ts) / 1e9), 2)
            if (end_ts - start_ts) != 0
            else 0
        )

        return jank_time, jank_start, jank_over_count, fps

    def onscreen_seg_correct(
        self,
        common: SwipeParserUtils,
        swipe_data: SwipeOffScreenData,
        deliver_start: int,
        deliver_end: int,
    ):
        """根据在屏上的输入事件片段，得到精细的在屏滑动时间段，并获取该时间段内的 buffer_down 数据"""

        start_ts, end_ts = deliver_start, deliver_end

        vsync_df = common.df_in_range(
            swipe_data.vsync_app,
            (deliver_start, deliver_end),
            copy=False,
            reset_index=False,
        )
        if not vsync_df.empty:
            start_ts = vsync_df.iloc[0]["ts"]
            end_ts = vsync_df.iloc[-1]["ts"] + vsync_df.iloc[-1]["dur"]

        buffer_down_in_range = common.df_in_range(
            swipe_data.buffer_down_counters,
            (start_ts, end_ts),
            copy=True,
            reset_index=True,
        )

        if buffer_down_in_range.empty:
            self.logger.w(f"{deliver_start} 开始的滑动未找到 buffer_down 数据")
            return None, None, pd.DataFrame()

        first_down = buffer_down_in_range.iloc[0]["ts"]
        if not vsync_df.empty:
            mask_df = vsync_df.loc[vsync_df["ts"] < first_down]
            if not mask_df.empty:
                start_ts = mask_df.iloc[-1]["ts"]

        return start_ts, end_ts, buffer_down_in_range

    @staticmethod
    def get_off_screen_segments(deliverInput_data: pd.DataFrame):
        """
        根据deliverInput数据，获取滑动后离手的时间段
        """
        deliver_segments = []
        deliverInput_data.loc[:, "diff"] = (
            deliverInput_data["ts"].shift(-1) - deliverInput_data["ts"]
        )
        deliverInput_data.loc[:, "diff"] = deliverInput_data["diff"].fillna(0)
        mask = deliverInput_data["diff"] >= 600_000_000

        for idx in deliverInput_data[mask].index:
            prev_te = deliverInput_data.loc[idx, "te"]
            next_ts = deliverInput_data.loc[idx + 1, "ts"]
            deliver_segments.append([prev_te, next_ts])

        last_deliver = deliverInput_data.iloc[-1]["te"]
        last_end = last_deliver + SWIPE_OFF_MAX_TIME * 1_000_000
        deliver_segments.append([last_deliver, last_end])
        swipe_counts = len(deliver_segments)

        return deliver_segments, swipe_counts

    @staticmethod
    def get_on_screen_segments(deliverInput_data: pd.DataFrame):
        if deliverInput_data.empty:
            return [], 0

        ts = deliverInput_data["ts"].astype("int64")

        deliverInput_data["group"] = (ts.diff() > 500_000_000).cumsum()

        segments = []
        for _, group_df in deliverInput_data.groupby("group"):
            start_ts = group_df["ts"].iloc[0]
            end_ts = group_df["te"].iloc[-1]
            segments.append([start_ts, end_ts])

        return segments, len(segments)

    @staticmethod
    def pair_segments_by_time(on_segments, off_segments):
        """根据时间对 on-screen 和 off-screen 段进行配对"""
        paired = []
        used_off = set()

        for on_start, on_end in on_segments:
            # 找到第一个 off-screen 段的开始时间 >= on_end
            match = None
            for i, (off_start, off_end) in enumerate(off_segments):
                if i in used_off:
                    continue
                if off_start >= on_end:
                    match = (off_start, off_end)
                    used_off.add(i)
                    break
            if match:
                paired.append(((on_start, on_end), match))

        return paired
