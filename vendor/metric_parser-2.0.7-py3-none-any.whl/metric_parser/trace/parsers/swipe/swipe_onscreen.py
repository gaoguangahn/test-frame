"""
应用内跟手滑动动效分析模块（原滑动模型）

功能说明:
- 测量应用内不离手滑动的动效卡顿
- 支持时间段多次滑动场景分析

版本: v1.1.0
"""

import re
from typing import cast

import pandas as pd

from metric_parser.trace.base.base_analyser import BaseTraceAnalyse
from metric_parser.trace.base.registry import AnalyseRegistry
from metric_parser.trace.models.swipe_onscreen_data import (
    SwipeOnScreenData,
    SwipeOnScreenResult,
)
from metric_parser.trace.parsers.swipe.swipe_parser_utils import SwipeParserUtils

SWIPE_OFF_MAX_TIME = 3500
SWIPE_OFF_MIN_TIME = 2500


@AnalyseRegistry.register("swipe_onScreen")
class SwipeOnScreen(BaseTraceAnalyse):
    def __init__(self, context):
        super().__init__(context)
        # 是否卡顿分析 (配置项保留在实例级别)
        self.diagnosis = False

    def analyse(
        self,
        package: str,
        activity: str,
        start: int | None = None,
        end: int | None = None,
        vertical: bool = True,
        **kwargs,
    ):
        """统一的对外分析接口，跟手滑动分析"""
        try:
            results = self._analyse_internal(package, activity, start, end, vertical)
            return self.success(results)
        except Exception as e:
            self.logger.e(f"跟手滑动分析失败: {e}")
            return self.fail(f"跟手滑动分析失败: {e}")

    def _analyse_internal(
        self,
        package: str,
        activity: str,
        start: int | None,
        end: int | None,
        vertical: bool,
    ) -> list[SwipeOnScreenResult]:

        swipe_results: list[SwipeOnScreenResult] = []

        # 解析/校验时间范围
        start_time, end_time = self._validate_time_range(start, end)
        if start_time is None or end_time is None:
            return swipe_results

        # 每次请求实例化全新的上下文和工具类，确保绝对无状态
        swipe_data = SwipeOnScreenData()
        common = SwipeParserUtils(self.tp)

        swipe_data.direction = "vertical" if vertical else "horizontal"

        # === Step 1: 根据包名和活动名获取相关信息 ===
        try:
            package_name, activity_name, process_name, bufferTx = common.get_pkg_info(
                package, activity, start_time, end_time
            )
        except Exception as e:
            self.logger.e(f"获取相关信息失败: {e}")
            return swipe_results

        # 根据进程名获取进程 pid, ui线程id、render线程id, sf主线程id
        (
            swipe_data.upid,
            swipe_data.ui_utid,
            swipe_data.render_utid,
            swipe_data.sf_utid,
        ) = common.get_pid_tid(process_name, start_time, end_time)

        # 获取帧率、帧间隔标准、丢帧标准等信息
        swipe_data.vsync_sf, get_vsync_sf_avg = common.get_vsync_sf_avg(
            start_time, end_time
        )
        swipe_data.fps, swipe_data.frame_interval, swipe_data.jank_interval = (
            SwipeParserUtils.get_fps_standards(get_vsync_sf_avg)
        )
        swipe_data.vsync_app = common.get_vsync_app(start_time, end_time)

        # === Step 2: 获取ui线程的相关slice信息，用于后面的滑动状态判断 ===
        swipe_data.ui_slices = common.get_onscreen_ui_slices(
            swipe_data.upid, swipe_data.ui_utid, start_time, end_time
        )

        # === Step 3: 获取检测区间内的 bufferTx 数据和 bufferTx 下降的数据 ===
        swipe_data.buffer_counters, swipe_data.buffer_down_counters = common.get_buffer(
            bufferTx=bufferTx, start_ts=start_time, end_ts=end_time
        )
        buffer_effective = (swipe_data.buffer_counters["value"] >= 2).sum() > 10
        if not buffer_effective:
            self.logger.w("bufferTx 数据不充分，可能影响结果准确性")

        # === Step 4: 获取检测区间内指定进程的触控数据，并进步获得滑动跟手区间 ===
        deliverInput_data = common.get_deliverInput(
            process_name, swipe_data.upid, start_time, end_time
        )
        on_screen_segments, onscreen_counts = self.get_on_screen_segments(
            deliverInput_data
        )

        # === Step 5: 执行后续获取滑动卡顿结果===
        for idx, (deliver_start, deliver_end) in enumerate(on_screen_segments):
            try:
                jank_time, jank_start, jank_over_count = self.get_swipe_frames_onscreen(
                    common, swipe_data, deliver_start, deliver_end
                )

                # 显式类型转换，解决 Pandas 隐式 float 导致的数据类型不匹配问题
                formatted_jank = [
                    (int(s), float(t)) for s, t in zip(jank_start, jank_time)
                ]

                swipe_results.append(
                    SwipeOnScreenResult(
                        package=package,
                        activity=activity,
                        on_deliver_start=deliver_start,
                        on_deliver_end=deliver_end,
                        jank=formatted_jank,
                        count=int(jank_over_count),
                    )
                )

            except Exception as e:
                self.logger.e(f"Failed to get swipe frames onscreen: {e}")
                continue

        return swipe_results

    def get_swipe_frames_onscreen(
        self,
        common: SwipeParserUtils,
        swipe_data: SwipeOnScreenData,
        deliver_start: int,
        deliver_end: int,
    ):
        """获取在屏上滑动的帧间隔卡顿信息"""
        jank_time = []
        jank_start = []
        jank_over_count = 0

        start_ts, end_ts, buffer_down_in_range = self.onscreen_seg_correct(
            common, swipe_data, deliver_start, deliver_end
        )

        if start_ts is None or end_ts is None or buffer_down_in_range.empty:
            return jank_time, jank_start, jank_over_count

        # 垂直滑动时，后续通过UI线程的slice进一步判断滑动距离来确定滑动片段
        if swipe_data.direction == "vertical":
            ui_slice_in_range = common.df_in_range(
                swipe_data.ui_slices, (start_ts, end_ts), copy=True, reset_index=True
            )

            prev_density, prev_ts = None, None
            pattern = re.compile(r"\((\d+(?:\.\d+)?),\s*(\d+(?:\.\d+)?)\)")

            for idx, row in ui_slice_in_range.iterrows():
                slice_name = row["name"]

                match = pattern.search(slice_name)
                if not match:
                    continue

                density = float(match.group(2))

                if prev_density is None:
                    prev_density, prev_ts = density, row["ts"]
                    continue

                if prev_density - density >= 25:
                    start_ts = prev_ts
                    break

                prev_density, prev_ts = density, row["ts"]

            # 如果 start_ts 有变化更新下buffer_down_in_range
            buffer_down_in_range = common.df_in_range(
                buffer_down_in_range, (start_ts, end_ts), copy=True, reset_index=True
            )

        # 获取 Buffer 消费信息中的时间差, 是消费帧减去上一帧的时间差，第一帧就减去开始位置
        buffer_down_in_range.loc[:, "ts_diff"] = (
            buffer_down_in_range["ts"]
            .diff()
            .fillna(buffer_down_in_range["ts"].iloc[0] - start_ts)
            / 1e6
        )

        # 卡顿判断
        threshold = swipe_data.jank_interval
        over_threshold = buffer_down_in_range[
            buffer_down_in_range["ts_diff"] >= threshold
        ]

        for idx, row in over_threshold.iterrows():
            idx = cast(int, idx)
            exceed_amount = round(row["ts_diff"] - swipe_data.frame_interval, 2)
            jank_time.append(exceed_amount)

            # 取当前行的 ts 作为 jank_start
            prev_ts = buffer_down_in_range.loc[idx - 1]["ts"] if idx > 0 else start_ts
            jank_start.append(prev_ts)
            # 计数累加
            jank_over_count += int(exceed_amount / swipe_data.frame_interval)

        return jank_time, jank_start, jank_over_count

    def onscreen_seg_correct(
        self,
        common: SwipeParserUtils,
        swipe_data: SwipeOnScreenData,
        deliver_start: int,
        deliver_end: int,
    ):
        """根据在屏上的输入事件片段，得到精细的在屏滑动时间段，并获取该时间段内的 buffer_down 数据"""
        start_ts, end_ts = deliver_start, deliver_end

        vsync_df = common.df_in_range(
            swipe_data.vsync_app,
            (deliver_start, deliver_end),
            copy=False,
            reset_index=False,
        )

        if not vsync_df.empty:
            start_ts = vsync_df.iloc[0]["ts"]
            end_ts = vsync_df.iloc[-1]["ts"] + vsync_df.iloc[-1]["dur"]

        buffer_down_in_range = common.df_in_range(
            swipe_data.buffer_down_counters,
            (start_ts, end_ts),
            copy=True,
            reset_index=True,
        )

        if buffer_down_in_range.empty:
            self.logger.w(f"{deliver_start} 开始的滑动未找到 buffer_down 数据")
            return None, None, pd.DataFrame()

        first_down = buffer_down_in_range.iloc[0]["ts"]
        if not vsync_df.empty:
            mask_df = vsync_df.loc[vsync_df["ts"] < first_down]
            if not mask_df.empty:
                start_ts = mask_df.iloc[-1]["ts"]

        return start_ts, end_ts, buffer_down_in_range

    @staticmethod
    def get_on_screen_segments(deliverInput_data: pd.DataFrame):
        if deliverInput_data.empty:
            return [], 0
        ts = deliverInput_data["ts"].astype("int64")

        deliverInput_data["group"] = (ts.diff() > 500_000_000).cumsum()

        segments = []
        for _, group_df in deliverInput_data.groupby("group"):
            start_ts = group_df["ts"].iloc[0]
            end_ts = group_df["te"].iloc[-1]  # 用 te 作为结束时间更准确
            segments.append([start_ts, end_ts])

        return segments, len(segments)
