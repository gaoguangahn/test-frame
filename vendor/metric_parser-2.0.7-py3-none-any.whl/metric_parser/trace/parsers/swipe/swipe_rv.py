import pandas as pd

from metric_parser.trace.models.swipe_offscreen_data import SwipeOffScreenData
from metric_parser.trace.parsers.swipe.swipe_parser_utils import SwipeParserUtils
from metric_parser.utils.logger import ParseLogger


class RVScrollAnalyser:
    def __init__(self, common_obj: SwipeParserUtils):
        self.common = common_obj
        self.logger = ParseLogger("RVScrollAnalyser")
        self.swipe_data: SwipeOffScreenData | None = None

    def set_swipe_data(self, data: SwipeOffScreenData):
        self.swipe_data = data

    def get_swipe_frames(
        self,
        deliver_start,
        deliver_end,
    ):
        """
        由RVScroll获取到滑动时间段，获取滑动的帧间隔
        :param deliver_start: 滑动开始时间
        :param deliver_end: 滑动结束时间
        """
        jank_time = []
        jank_start = []
        jank_over_count = 0
        fps = -1

        # 判断当前片段是否有效，也就是off screen是有效滑动
        segment_effective = False

        # 根据deliver的起终时间和RVScroll获取准确的滑动时间段
        (start_time, end_time), RVScroll_effective = self.get_RVScroll_range(
            deliver_start, deliver_end
        )
        if not RVScroll_effective:
            self.logger.w(
                f"{deliver_start} 开始的这段滑动 RVScroll 时间段无效，无法使用RVScroll解析",
            )
            return segment_effective, jank_time, jank_start, jank_over_count, fps

        # 获取滑动时间段内的 Buffer 消费信息
        buffer_down_in_range = self.common.df_in_range(
            self.swipe_data.buffer_down_counters,
            (start_time, end_time),
            copy=True,
            reset_index=True,
        )

        if buffer_down_in_range.empty:
            self.logger.e("滑动时间段内无 buffer_down 数据")
            return segment_effective, jank_time, jank_start, jank_over_count, fps

        # 获取 Buffer 消费信息中的时间差, 是消费帧减去上一帧的时间差，第一帧就减去开始位置
        buffer_down_in_range.loc[:, "ts_diff"] = (
            buffer_down_in_range["ts"]
            .diff()
            .fillna(buffer_down_in_range["ts"].iloc[0] - start_time)
            / 1e6
        )

        # 卡顿判断
        threshold = self.swipe_data.jank_interval
        over_threshold = buffer_down_in_range[
            buffer_down_in_range["ts_diff"] >= threshold
        ]

        for idx, row in over_threshold.iterrows():
            # 第一帧暂时不去算卡顿，后续再确定怎么判断
            if idx == 0:
                continue

            exceed_amount = round(row["ts_diff"] - self.swipe_data.frame_interval, 2)
            jank_time.append(exceed_amount)

            # 取当前行的 ts 作为 jank_start
            prev_ts = buffer_down_in_range.loc[idx - 1]["ts"] if idx > 0 else start_time
            jank_start.append(prev_ts)
            # 计数累加
            jank_over_count += exceed_amount / self.swipe_data.frame_interval

            # # 发生卡顿，诊断原因
            # if self.diagnosis:
            #     self.common.get_jank_reason(prev_ts, row['ts'], row["ts_diff"])

        segment_effective = True

        # 计算平均帧率
        buffer_nums = len(buffer_down_in_range)
        fps = (
            round(buffer_nums / ((end_time - start_time) / 1e9), 2)
            if (end_time - start_time) != 0
            else 0
        )

        return segment_effective, jank_time, jank_start, jank_over_count, fps

    def get_RVScroll_range(self, deliver_start, deliver_end):
        """
        如果有RVScroll参数，根据deliver和RVScroll的时间点，获取滑动的具体时间段，主要是确定滑动结束时间
        """

        RVScroll_effective = True

        # === Step 1: 数据准备 ===
        # 获取 deliver_start 后的首个 vsync 时间
        vsync_candidates = self.swipe_data.vsync_app[
            self.swipe_data.vsync_app["ts"] >= deliver_start
        ]

        if vsync_candidates.empty:
            self.logger.w(f"{deliver_start} 未找到对应 vsync_app")
            return (deliver_start, deliver_end), False

        first_vsync_app = vsync_candidates.iloc[0]["ts"]

        # 根据deliver的开始和结束时间初步确定候选滑动区间
        start_ts = first_vsync_app if first_vsync_app else deliver_start
        end_ts = deliver_end - 500_000_000

        RVScroll_data = self.common.df_in_range(
            self.swipe_data.RVScroll_data,
            (start_ts, end_ts),
            copy=True,
            reset_index=True,
        )

        # 提前查询出整个时间端内的两个线程状态，避免下面分段查询
        ui_thread_state = self.common.query_thread_state_range(
            start_ts, end_ts, self.swipe_data.ui_utid
        )
        render_thread_state = self.common.query_thread_state_range(
            start_ts, end_ts, self.swipe_data.render_utid
        )

        # 提前查出vsync_sf，避免下面分段查询
        all_vsync_sf = self.common.get_vsync_sf(start_ts, end_ts)

        # === 2. 有效性检查 ===
        # 判断 RVScroll 是否有效
        if (
            len(RVScroll_data) <= 10
            or RVScroll_data.iloc[0]["ts"] - start_ts >= 200_000_000
        ):
            RVScroll_effective = False
            return (start_ts, end_ts), RVScroll_effective

        # === 3. 候选区间筛选 ===
        # 条件一：diff > 200
        mask_200 = RVScroll_data["diff"] > 200
        # 条件二：54 <= diff <= 200
        mask_54 = RVScroll_data["diff"].between(54, 200)
        # 合并候选
        candidates = RVScroll_data[mask_200 | mask_54].copy()

        last_rv = RVScroll_data.iloc[-1]["ts"]

        # 对候选区间做查询判断
        for idx in candidates.index:
            if idx == 0:
                continue
            prev_ts = RVScroll_data.loc[idx - 1, "ts"]
            curr_ts = RVScroll_data.loc[idx, "ts"]
            # 线程 sleep 状态检查
            sleep_state = self.common.get_thread_state(
                prev_ts, curr_ts, ui_thread_state, "S", render_thread_state
            )
            if not sleep_state:
                continue

            # 大间隔直接结束
            if RVScroll_data.loc[idx, "diff"] > 200:
                last_rv = prev_ts
                break

            # 中间间隔检查, 剩下的是只有 54 <= diff <= 200 的数据

            # 检查线程状态
            running_state = self.common.get_thread_state(
                prev_ts, curr_ts, ui_thread_state, "Running"
            )
            # 如果线程活跃，检查下一个 RVScroll_data
            if running_state:
                continue

            # 判断区间内是不是有长度大于一定长度的slice，长度大于一定长度代表可能是延迟，不是滑动结束？
            length_effective = self.common.get_length_slice(
                [self.swipe_data.ui_utid, self.swipe_data.render_utid],
                prev_ts,
                curr_ts,
                self.swipe_data.frame_interval * 2,
            )
            if length_effective:
                continue

            # 检查 Buffer, 如果bufferTx在prev后存在是0的value，认为到这里就结束了滑动
            buffer_flag = (self.swipe_data.buffer_counters["ts"] >= prev_ts) & (
                self.swipe_data.buffer_counters["value"] < 1
            )
            if buffer_flag.any():
                last_rv = prev_ts
                return (start_ts, last_rv), RVScroll_effective

            # 检查 vsync, 判断是否存在gap, 滑动模型代码逻辑有问题，这段执行不到
            vsync_gap = self.find_vsync_gap(
                all_vsync_sf, prev_ts, curr_ts, self.swipe_data.frame_interval
            )
            if vsync_gap:
                last_rv = vsync_gap
            return (start_ts, last_rv), RVScroll_effective

        first_draw_frame = self.common.get_first_draw_frame(
            self.swipe_data.render_utid, last_rv
        )
        if first_draw_frame:
            return (start_ts, first_draw_frame), RVScroll_effective
        # 如果没找到，返回最后一帧时间
        return (start_ts, last_rv), RVScroll_effective

    @staticmethod
    def find_vsync_gap(all_vsync_data, start_ts, end_ts, value):
        """寻找范围内的vsync gap连续三帧大于指定值的索引"""

        # 传了时间范围，先切片
        all_vsync_data = all_vsync_data[
            (all_vsync_data["ts"] >= start_ts) & (all_vsync_data["ts"] <= end_ts)
        ]

        if all_vsync_data.shape[0] < 3:
            return None

        # 判断每帧是否超过阈值
        cond = all_vsync_data["value"] >= (value + 3)

        # 滑动窗口找连续3帧
        cond_rolling = cond.rolling(3).sum()
        idx = cond_rolling[cond_rolling == 3].index
        if len(idx) > 0:
            first_idx = idx[0] - 2  # 回到连续3帧的第一帧
            return all_vsync_data.iloc[first_idx]["ts"]

        return None
