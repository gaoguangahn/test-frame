import pandas as pd

from metric_parser.trace.models.swipe_offscreen_data import SwipeOffScreenData
from metric_parser.trace.parsers.swipe.swipe_parser_utils import SwipeParserUtils
from metric_parser.utils.logger import ParseLogger

SWIPE_OFF_MAX_TIME = 3500
SWIPE_OFF_MIN_TIME = 250


class TargetBufAnalyser:
    def __init__(self, common_obj: SwipeParserUtils):
        self.common = common_obj
        self.logger = ParseLogger("TargetBufAnalyser")
        self.swipe_data: SwipeOffScreenData | None = None

    def set_swipe_data(self, data: SwipeOffScreenData):
        self.swipe_data = data

    def get_swipe_frames(self, deliver_start, deliver_end):
        """
        由TargetBuf获取到滑动时间段，获取滑动的帧间隔
        :param deliver_start: 滑动开始时间
        :param deliver_end: 滑动结束时间
        :return: jank_time, jank_start, jank_over_count: 卡顿时长，卡顿时间，卡顿超过比例
        """
        jank_time = []
        jank_start = []
        jank_over_count = 0
        fps = -1

        # 判断当前片段是否有效，也就是off screen是有效滑动
        segment_effective = False

        try:
            start_time, end_time = self.get_target_range(deliver_start, deliver_end)
        except Exception as e:
            self.logger.e(f"{deliver_start} 开始的滑动找不到有效滑动范围: {e}")
            return segment_effective, jank_time, jank_start, jank_over_count, fps

        # 获取滑动时间段内的 Buffer 消费信息
        buffer_in_range = self.common.df_in_range(
            self.swipe_data.buffer_counters,
            (deliver_start, deliver_end),
            copy=True,
            reset_index=True,
        )
        buffer_down_in_range = self.common.df_in_range(
            self.swipe_data.buffer_down_counters,
            (deliver_start, deliver_end),
            copy=True,
            reset_index=True,
        )

        if buffer_in_range.empty or buffer_down_in_range.empty:
            self.logger.e(f"{deliver_start} 开始的滑动无buffer数据, 忽略")
            return segment_effective, jank_time, jank_start, jank_over_count, fps

        # 提前查询出整个时间端内的两个线程状态，避免下面分段查询。(用输入片段查询，因为 TargetBuf 中的消费帧可能在TargetBuf外绘制)
        ui_thread_state = self.common.query_thread_state_range(
            deliver_start, deliver_end, self.swipe_data.ui_utid
        )
        render_thread_state = self.common.query_thread_state_range(
            deliver_start, deliver_end, self.swipe_data.render_utid
        )

        # 根据 self.buffer_counters 中大 value 大于1的slice间距先做一部判断，认为大于110ms的滑动就已经结束，哪怕在 TargetBuf中
        overlap_start, overlap_end = self.overlap_counters_judge(
            buffer_in_range, deliver_end, ui_thread_state, render_thread_state
        )

        if overlap_end is not None:
            # 这里相当于解决通过vsync获取时长过长的问题，通过buffer获取滑动结束时间
            end_time = overlap_end
        if overlap_start is not None:
            # 感觉还是用buffer判断区间靠谱，不然不好区分滑动是不是真的开始
            start_time = overlap_start

        if end_time == 0 or start_time == 0:
            self.logger.e(f"{deliver_start} 开始的滑动无法获取有效的滑动范围, 忽略")
            return segment_effective, jank_time, jank_start, jank_over_count, fps

        if (end_time - start_time) <= 200e6:
            self.logger.e(f"{deliver_start} 开始的滑动时间段过短, 忽略")
            return segment_effective, jank_time, jank_start, jank_over_count, fps

        # 如果有对end_time做修改，根据修改的结果再修正下 buffer_in_range 和 buffer_down_in_range
        buffer_down_in_range = self.common.df_in_range(
            buffer_down_in_range, (start_time, end_time), copy=False, reset_index=True
        )
        if len(buffer_down_in_range) <= 10:
            self.logger.e(
                f"{deliver_start} 开始的滑动时间段内 buffer_down 数据过少, 忽略"
            )
            return segment_effective, jank_time, jank_start, jank_over_count, fps

        # 获取 Buffer 消费信息中的时间差, 是消费帧减去上一帧的时间差，第一帧就减去开始位置
        buffer_down_in_range.loc[:, "ts_diff"] = (
            buffer_down_in_range["ts"]
            .diff()
            .fillna(buffer_down_in_range["ts"].iloc[0] - start_time)
            / 1e6
        )
        jank_time, jank_start, jank_over_count = self.jank_analysis(
            start_time, buffer_down_in_range, ui_thread_state, render_thread_state
        )

        segment_effective = True

        buffer_nums = len(buffer_down_in_range)

        # 计算平均帧率
        fps = (
            round(buffer_nums / ((end_time - start_time) / 1e9), 2)
            if (end_time - start_time) != 0
            else 0
        )

        return segment_effective, jank_time, jank_start, jank_over_count, fps

    def get_target_range(self, deliver_start, deliver_end):
        """
        根据deliver和TargetBuf的时间点，或者稳定帧率的原则（待确定），获取滑动的具体时间段，同时返回时间段内的buffer下降信息
        :param deliver_start: 滑动开始时间
        :param deliver_end: 滑动结束时间
        :return: start_ts, end_ts, buffer_down_in_range
        """
        global SWIPE_OFF_MAX_TIME

        # 有TargetBuf的话优先考虑，否则再判断是否有稳定的滑动进程，没有的话用deliver的策略
        def get_range():
            if not self.swipe_data.targetBuf.empty:
                target_range = self.common.df_in_range(
                    self.swipe_data.targetBuf,
                    (deliver_start, deliver_end),
                    copy=False,
                    reset_index=False,
                )
                if not target_range.empty:
                    start_time, end_time = (
                        target_range.iloc[0]["ts"],
                        target_range.iloc[0]["te"],
                    )
                    return start_time, end_time

            # 判断是否有稳定的帧率序列间隔
            vsync_sf_range = self.common.df_in_range(
                self.swipe_data.vsync_sf,
                (deliver_start, deliver_end),
                copy=True,
                reset_index=True,
            )

            try:
                stable_durations = self.detect_stable_fps_range(vsync_sf_range)
            except Exception as e:
                raise RuntimeError(f"通过稳定帧率区间获取滑动段时解析出错:{e}")

            if stable_durations:
                # 只取deliver期间的第一段stable帧率序列
                start_idx, end_idx = stable_durations[0][0], stable_durations[0][1]
                start_time = vsync_sf_range.iloc[start_idx]["ts"]
                end_time = (
                    vsync_sf_range.iloc[end_idx]["ts"]
                    + vsync_sf_range.iloc[end_idx]["dur"]
                )

                if end_time - start_time <= SWIPE_OFF_MAX_TIME * 1e6:
                    return start_time, end_time
                else:
                    return 0, 0
            else:
                return -1, -1

        start_ts, end_ts = get_range()

        if start_ts == -1 or end_ts == -1:
            raise ValueError("不存在稳定的帧率序列")

        if start_ts == 0 or end_ts == 0:
            # 稳定时长超过了最大限制，大概率靠这个无法分辨
            return 0, 0

        # 利用vsync_app的信息，做到只取离手后绘制刷新的帧
        vsync_app_range = self.common.df_in_range(
            self.swipe_data.vsync_app, (start_ts, end_ts), copy=False, reset_index=False
        )

        if not vsync_app_range.empty:
            start_ts = vsync_app_range.iloc[0]["ts"]
            # end_ts = vsync_app_range.iloc[-1]['ts'] + vsync_in_range.iloc[-1]['dur']

        # buffer_down_in_range = self.common.df_in_range(
        #   self.buffer_down_counters, (start_ts, end_ts), copy=True, reset_index=True
        # )
        #
        # first_down = buffer_down_in_range.iloc[0]['ts']
        # if not vsync_in_range.empty:
        #     mask_df = vsync_app_range.loc[vsync_in_range['ts'] < first_down]
        #     if not mask_df.empty:
        #         start_ts = mask_df.iloc[-1]['ts']

        return start_ts, end_ts

    def overlap_counters_judge(
        self, buffer_in_range, end_time, ui_thread_state, render_thread_state
    ):
        """
        根据 self.buffer_counters 进一步判断结束时间
        """
        # 根据 self.buffer_counters 中大 value 大于1的slice间距先做一部判断，认为大于110ms的滑动就已经结束，哪怕在 TargetBuf中
        buffer_in_range["slice_dur"] = (
            buffer_in_range["ts"].shift(-1) - buffer_in_range["ts"]
        )  # 下一行减去上一行
        buffer_in_range["slice_dur"] = buffer_in_range["slice_dur"].fillna(
            end_time - buffer_in_range.iloc[-1]["ts"]
        )
        overlap_counters = buffer_in_range[buffer_in_range["value"] > 1].copy()

        if len(overlap_counters) <= 5:
            return None, None

        overlap_counters["internal"] = (
            overlap_counters["ts"].shift(-1) - overlap_counters["ts"]
        )  # 下一行减去上一行
        overlap_counters["internal"] = overlap_counters["internal"].fillna(
            end_time - overlap_counters.iloc[-1]["ts"]
        )

        # 获取起点
        first_over_ts = overlap_counters.iloc[0]["ts"]
        cond = (
            (buffer_in_range["value"] == 0)
            & (buffer_in_range["value"].shift(-1) == 1)
            & (buffer_in_range["ts"] < first_over_ts)
        )
        candidate_ts = buffer_in_range.loc[cond, "ts"]
        if not candidate_ts.empty:
            start_time = candidate_ts.max()  # 最近的
        else:
            start_time = first_over_ts

        end_time = None
        for idx, row in overlap_counters.iloc[:-1].iterrows():
            internal = row["internal"] / 1e6
            slice_dur = row["slice_dur"] / 1e6
            if internal >= 110:
                if slice_dur >= self.swipe_data.frame_interval * 1.9:
                    end_ts = row["ts"] + row["slice_dur"]
                else:
                    end_ts = row["ts"] + row["internal"]

                sleep_state = self.common.get_thread_state(
                    row["ts"], end_ts, ui_thread_state, "S", render_thread_state
                )

                if sleep_state:
                    pos = buffer_in_range.index.get_loc(idx)
                    if pos + 2 < len(buffer_in_range):
                        end_time = buffer_in_range.iloc[pos + 2]["ts"]
                    else:
                        end_time = buffer_in_range.loc[idx]["ts"]
                    break
        if end_time is None:
            last_idx = overlap_counters.index[-1]
            pos = buffer_in_range.index.get_loc(last_idx)
            if pos + 2 < len(buffer_in_range):
                end_time = buffer_in_range.iloc[pos + 2]["ts"]
            else:
                end_time = buffer_in_range.loc[last_idx]["ts"]

        # TODO: 原来的代码还有一个根据down_buffer是不是连续三帧掉帧来判断是不是已经结束

        return start_time, end_time

    def jank_analysis(
        self,
        start_time,
        buffer_down_in_range: pd.DataFrame,
        ui_thread_state,
        render_thread_state,
    ):
        """
        判断间隔大于阈值的数据中，哪些是真的卡顿，哪些实际是滑动结束
        """

        jank_time: list[float] = []
        jank_start: list[float] = []
        jank_over_count: float = 0
        swipe_end = -1

        # 根据滑动时间段内的buffer下降的间隔，判断是不是卡顿。ts_diff是和上一次buffer下降的时间差
        threshold = self.swipe_data.jank_interval
        # 如果前三帧是连续的卡顿，则认为滑动已经提前结束了
        if len(buffer_down_in_range) >= 3:
            # 已 reset_index，索引为 0,1,2,...
            first3 = buffer_down_in_range.iloc[:3]
            first3_all_over = (first3["ts_diff"] >= threshold).all()

            if first3_all_over:
                swipe_end = buffer_down_in_range.iloc[0]["ts"]
                return jank_time, jank_start, jank_over_count

        over_threshold = buffer_down_in_range[
            buffer_down_in_range["ts_diff"] >= threshold
        ]  # 可能是卡顿的bufferTX

        for idx, row in over_threshold.iterrows():
            # 第一帧暂时不算到卡顿中
            if idx == 0:
                continue

            prev_ts = buffer_down_in_range.loc[idx - 1]["ts"]
            # 卡顿超过了800ms，就认为滑动已经结束了
            if row["ts_diff"] / 1e6 >= 800:
                # 找到上一个buffer down的位置作为滑动结束
                swipe_end = prev_ts
                return jank_time, jank_start, jank_over_count

            # TODO: 这里的逻辑存在问题，不能仅仅判断两次刷新间的线程状态，应该判断间的doframe间的状态，否则会出现滑动停止的误判
            # sleep_state = self.common.get_thread_state(prev_ts, row['ts'], ui_thread_state, "S", render_thread_state)
            # if sleep_state:
            #     # 上一个buffer down到当前buffer down中线程已经sleep，认为滑动结束
            #     swipe_end = prev_ts
            #     return jank_time, jank_start, jank_over_count
            exceed_amount = round(row["ts_diff"] - self.swipe_data.frame_interval, 2)
            jank_time.append(exceed_amount)

            # 取当前行的 ts 作为 jank_start
            prev_ts = buffer_down_in_range.loc[idx - 1]["ts"] if idx > 0 else start_time
            jank_start.append(prev_ts)
            # 计数累加
            jank_over_count += exceed_amount / self.swipe_data.frame_interval

        return jank_time, jank_start, jank_over_count

    def detect_stable_fps_range(self, vsync_data):
        """
        检测稳定帧率区间发生变化的位置
        :param vsync_data: DataFrame，包含 ts（时间戳，ms） 和 dur（帧间隔，ms）
        :return: (fps, 稳定区间列表)
        """
        global SWIPE_OFF_MIN_TIME
        vsync_ts = (vsync_data["ts"] / 1e6).to_list()

        stable_durations = self.common.detect_stable_vsync_regions(
            timestamps=vsync_ts,
            provide_intervals=False,
            expected_period_ms=self.swipe_data.frame_interval,
            win=3,
            residual_tau_ms=10,
            residual_p95_max_ms=40,
            residual_max_max_ms=40,
            outlier_ratio_max=0.5,
            min_region_len_ms=SWIPE_OFF_MIN_TIME,
        )

        return stable_durations
