import math

from metric_parser.trace.base.trace_processor_handler import TraceProcessorHandler
from metric_parser.utils.logger import ParseLogger

PROC_LIST = [
    "com.hihonor.iaware",
    "system_server",
    "com.hihonor.systemserver",
    "com.hihonor.brain",
    "com.hihonor.awareness",
    "com.hihonor.android.launcher",
    "com.android.systemui",
    "com.android.phone",
    "/system/bin/hwpged",
    "com.hihonor.hiview",
    "/system/bin/logd",
    "/system/bin/dubaid",
]

TAG = "CpuLoad"


class CpuLoad:
    """
    cpu load 分析主函数
    """

    def __init__(self):
        self.logger = ParseLogger("CpuLoad")
        self.tp = None
        self.segments = []

    def clmain(
        self,
        tp: TraceProcessorHandler,
        scene_type: str = "Swipe",
        start_ts: int = None,
        end_ts: int = None,
    ):
        """获取cpu load信息"""
        # 未输入查询时间段，查询全部
        self.tp = tp

        if start_ts is None or end_ts is None:
            sql = "SELECT MIN(ts) as min_ts, MAX(ts) as max_ts FROM sched"
            data = tp.query(sql)
            start_ts, end_ts = data[0].min_ts, data[0].max_ts

        self._get_segments(scene_type, start_ts, end_ts)

        final_results = {}
        for segment in self.segments:
            segment_result = self._all_cpuload(segment)
            for proc, value in segment_result.items():
                if not value:
                    continue
                if proc not in final_results:
                    final_results[proc] = [value]
                else:
                    final_results[proc].append(value)

        return final_results

    def _all_cpuload(self, segment, detect_procs: list = None):
        if detect_procs is None:
            detect_procs = PROC_LIST

        all_cpu_load = {}
        for proc_name in detect_procs:
            all_cpu_load[proc_name] = self._cal_cpu_usage_info(segment, proc_name)

        return all_cpu_load

    def _get_segments(self, scene_type, start_ts, end_ts):
        """根据不同的操作场景对 trace 做分段，返回时间区间列表"""
        self.segments = []
        if start_ts is None or end_ts is None:
            self.logger.e("未输入查询时间段")

        # 每段的持续时间（单位：纳秒）
        if scene_type == "Swipe":
            segment_duration_ns = 5_000_000_000
        elif scene_type == "InAppClick" or scene_type == "StartExitApp":
            segment_duration_ns = 1_000_000_000
        else:
            segment_duration_ns = 1_000_000_000

        total_duration_ns = int(end_ts - start_ts)
        # 分段数
        segment_count = total_duration_ns // segment_duration_ns + 1

        # 分段时间区间列表
        for i in range(segment_count):
            if i < segment_count - 1:
                segment_start = start_ts + segment_duration_ns * i
                if i < segment_count - 1:
                    segment_end = start_ts + segment_duration_ns * (i + 1)
                else:
                    segment_end = end_ts
                self.segments.append([segment_start, segment_end])

        return

    def _cal_cpu_usage_info(self, segment, proc_name):
        if not len(segment) == 2:
            self.logger.e("segment list illegal!!")

        start_ts = segment[0]
        end_ts = segment[1]
        if start_ts == end_ts:
            self.logger.e("开始结束时间不能相同")
            return []

        sql = f"""
            SELECT process.name AS proc_name, SUM(dur) AS cpu_ns 
            FROM sched 
            JOIN thread USING(utid) 
            JOIN process USING(upid)
            WHERE ts >= {start_ts} 
             AND ts <= {end_ts}
             AND process.name = '{proc_name}'
             GROUP BY upid
             ORDER BY cpu_ns DESC
            """
        data = self.tp.query(sql)
        result = []
        if not data.empty:
            cpu_ns = data.iloc[0].cpu_ns / 1e6
            duration = (end_ts - start_ts) / 1e6
            rate = round(cpu_ns / duration, 2) if duration != 0 else math.inf
            result = [
                start_ts,
                end_ts,
                cpu_ns,
                duration,
                cpu_ns / duration,
            ]  # 起始时间戳、结束时间戳、运行时长、统计时长、使用率
        return result
