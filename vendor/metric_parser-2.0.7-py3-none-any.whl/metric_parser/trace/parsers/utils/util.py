def is_all_none(dataframe):
    """
    判断 Pandas DataFrame 的所有值是否都是 None。

    参数:
        dataframe (pd.DataFrame): 输入的 Pandas DataFrame。

    返回:
        bool: 如果所有值都是 None，返回 True；否则返回 False。
    """
    # 检查 DataFrame 是否为空
    if dataframe.empty:
        return True

    # 使用 DataFrame 的 `isnull()` 方法检查所有值是否为 None
    return dataframe.isnull().all().all()
