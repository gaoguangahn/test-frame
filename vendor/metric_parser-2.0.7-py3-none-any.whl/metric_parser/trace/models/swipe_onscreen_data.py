from dataclasses import dataclass, field

import pandas as pd


@dataclass
class SwipeOnScreenData:
    """内部解析状态流转类"""

    upid: int | None = None
    ui_utid: int | None = None
    render_utid: int | None = None
    sf_utid: int | None = None
    buffer_counters: pd.DataFrame = field(default_factory=pd.DataFrame)
    buffer_down_counters: pd.DataFrame = field(default_factory=pd.DataFrame)
    vsync_sf: pd.DataFrame = field(default_factory=pd.DataFrame)
    vsync_app: pd.DataFrame = field(default_factory=pd.DataFrame)
    ui_slices: pd.DataFrame = field(default_factory=pd.DataFrame)
    fps: int | None = None
    frame_interval: float | None = None
    jank_interval: float | None = None
    direction: str = "vertical"


@dataclass
class SwipeOnScreenResult:
    """对外输出的强类型结果类"""

    package: str
    activity: str
    on_deliver_start: int
    on_deliver_end: int
    jank: list[tuple[int, float]]
    count: int
