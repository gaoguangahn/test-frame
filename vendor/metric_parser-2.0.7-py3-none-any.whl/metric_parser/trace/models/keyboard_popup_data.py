from dataclasses import asdict, dataclass, field

import pandas as pd


@dataclass
class KeyboardPopupData:
    """内部解析状态流转类"""

    package_name: str = ""
    upid: int = -1
    new_activity: str = "unknown"
    launching_time: tuple[int, int] = field(default_factory=lambda: (-1, -1))
    deliver_ts: int = -1
    deliver_te: int = -1
    deliver_data: pd.DataFrame = field(default_factory=pd.DataFrame)
    animator_time: tuple[int, int] = field(default_factory=lambda: (-1, -1))
    animator_fps: int = -1
    response_time: int = -1
    target_first_frame: int = -1
    spend_time: int = -1
    startup_type: str = "unknown"
    animator_type: str = "unknown"
    thread_states: list[dict] = field(default_factory=list)
    animation_frames: list[float] = field(default_factory=list)
    transaction_frames: list[float] = field(default_factory=list)


@dataclass
class KeyboardPopupResult:
    """对外输出的强类型结果类"""

    name: str
    op_start: int
    animator_type: str
    response_time: int
    animator_time: int
    animator_fps: int
    animation_frames: list[float]

    def to_dict(self):
        return asdict(self)
