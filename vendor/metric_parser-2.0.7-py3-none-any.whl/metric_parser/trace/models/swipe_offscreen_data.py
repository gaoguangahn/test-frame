from dataclasses import asdict, dataclass, field

import pandas as pd
from pandas import DataFrame


@dataclass
class SwipeOffScreenData:
    upid: int | None = None
    ui_utid: int | None = None
    render_utid: int | None = None
    sf_utid: int | None = None
    # 滑动打点
    swipe_key_pairs: list[tuple[int, int]] = field(default_factory=list)
    # RV Scroll 相关数据帧
    RVScroll_data: pd.DataFrame = field(default_factory=pd.DataFrame)
    # targetBuf 事件
    targetBuf: pd.DataFrame = field(default_factory=pd.DataFrame)
    # bufferTx 相关数据帧
    buffer_counters: pd.DataFrame = field(default_factory=pd.DataFrame)
    buffer_down_counters: pd.DataFrame = field(default_factory=pd.DataFrame)
    # vsync 相关数据帧
    vsync_sf: pd.DataFrame = field(default_factory=pd.DataFrame)
    vsync_app: pd.DataFrame = field(default_factory=pd.DataFrame)
    fps: int | None = None
    frame_interval: float | None = None
    jank_interval: float | None = None

    def set_tids(self, upid: int, ui_utid: int, render_utid: int, sf_utid: int) -> None:
        """一次性更新与进程/线程相关的标识，便于校验与日志"""
        self.upid = upid
        self.ui_utid = ui_utid
        self.render_utid = render_utid
        self.sf_utid = sf_utid

    def get_tids(self):
        """一次性取出所有的tid"""
        return self.upid, self.ui_utid, self.render_utid, self.sf_utid

    def set_fps_info(
        self, fps: int, frame_interval: float, jank_interval: float
    ) -> None:
        self.fps = fps
        self.frame_interval = frame_interval
        self.jank_interval = jank_interval

    def get_fps_info(self):
        return self.fps, self.frame_interval, self.jank_interval

    def set_judge_data(
        self,
        key_df: list[tuple[int, int]],
        rv_df: pd.DataFrame,
        target_df: pd.DataFrame,
    ):
        self.RVScroll_data = rv_df
        self.targetBuf = target_df
        self.swipe_key_pairs = key_df

    def get_judge_data(self):
        return self.swipe_key_pairs, self.RVScroll_data, self.targetBuf

    def set_buffer_counters(
        self, counters: pd.DataFrame, down_counters: pd.DataFrame | None = None
    ) -> None:
        self.buffer_counters = counters
        if down_counters is not None:
            self.buffer_down_counters = down_counters

    def get_buffer_counters(self) -> tuple[DataFrame, DataFrame]:
        return self.buffer_counters, self.buffer_down_counters

    def set_vsync(self, sf_df: pd.DataFrame, app_df: pd.DataFrame) -> None:
        self.vsync_sf = sf_df
        self.vsync_app = app_df

    def get_vsync(self) -> tuple[DataFrame, DataFrame]:
        return self.vsync_sf, self.vsync_app


@dataclass
class SwipeOffScreenResult:
    """对外输出的强类型结果类"""

    package: str
    activity: str
    op_start: int
    on_deliver_start: int
    off_jank: list[tuple[int, float]]
    off_count: int
    off_avg_fps: float
    on_jank: list[tuple[int, float]]
    on_count: int
    on_avg_fps: float

    def to_dict(self):
        return asdict(self)
