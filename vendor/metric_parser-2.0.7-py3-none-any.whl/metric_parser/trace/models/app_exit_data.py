from dataclasses import asdict, dataclass, field


@dataclass
class AppExitData:
    """内部解析状态流转类"""

    name: str = ""
    upid: int = -1
    animator_process: str = ""
    launching_time: tuple[int, int] = field(default_factory=lambda: (-1, -1))
    animator_time: tuple[int, int] = field(default_factory=lambda: (-1, -1))
    animator_fps: int = -1
    sf_timelines: dict[str, int] = field(default_factory=dict)
    animation_frames: list[float] = field(default_factory=list)
    transaction_frames: list[float] = field(default_factory=list)
    type: str = ""


@dataclass
class ExitAnimationResult:
    """对外输出的强类型结果类"""

    name: str
    op_start: int
    animator_time: float
    animator_fps: int
    animation_frames: list[float]
    transaction_frames: list[float]

    def to_dict(self):
        return asdict(self)
