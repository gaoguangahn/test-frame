from dataclasses import asdict, dataclass, field


@dataclass
class ControlCenterData:
    """内部解析状态流转类"""

    upid: int = -1
    animator_time: tuple[int, int] = field(default_factory=lambda: (-1, -1))
    animator_fps: int = -1
    animation_frames: list[float] = field(default_factory=list)


@dataclass
class ControlCenterResult:
    """对外输出的强类型结果类"""

    op_start: int
    animator_time: int
    animator_fps: int
    animation_frames: list[float]

    def to_dict(self):
        return asdict(self)
