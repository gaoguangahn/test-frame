from dataclasses import asdict, dataclass, field


@dataclass
class MultiTaskData:
    """内部解析状态流转类"""

    animator_time: tuple[int, int] = field(default_factory=lambda: (-1, -1))
    animation_frames: list[float] = field(default_factory=list)
    animator_fps: int = -1


@dataclass
class MultiTaskResult:
    """对外输出的强类型结果类"""

    op_start: int
    animator_time: int
    animator_fps: int
    animation_frames: list[float]

    def to_dict(self):
        return asdict(self)
