import json
import os


class LogContext:
    """日志上下文"""

    def __init__(self, file_path: str, device_brand: str = "Honor"):

        self.file_path = file_path

        self.device_brand = device_brand

        # 文件名
        self.name = os.path.basename(file_path)
        # 不带后缀文件名
        self.stem = os.path.splitext(self.name)[0]
        # 后缀
        self.suffix = os.path.splitext(self.name)[1]
        # 目录
        self.parent = os.path.dirname(file_path)

        self._json_data = None

    @property
    def json_data(self):
        """懒加载 JSON 数据"""

        if self._json_data is not None:
            return self._json_data

        try:
            with open(self.file_path, "r", encoding="utf-8", errors="ignore") as f:
                self._json_data = json.load(f)

        except Exception:
            self._json_data = {}

        return self._json_data

    def iter_lines(self, encoding="utf-8", errors="ignore"):
        """流式读取日志"""

        with open(self.file_path, "r", encoding=encoding, errors=errors) as f:
            for line in f:
                yield line

    def __enter__(self):

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):

        return False
