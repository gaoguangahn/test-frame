class AnalyseError(Exception):
    """
    日志分析异常
    """
