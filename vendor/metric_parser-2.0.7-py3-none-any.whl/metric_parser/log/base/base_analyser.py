# metric_parser/log/base/base_analyser.py

from abc import ABC, abstractmethod

from metric_parser.utils.logger import ParseLogger

from .result import AnalyseResult


class BaseLogAnalyse(ABC):
    """
    日志分析器抽象基类
    """

    def __init__(self, context):

        self.context = context
        self.logger = ParseLogger(self.__class__.__name__)

    @abstractmethod
    def analyse(self, **kwargs) -> AnalyseResult:
        """所有 analyser 必须实现"""

    def success(self, data) -> AnalyseResult:

        return AnalyseResult(success=True, data=data)

    def fail(self, error) -> AnalyseResult:

        return AnalyseResult(success=False, error=str(error))
