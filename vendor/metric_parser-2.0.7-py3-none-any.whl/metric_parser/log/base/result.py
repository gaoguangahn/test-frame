from dataclasses import asdict, dataclass
from typing import Any


@dataclass
class AnalyseResult:
    success: bool

    data: Any = None

    error: str = ""

    def to_dict(self):

        return asdict(self)
