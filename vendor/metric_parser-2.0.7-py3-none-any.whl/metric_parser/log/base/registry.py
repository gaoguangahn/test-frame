class AnalyseRegistry:
    """
    日志分析器注册表
    """

    _registry: dict = {}

    @classmethod
    def register(cls, log_type: str, desc: str = "", version: str = "1.0"):

        def decorator(analyser_cls):

            cls._registry[log_type] = {
                "class": analyser_cls,
                "desc": desc,
                "version": version,
            }

            return analyser_cls

        return decorator

    @classmethod
    def get_analyser(cls, log_type: str):

        item = cls._registry.get(log_type)

        if not item:
            return None

        return item["class"]

    @classmethod
    def list_all(cls):

        return {
            k: {
                "class": v["class"].__name__,
                "desc": v["desc"],
                "version": v["version"],
            }
            for k, v in cls._registry.items()
        }
