from dataclasses import dataclass


@dataclass
class DumpsysMeminfoResult:
    free_ram: str | None = None
    dma_buf_mapped: str | None = None
    dma_buf_unmapped: str | None = None
    gpu_dmabuf: str | None = None
    gpu_private: str | None = None
    used_ram_usedpss: str | None = None
    used_ram_kernel: str | None = None
    zram_physical_used: str | None = None
    zram_swap: str | None = None
    zram_total_swap: str | None = None
