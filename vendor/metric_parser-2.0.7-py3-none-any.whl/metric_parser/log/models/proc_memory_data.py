from dataclasses import dataclass, field
from typing import Any


@dataclass
class ProcMemoryResult:
    # 明确计算的特殊字段
    direct_reclaim: int = 0
    # 其他从 json 动态匹配的指标统一存放在这里
    metrics: dict[str, Any] = field(default_factory=dict)
