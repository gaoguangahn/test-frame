from datetime import datetime

read_file_max_size = 10000000

FLAG_RECEIVER_OFFLOAD = 0x80000000
FLAG_RECEIVER_FOREGROUND = 0x10000000
FLAG_RECEIVER_KEY_QUEUE = 0x00001000
FLAG_RECEIVER_THIRDAPP_QUEUE = 0x00002000
FLAG_IS_ALARM_BROADCAST = 1 << 3
FLAG_INTERACTIVE = 1 << 5

FIRST_APPLICATION_UID = 10000

DELIVERY_PENDING = "PENDING"
DELIVERY_DELIVERED = "DELIVERED"
DELIVERY_DELIVERED_T = "Deliver"
DELIVERY_SKIPPED = "SKIPPED"
DELIVERY_SKIPPED_T = "Skipped"
DELIVERY_TIMEOUT = "TIMEOUT"
DELIVERY_SCHEDULED = "SCHEDULED"
DELIVERY_FAILURE = "FAILURE"
DELIVERY_DEFERRED = "DEFERRED"

IAWARE = "iaware"

REMOTE_APP = "remote app"
REMOTE = "remote"

# 广播统计数据表头关键字
broadcast_status_column = [
    "collection_begin_time",
    "collection_end_time",
    "system_br_cnt(0<uid<10000)",
    "third_br_cnt(uid>10000)",
    "sticky_br_cnt(uid=-1)",
    "mainfest_receiver_cnt",
    "receiverFilter_cnt",
    "remote_binder_cnt",
    "receiver_cnt",
    "iaware_ctrl_receiver_cnt",
    "aosp_skip_receiver_cnt",
    "avg_fg_br_scheduled_latency(ms)",
    "fg_br_scheduled_latency(64~256ms)",
    "fg_br_scheduled_latency(256~500ms)",
    "fg_br_scheduled_latency(>500ms)",
    "avg_bg_br_scheduled_latency(ms)",
    "bg_br_scheduled_latency(128~500ms)",
    "bg_br_scheduled_latency(500~1000ms)",
    "bg_br_scheduled_latency(>1000ms)",
    "avg_offload_br_scheduled_latency(ms)",
    "offload_br_scheduled_latency(128~500ms)",
    "offload_br_scheduled_latency(500~1000ms)",
    "offload_br_scheduled_latency(>1000ms)",
    "avg_key_br_scheduled_latency(ms)",
    "key_br_scheduled_latency(64~256ms)",
    "key_br_scheduled_latency(256~500ms)",
    "key_br_scheduled_latency(>500ms)",
    "avg_receiverFilter_terminal_latency(ms)",
    "receiverFilter_terminal_latency(16~64ms)",
    "receiverFilter_terminal_latency(64~128ms)",
    "receiverFilter_terminal_latency(>128ms)",
    "avg_mainfest_terminal_latency(ms)",
    "mainfest_terminal_latency(64~256ms)",
    "mainfest_terminal_latency(256~512ms)",
    "mainfest_terminal_latency(>512ms)",
]


class ParseBroadcastDumpFile:
    @staticmethod
    # 获得解析后的数据采集开始时间和结束时间
    def get_br_collection_time(dump_path):
        result_map = {"collection_begin_time": "", "collection_end_time": ""}

        # 检查文件名格式
        if (not dump_path["start_path"].split("\\")[-1].endswith(".txt")) or (
            len(dump_path["start_path"].split("\\")[-1].split("_")) != 12
        ):
            print(
                "[broadcast] -> this file format does not comply with settings"
                + str(dump_path["start_path"].split("\\")[-1])
            )
            return result_map
        if (not dump_path["end_path"].split("\\")[-1].endswith(".txt")) or (
            len(dump_path["end_path"].split("\\")[-1].split("_")) != 12
        ):
            print(
                "[broadcast] -> this file format does not comply with settings"
                + str(dump_path["end_path"].split("\\")[-1])
            )
            return result_map

        for time_str in dump_path["start_path"].split("\\")[-1].split("_")[5:10]:
            result_map["collection_begin_time"] += time_str

        for time_str in dump_path["end_path"].split("\\")[-1].split("_")[5:10]:
            result_map["collection_end_time"] += time_str
        return result_map

    @staticmethod
    # 获得解析后的广播生命周期信息
    def get_br_detail(txt_br, queue_name):
        parsed_br_detail_list = [None] * 29
        parsed_receiver_delivery_List = []
        br_action = "na"
        intent_data = "na"
        intent_type = "na"
        flg = "na"
        hwFlg = "na"
        options = "na"
        options_deferralPolicy = "na"
        options_flg = "na"
        target_comp = "na"
        target_pkg = "na"
        caller_pkg = "na"
        caller_pkg_uid = "na"
        required_permissions = "na"
        enqueue_clock_time = "na"
        dispatch_clock_time = "na"
        dispatch_latency = "na"
        complete_latency = "na"
        result_to = "na"
        iaware_ctrl_type = "0"
        is_urgent = 0
        is_offload = 0
        is_defer_until_active = 0
        result_abort = 0
        ordered = 0
        sticky = 0
        initialSticky = 0

        for intent_item in txt_br[2].split():
            if intent_item.startswith("act="):
                br_action = intent_item[4:]
            elif intent_item.startswith("dat="):
                intent_data = intent_item[4:]
            elif intent_item.startswith("typ="):
                intent_type = intent_item[4:]
            elif intent_item.startswith("flg="):
                flg = intent_item[4:]
            elif intent_item.startswith("hwFlg="):
                hwFlg = intent_item[6:]
            elif intent_item.startswith("pkg="):
                target_pkg = intent_item[4:]
            else:
                pass

        receiver_list = []
        receiver_start_index = len(txt_br)
        for item_index in range(3, len(txt_br)):
            if " #" in txt_br[item_index]:
                receiver_list.append(item_index)
        if len(receiver_list) == 0:
            # print("[broadcast] -> this broadcast receiver_list is null: " + str(txt_br[1]))
            pass
        else:
            receiver_start_index = receiver_list[0]

        for item_index in range(3, receiver_start_index):
            if "     targetComp: {" in txt_br[item_index]:
                target_comp = txt_br[item_index][19:-2]
            elif "   caller=" in txt_br[item_index]:
                for caller_info_item in txt_br[item_index].split():
                    if caller_info_item.startswith("caller="):
                        caller_pkg = caller_info_item[7:]
                    elif caller_info_item.startswith("pid="):
                        caller_pkg_pid = caller_info_item[4:]
                    elif caller_info_item.startswith("uid="):
                        caller_pkg_uid = caller_info_item[4:]
                    elif caller_info_item.startswith("iawareFromProxy=") and (
                        "iawareFromProxy=false" not in caller_info_item
                    ):
                        iaware_ctrl_type = "1"
                    elif caller_info_item.startswith("iawareCtrlType=") and (
                        "iawareCtrlType=0" not in caller_info_item
                    ):
                        iaware_ctrl_type = caller_info_item[15:]
            elif "    enqueueClockTime=" in txt_br[item_index]:
                clockTime_info_list = txt_br[item_index].split("=")
                enqueue_clock_time = clockTime_info_list[1][:-18]
                dispatch_clock_time = clockTime_info_list[2][:-1]
            elif "    dispatchTime=" in txt_br[item_index]:
                latency_info_list = txt_br[item_index].split()
                if not ParseBroadcastDumpFile.is_zero_time(enqueue_clock_time):
                    dispatch_latency = latency_info_list[1][1:]
                complete_latency = latency_info_list[5][1:]
            elif "    resultTo=" in txt_br[item_index]:
                properties_list = txt_br[item_index].split()
                if properties_list[0].split("=")[1] != "null":
                    result_to = "unnull"
            elif "    resultAbort=" in txt_br[item_index]:
                properties_list = txt_br[item_index].split()
                result_abort = ParseBroadcastDumpFile.str_bool_to_int(
                    properties_list[0][12:]
                )
                ordered = ParseBroadcastDumpFile.str_bool_to_int(properties_list[1][8:])
                sticky = ParseBroadcastDumpFile.str_bool_to_int(properties_list[2][7:])
                initialSticky = ParseBroadcastDumpFile.str_bool_to_int(
                    properties_list[3][14:]
                )
            elif "    requiredPermissions=" in txt_br[item_index]:
                permissions_list = txt_br[item_index].split()
                required_permissions = permissions_list[0][21:-1]
            elif "    extras:" in txt_br[item_index]:
                extras = txt_br[item_index][14:-1]
            elif "    options=" in txt_br[item_index]:
                for options_item in txt_br[item_index][14:-1].split(", "):
                    if "android:broadcast.deferralPolicy=" in options_item:
                        options_deferralPolicy = options_item.split("=")[1].replace(
                            "}]", ""
                        )
                    if "android:broadcast.flags=" in options_item:
                        options_flg = options_item.split("=")[1].replace("}]", "")
            else:
                pass

        dispatch_latency_ms = ParseBroadcastDumpFile.to_format_duration_ms(
            dispatch_latency
        )
        complete_latency_ms = ParseBroadcastDumpFile.to_format_duration_ms(
            complete_latency
        )
        is_offload = ParseBroadcastDumpFile.is_offload_br(flg)
        is_urgent = ParseBroadcastDumpFile.is_urgent_br(flg, options_flg)
        is_defer_until_active = ParseBroadcastDumpFile.is_defer_until_active_br(
            ordered,
            result_to,
            options_deferralPolicy,
            is_urgent,
            caller_pkg_uid,
            br_action,
        )

        parsed_br_detail_list[0] = br_action
        parsed_br_detail_list[1] = queue_name
        parsed_br_detail_list[2] = caller_pkg
        parsed_br_detail_list[3] = caller_pkg_uid
        parsed_br_detail_list[4] = len(receiver_list)
        parsed_br_detail_list[5] = txt_br[1].split()[-1]
        parsed_br_detail_list[6] = enqueue_clock_time
        parsed_br_detail_list[7] = dispatch_clock_time
        parsed_br_detail_list[8] = dispatch_latency
        parsed_br_detail_list[9] = complete_latency
        parsed_br_detail_list[10] = is_urgent
        parsed_br_detail_list[11] = is_offload
        parsed_br_detail_list[12] = is_defer_until_active
        parsed_br_detail_list[13] = result_abort
        parsed_br_detail_list[14] = ordered
        parsed_br_detail_list[15] = sticky
        parsed_br_detail_list[16] = initialSticky
        parsed_br_detail_list[17] = iaware_ctrl_type
        parsed_br_detail_list[18] = flg
        parsed_br_detail_list[19] = hwFlg
        parsed_br_detail_list[20] = target_comp
        parsed_br_detail_list[21] = target_pkg
        parsed_br_detail_list[22] = result_to
        parsed_br_detail_list[23] = options_deferralPolicy
        parsed_br_detail_list[24] = options_flg
        parsed_br_detail_list[25] = intent_type
        parsed_br_detail_list[26] = required_permissions
        parsed_br_detail_list[27] = dispatch_latency_ms
        parsed_br_detail_list[28] = complete_latency_ms
        parsed_receiver_delivery_List = (
            ParseBroadcastDumpFile.get_receiver_delivery_list(
                txt_br, receiver_list, parsed_br_detail_list
            )
        )
        return [parsed_br_detail_list, parsed_receiver_delivery_List]

    # 广播接收者详细信息“解码”
    def get_receiver_delivery_list(txt_br, receiver_list, parsed_br_detail_list):
        parsed_receiver_delivery_List = []
        receiver_list.append(len(txt_br))
        for item_index in range(len(receiver_list)):
            if item_index < (len(receiver_list) - 1):
                br_receiver_entry_list = []
                receiver_start_index = int(receiver_list[item_index])
                receiver_end_index = int(receiver_list[item_index + 1] - 1)
                if receiver_start_index == receiver_end_index:
                    br_receiver_entry_list = (
                        ParseBroadcastDumpFile.get_one_receiver_delivery_list(
                            [txt_br[receiver_start_index]], parsed_br_detail_list
                        )
                    )
                else:
                    br_receiver_entry_list = (
                        ParseBroadcastDumpFile.get_one_receiver_delivery_list(
                            txt_br[receiver_start_index : receiver_end_index + 1],
                            parsed_br_detail_list,
                        )
                    )
                if len(br_receiver_entry_list) > 0:
                    parsed_receiver_delivery_List.append(br_receiver_entry_list)
        return parsed_receiver_delivery_List

    # 单条广播接收者详细信息“解码”
    def get_one_receiver_delivery_list(txt_receiver, parsed_br_detail_list):
        br_receiver_entry_list = [None] * 26
        br_action = parsed_br_detail_list[0]
        queue_name = parsed_br_detail_list[1]
        receiver_name = "na"
        receiver_pkg_name = "na"
        receiver_process_name = "na"
        receiver_type = 0
        delivery_state = "na"
        reason = "na"
        receiver_pkg_uid = "na"
        receiver_userid = "na"
        binder_type = "na"
        binder_detail = "na"
        scheduled_latency = "na"
        terminal_latency = "na"
        receiver_index = "na"
        receiver_blocked_count = "na"
        caller_pkg = parsed_br_detail_list[2]
        caller_pkg_uid = parsed_br_detail_list[3]
        receiver_size = parsed_br_detail_list[4]
        userid = parsed_br_detail_list[5]
        is_urgent = parsed_br_detail_list[10]
        is_offload = parsed_br_detail_list[11]
        ordered = parsed_br_detail_list[14]
        result_to = parsed_br_detail_list[22]
        is_defer_until_active = parsed_br_detail_list[12]
        iaware_ctrl_type = parsed_br_detail_list[17]
        if ": (manifest)" in txt_receiver[0]:
            # 静态注册接收者填写
            receiver_type = 1
            broadcast_filter_list = txt_receiver[0].split()
            if " terminal " in txt_receiver[0]:
                delivery_state = broadcast_filter_list[0]
                for item_index in range(len(broadcast_filter_list)):
                    if "scheduled" == broadcast_filter_list[item_index]:
                        scheduled_latency = broadcast_filter_list[item_index + 1]
                    elif "terminal" == broadcast_filter_list[item_index]:
                        terminal_latency = broadcast_filter_list[item_index + 1]
                    elif "(manifest)" in broadcast_filter_list[item_index]:
                        receiver_index = broadcast_filter_list[item_index - 1][1:-1]
                        receiver_blocked_count = broadcast_filter_list[item_index - 2][
                            1:-1
                        ]
            else:
                delivery_state = broadcast_filter_list[0]
                scheduled_latency = parsed_br_detail_list[27]
                terminal_latency = broadcast_filter_list[1]
                receiver_index = broadcast_filter_list[2][1:-1]
            for item_index in range(len(txt_receiver)):
                if "name=" in txt_receiver[item_index]:
                    receiver_name = txt_receiver[item_index][13:]
                elif "packageName=" in txt_receiver[item_index]:
                    receiver_pkg_name = txt_receiver[item_index][20:]
                elif "processName=" in txt_receiver[item_index]:
                    receiver_process_name = txt_receiver[item_index][20:]
                elif "reason:" in txt_receiver[item_index]:
                    reason = txt_receiver[item_index][16:]
                else:
                    pass
            pass
        elif ": BroadcastFilter{" in txt_receiver[0]:
            # 动态注册接收者填写
            receiver_type = 2
            broadcast_filter_list = txt_receiver[0].split()
            if " terminal " in txt_receiver[0]:
                delivery_state = broadcast_filter_list[0]
                for item_index in range(len(broadcast_filter_list)):
                    if "scheduled" == broadcast_filter_list[item_index]:
                        scheduled_latency = broadcast_filter_list[item_index + 1]
                    elif "terminal" == broadcast_filter_list[item_index]:
                        terminal_latency = broadcast_filter_list[item_index + 1]
                    elif "ReceiverList{" in broadcast_filter_list[item_index]:
                        receiver_process_name = broadcast_filter_list[
                            item_index + 2
                        ].split("/")[0]
                        receiver_pkg_uid = broadcast_filter_list[item_index + 2].split(
                            "/"
                        )[1]
                        receiver_userid = broadcast_filter_list[item_index + 2].split(
                            "/"
                        )[2]
                        binder_type = broadcast_filter_list[item_index + 3].split(":")[
                            0
                        ]
                        binder_detail = broadcast_filter_list[item_index + 3].split(
                            ":"
                        )[1]
                    elif "BroadcastFilter{" in broadcast_filter_list[item_index]:
                        receiver_index = broadcast_filter_list[item_index - 1][1:-1]
                        receiver_blocked_count = broadcast_filter_list[item_index - 2][
                            1:-1
                        ]
                    else:
                        pass
            else:
                delivery_state = broadcast_filter_list[0]
                scheduled_latency = parsed_br_detail_list[27]
                terminal_latency = broadcast_filter_list[1]
                receiver_index = broadcast_filter_list[2][1:-1]
                receiver_process_name = broadcast_filter_list[7].split("/")[0]
                receiver_pkg_uid = broadcast_filter_list[7].split("/")[1]
                receiver_userid = broadcast_filter_list[7].split("/")[2]
                binder_type = broadcast_filter_list[8].split(":")[0]
                binder_detail = broadcast_filter_list[8].split(":")[1]
                pass
            for item_index in range(len(txt_receiver)):
                if " reason: " in txt_receiver[item_index]:
                    reason = txt_receiver[item_index][16:]
        else:
            pass

        # only for T aosp
        if (reason == "na") and (delivery_state == DELIVERY_DELIVERED_T):
            if (receiver_type == 1) or (ordered == 1) or (result_to != "na"):
                reason = REMOTE_APP

        scheduled_latency_ms = ParseBroadcastDumpFile.to_format_duration_ms(
            scheduled_latency
        )
        terminal_latency_ms = ParseBroadcastDumpFile.to_format_duration_ms(
            terminal_latency
        )

        br_receiver_entry_list[0] = br_action
        br_receiver_entry_list[1] = queue_name
        br_receiver_entry_list[2] = receiver_process_name
        br_receiver_entry_list[3] = receiver_type
        br_receiver_entry_list[4] = delivery_state
        br_receiver_entry_list[5] = scheduled_latency
        br_receiver_entry_list[6] = terminal_latency
        br_receiver_entry_list[7] = receiver_blocked_count
        br_receiver_entry_list[8] = receiver_index
        br_receiver_entry_list[9] = receiver_pkg_uid
        br_receiver_entry_list[10] = receiver_userid
        br_receiver_entry_list[11] = binder_type
        br_receiver_entry_list[12] = caller_pkg
        br_receiver_entry_list[13] = caller_pkg_uid
        br_receiver_entry_list[14] = is_urgent
        br_receiver_entry_list[15] = is_offload
        br_receiver_entry_list[16] = is_defer_until_active
        br_receiver_entry_list[17] = receiver_size
        br_receiver_entry_list[18] = userid
        br_receiver_entry_list[19] = binder_detail
        br_receiver_entry_list[20] = reason
        br_receiver_entry_list[21] = receiver_name
        br_receiver_entry_list[22] = receiver_pkg_name
        br_receiver_entry_list[23] = scheduled_latency_ms
        br_receiver_entry_list[24] = terminal_latency_ms
        br_receiver_entry_list[25] = iaware_ctrl_type
        return br_receiver_entry_list

    def get_br_status_map(parsed_receiver_delivery_List):
        result_map = {}
        for br_column_item in broadcast_status_column[2:]:
            result_map[br_column_item] = 0
        avg_key_br_scheduled_latency_cnt = 0
        avg_fg_br_scheduled_latency_cnt = 0
        avg_offload_br_scheduled_latency_cnt = 0
        avg_bg_br_scheduled_latency_cnt = 0
        avg_receiverFilter_terminal_latency_cnt = 0
        avg_mainfest_terminal_latency_cnt = 0
        iaware_ctrl_type_br_cnt = 0

        for br_receiver_entry_list in parsed_receiver_delivery_List:
            if br_receiver_entry_list[13] != "na":
                if (
                    int(br_receiver_entry_list[13]) >= 0
                    and int(br_receiver_entry_list[13]) < FIRST_APPLICATION_UID
                ):
                    result_map["system_br_cnt(0<uid<10000)"] += 1
                elif int(br_receiver_entry_list[13]) >= FIRST_APPLICATION_UID:
                    result_map["third_br_cnt(uid>10000)"] += 1
                elif int(br_receiver_entry_list[13]) == -1:
                    result_map["sticky_br_cnt(uid=-1)"] += 1
                else:
                    pass

            if br_receiver_entry_list[3] == 1:
                result_map["mainfest_receiver_cnt"] += 1
                result_map["remote_binder_cnt"] += 1
            elif br_receiver_entry_list[3] == 2:
                result_map["receiverFilter_cnt"] += 1
                if br_receiver_entry_list[11] == REMOTE:
                    result_map["remote_binder_cnt"] += 1
            else:
                pass

            if br_receiver_entry_list[25] == "1":
                iaware_ctrl_type_br_cnt += 1
            result_map["receiver_cnt"] += 1

            if br_receiver_entry_list[4] != "na":
                if (br_receiver_entry_list[4] == DELIVERY_SKIPPED) or (
                    br_receiver_entry_list[4] == DELIVERY_SKIPPED_T
                ):
                    if br_receiver_entry_list[20] != "na" and br_receiver_entry_list[
                        20
                    ].startswith(IAWARE):
                        result_map["iaware_ctrl_receiver_cnt"] += 1
                    else:
                        result_map["aosp_skip_receiver_cnt"] += 1
                elif (
                    br_receiver_entry_list[4] == DELIVERY_DELIVERED
                    or br_receiver_entry_list[4] == DELIVERY_DELIVERED_T
                ):
                    scheduled_latency_ms = br_receiver_entry_list[23]
                    terminal_latency_ms = br_receiver_entry_list[24]
                    if not isinstance(scheduled_latency_ms, str):
                        if (br_receiver_entry_list[1] != "na") and (
                            "key" in br_receiver_entry_list[1]
                        ):
                            result_map["avg_key_br_scheduled_latency(ms)"] += (
                                scheduled_latency_ms
                            )
                            avg_key_br_scheduled_latency_cnt += 1
                            if (
                                scheduled_latency_ms >= 64
                                and scheduled_latency_ms < 256
                            ):
                                result_map["key_br_scheduled_latency(64~256ms)"] += 1
                            elif (
                                scheduled_latency_ms >= 256
                                and scheduled_latency_ms < 500
                            ):
                                result_map["key_br_scheduled_latency(256~500ms)"] += 1
                            elif scheduled_latency_ms >= 500:
                                result_map["key_br_scheduled_latency(>500ms)"] += 1
                            else:
                                pass
                        if br_receiver_entry_list[14] == 1:
                            result_map["avg_fg_br_scheduled_latency(ms)"] += (
                                scheduled_latency_ms
                            )
                            avg_fg_br_scheduled_latency_cnt += 1
                            if (
                                scheduled_latency_ms >= 64
                                and scheduled_latency_ms < 256
                            ):
                                result_map["fg_br_scheduled_latency(64~256ms)"] += 1
                            elif (
                                scheduled_latency_ms >= 256
                                and scheduled_latency_ms < 500
                            ):
                                result_map["fg_br_scheduled_latency(256~500ms)"] += 1
                            elif scheduled_latency_ms >= 500:
                                result_map["fg_br_scheduled_latency(>500ms)"] += 1
                            else:
                                pass
                        elif br_receiver_entry_list[15] == 1:
                            result_map["avg_offload_br_scheduled_latency(ms)"] += (
                                scheduled_latency_ms
                            )
                            avg_offload_br_scheduled_latency_cnt += 1
                            if (
                                scheduled_latency_ms >= 128
                                and scheduled_latency_ms < 500
                            ):
                                result_map[
                                    "offload_br_scheduled_latency(128~500ms)"
                                ] += 1
                            elif (
                                scheduled_latency_ms >= 500
                                and scheduled_latency_ms < 1000
                            ):
                                result_map[
                                    "offload_br_scheduled_latency(500~1000ms)"
                                ] += 1
                            elif scheduled_latency_ms >= 1000:
                                result_map["offload_br_scheduled_latency(>1000ms)"] += 1
                            else:
                                pass
                        else:
                            result_map["avg_bg_br_scheduled_latency(ms)"] += (
                                scheduled_latency_ms
                            )
                            avg_bg_br_scheduled_latency_cnt += 1
                            if (
                                scheduled_latency_ms >= 128
                                and scheduled_latency_ms < 500
                            ):
                                result_map["bg_br_scheduled_latency(128~500ms)"] += 1
                            elif (
                                scheduled_latency_ms >= 500
                                and scheduled_latency_ms < 1000
                            ):
                                result_map["bg_br_scheduled_latency(500~1000ms)"] += 1
                            elif scheduled_latency_ms >= 1000:
                                result_map["bg_br_scheduled_latency(>1000ms)"] += 1
                            else:
                                pass
                    # terminal_latency
                    if (
                        br_receiver_entry_list[20] != "na"
                        and br_receiver_entry_list[20].startswith(REMOTE_APP)
                    ) and (not isinstance(terminal_latency_ms, str)):
                        if br_receiver_entry_list[3] == 2:
                            result_map["avg_receiverFilter_terminal_latency(ms)"] += (
                                terminal_latency_ms
                            )
                            avg_receiverFilter_terminal_latency_cnt += 1
                            if terminal_latency_ms >= 16 and terminal_latency_ms < 64:
                                result_map[
                                    "receiverFilter_terminal_latency(16~64ms)"
                                ] += 1
                            elif (
                                terminal_latency_ms >= 64 and terminal_latency_ms < 128
                            ):
                                result_map[
                                    "receiverFilter_terminal_latency(64~128ms)"
                                ] += 1
                            elif terminal_latency_ms >= 128:
                                result_map[
                                    "receiverFilter_terminal_latency(>128ms)"
                                ] += 1
                            else:
                                pass
                        if br_receiver_entry_list[3] == 1:
                            result_map["avg_mainfest_terminal_latency(ms)"] += (
                                terminal_latency_ms
                            )
                            avg_mainfest_terminal_latency_cnt += 1
                            if terminal_latency_ms >= 64 and terminal_latency_ms < 256:
                                result_map["mainfest_terminal_latency(64~256ms)"] += 1
                            elif (
                                terminal_latency_ms >= 256 and terminal_latency_ms < 512
                            ):
                                result_map["mainfest_terminal_latency(256~512ms)"] += 1
                            elif terminal_latency_ms >= 512:
                                result_map["mainfest_terminal_latency(>512ms)"] += 1
                            else:
                                pass
                    else:
                        pass

        if avg_key_br_scheduled_latency_cnt != 0:
            result_map["avg_key_br_scheduled_latency(ms)"] = int(
                round(
                    result_map["avg_key_br_scheduled_latency(ms)"]
                    / avg_key_br_scheduled_latency_cnt,
                    0,
                )
            )
        if avg_fg_br_scheduled_latency_cnt != 0:
            result_map["avg_fg_br_scheduled_latency(ms)"] = int(
                round(
                    result_map["avg_fg_br_scheduled_latency(ms)"]
                    / avg_fg_br_scheduled_latency_cnt,
                    0,
                )
            )
        if avg_offload_br_scheduled_latency_cnt != 0:
            result_map["avg_offload_br_scheduled_latency(ms)"] = int(
                round(
                    result_map["avg_offload_br_scheduled_latency(ms)"]
                    / avg_offload_br_scheduled_latency_cnt,
                    0,
                )
            )
        if avg_bg_br_scheduled_latency_cnt != 0:
            result_map["avg_bg_br_scheduled_latency(ms)"] = int(
                round(
                    result_map["avg_bg_br_scheduled_latency(ms)"]
                    / avg_bg_br_scheduled_latency_cnt,
                    0,
                )
            )
        if avg_receiverFilter_terminal_latency_cnt != 0:
            result_map["avg_receiverFilter_terminal_latency(ms)"] = int(
                round(
                    result_map["avg_receiverFilter_terminal_latency(ms)"]
                    / avg_receiverFilter_terminal_latency_cnt,
                    0,
                )
            )
        if avg_mainfest_terminal_latency_cnt != 0:
            result_map["avg_mainfest_terminal_latency(ms)"] = int(
                round(
                    result_map["avg_mainfest_terminal_latency(ms)"]
                    / avg_mainfest_terminal_latency_cnt,
                    0,
                )
            )
        # result_map["iaware_skip_receiver_cnt"] -= iaware_ctrl_type_br_cnt
        return result_map

    def to_format_duration_ms(strTime):
        if not isinstance(strTime, str):
            return strTime
        if strTime == "na" or ("-" in strTime) or ("d" in strTime):
            return strTime
        duration_ms = 0
        duration = 0
        if strTime.count("h") == 1:
            dt = datetime.strptime(strTime, "+%Hh%Mm%Ss%fms")
            duration = dt - datetime.strptime("+0m0s0ms", "+%Mm%Ss%fms")
        elif strTime.count("m") == 2:
            dt = datetime.strptime(strTime, "+%Mm%Ss%fms")
            duration = dt - datetime.strptime("+0m0s0ms", "+%Mm%Ss%fms")
        elif strTime.count("s") == 2:
            dt = datetime.strptime(strTime, "+%Ss%fms")
            duration = dt - datetime.strptime("+0m0s0ms", "+%Mm%Ss%fms")
        elif (strTime.count("m") == 1) and (strTime.count("s") == 1):
            dt = datetime.strptime(strTime, "+%fms")
            duration = dt - datetime.strptime("+0m0s0ms", "+%Mm%Ss%fms")
        if str(duration) != "0":
            duration_ms = duration.seconds * 1000 + duration.microseconds / 1000
        return duration_ms

    # 判断逻辑需要与AOSP保持一致
    def is_urgent_br(str_br_flg, str_options_flg):
        is_urgent = 0
        if (str_br_flg == "na") and (str_options_flg == "na"):
            return is_urgent
        if str_br_flg != "na":
            int16_br_flg = int(str_br_flg, 16)
            if ((int16_br_flg & FLAG_RECEIVER_KEY_QUEUE) != 0) or (
                (int16_br_flg & FLAG_RECEIVER_FOREGROUND) != 0
            ):
                is_urgent = 1
        if str_options_flg != "na":
            int16_options_flg = int(str_options_flg)
            if ((int16_options_flg & FLAG_INTERACTIVE) != 0) or (
                (int16_options_flg & FLAG_IS_ALARM_BROADCAST) != 0
            ):
                is_urgent = 1
        return is_urgent

    # 判断逻辑需要与AOSP保持一致
    def is_offload_br(str_flg):
        if str_flg == "na":
            return 0
        is_offload = (int(str_flg, 16) & FLAG_RECEIVER_OFFLOAD) != 0
        return 1 if is_offload else 0

    # 判断逻辑需要与AOSP保持一致
    def is_defer_until_active_br(
        ordered, result_to, options_deferralPolicy, is_urgent, caller_pkg_uid, br_action
    ):
        is_defer_until_active = 0
        if ordered == 1:
            return 0
        if (ordered != 1) and (result_to != "na"):
            return 1
        if options_deferralPolicy != "na":
            if options_deferralPolicy == "2":
                return 1
            elif options_deferralPolicy == "1":
                return 0
        if is_urgent == 1:
            return 0
        if int(caller_pkg_uid) < FIRST_APPLICATION_UID:
            return 1
        return is_defer_until_active

    def str_bool_to_int(str_bool):
        return 1 if (str_bool == "true") else 0

    def is_zero_time(strTime):
        if strTime == "na" or ("-" in strTime) or ("d" in strTime):
            return 0
        dt = datetime.strptime(strTime, "%Y-%m-%d %H:%M:%S.%f")
        duration = dt - datetime.strptime("+0m0s0ms", "+%Mm%Ss%fms")
        if str(duration) == "0":
            return 1
        else:
            return 0
