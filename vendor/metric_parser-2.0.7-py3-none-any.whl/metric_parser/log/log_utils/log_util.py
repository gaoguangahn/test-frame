keywordKilling = 'I ActivityManager: Killing'
keywordStartUp = 'I ActivityManager: Start proc'
keywordIawareStartUp = 'AwareLog: AppStart: req'


def iaware_log_read(logfile):
    # 关键字到结果列表的映射
    kill_results = []
    start_up_results = []
    iaware_start_up_results = []
    merge_start_up_results = []

    with open(logfile, 'rt', errors='ignore') as f:
        for line in f:
            if keywordKilling in line:
                kill_results.append(line.strip())
            if keywordStartUp in line:
                start_up_results.append(line.strip())
            if keywordIawareStartUp in line:
                iaware_start_up_results.append(line.strip())

    merge_start_up_results = start_up_results + iaware_start_up_results

    return kill_results, start_up_results, iaware_start_up_results, merge_start_up_results
