"""
Jank 日志分析模块

功能：统计 LMK、JLOG 等卡顿相关日志的出现次数和耗时分布。
"""

import re

from metric_parser.log.base.base_analyser import BaseLogAnalyse
from metric_parser.log.base.registry import AnalyseRegistry


@AnalyseRegistry.register("jank_log")
class JankLogAnalyser(BaseLogAnalyse):
    """卡顿日志分析器"""

    def __init__(self, context):

        super().__init__(context)

        self.jlog413_pattern = re.compile(
            r".*?\[JLOG413]: "
            r"#ARG1:<([^>]*)>"
            r"#ARG2:<(\d+)>"
            r"#ARG3:<(\d+)>"
        )

    def analyse(self, **kwargs):

        result = {
            "logcat日志.lmkd": 0,
            "logcat日志.JLOG475": 0,
            "logcat日志.JLOG480": 0,
            "type_jank": [],
        }

        try:
            for raw_line in self.context.iter_lines():
                line = raw_line.strip()

                if not line:
                    continue

                self._process_line(
                    line=line,
                    result=result,
                )

            if result["type_jank"]:
                self.logger.d(f"jank_log 解析完成: {self.context.name}, "
                              f"lmkd={result['logcat日志.lmkd']}, "
                              f"JLOG475={result['logcat日志.JLOG475']}, "
                              f"JLOG480={result['logcat日志.JLOG480']}, "
                              f"type_jank={len(result['type_jank'])} 条")
            else:
                self.logger.w(f"未匹配到 type_jank 数据: {self.context.name}")

            return self.success(result)
        except Exception as e:
            self.logger.e(f"解析 jank_log 失败: {e}")
            return self.fail(f"处理 JLOG 文件失败: {e}")

    def _process_line(self, line, result):
        """处理单行日志"""

        # LMK
        if "JLOG396" in line and "lmk" in line:
            result["logcat日志.lmkd"] += 1
            return

        # JLOG475
        if "JLOG475" in line:
            result["logcat日志.JLOG475"] += 1
            return

        # JLOG480
        if "JLOG480" in line:
            result["logcat日志.JLOG480"] += 1
            return

        # JLOG413
        match = self.jlog413_pattern.search(line)

        if not match:
            return

        try:
            cost_time = int(match.group(2))

        except ValueError:
            return

        result["type_jank"].append(cost_time)
