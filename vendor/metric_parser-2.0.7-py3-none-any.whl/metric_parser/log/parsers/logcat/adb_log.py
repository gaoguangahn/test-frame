"""
ADB 日志分析模块

功能：解析 adblogs 中的 iAware 日志，提取杀进程记录、自启记录等。
"""

from metric_parser.log.base.base_analyser import BaseLogAnalyse
from metric_parser.log.base.registry import AnalyseRegistry

KEYWORD_KILLING = "I ActivityManager: Killing"

KEYWORD_STARTUP = "I ActivityManager: Start proc"

KEYWORD_IAWARE_STARTUP = "AwareLog: AppStart: req"


@AnalyseRegistry.register("adb_log")
class AdbLogAnalyser(BaseLogAnalyse):
    """ADB 日志分析器"""

    def __init__(self, context):
        super().__init__(context)

    def analyse(self, **kwargs):
        """解析单个 adb 日志文件，返回分类后的原始记录列表。"""
        try:
            kill_results = []
            startup_results = []
            iaware_startup_results = []

            for raw_line in self.context.iter_lines():
                line = raw_line.strip()

                if not line:
                    continue

                self._process_line(
                    line=line,
                    kill_results=kill_results,
                    startup_results=startup_results,
                    iaware_startup_results=iaware_startup_results,
                )

            merge_results = startup_results + iaware_startup_results

            result = {
                "kill_res": kill_results,
                "startup_res": startup_results,
                "iaware_res": iaware_startup_results,
                "merge_res": merge_results,
            }

            if not kill_results and not startup_results and not iaware_startup_results:
                self.logger.w(f"未匹配到任何 kill/startup 数据: {self.context.name}")

            return self.success(result)

        except Exception as e:
            self.logger.e(f"解析 adb_log 失败: {e}")
            return self.fail(e)

    def _process_line(
        self, line, kill_results, startup_results, iaware_startup_results
    ):
        """处理单行日志"""

        if KEYWORD_KILLING in line:
            kill_results.append(line)

        if KEYWORD_STARTUP in line:
            startup_results.append(line)

        if KEYWORD_IAWARE_STARTUP in line:
            iaware_startup_results.append(line)
