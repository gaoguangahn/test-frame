"""
Event Log 日志分析模块

功能：解析 events_logcat 日志，提取 wm_activity_launch_time 活动启动耗时数据。
"""

import re

from metric_parser.log.base.base_analyser import BaseLogAnalyse
from metric_parser.log.base.registry import AnalyseRegistry


@AnalyseRegistry.register("events_log", desc="Event Log Activity 启动耗时分析")
class EventsLogAnalyser(BaseLogAnalyse):
    """EVENTS 日志分析器"""

    PATTERN = re.compile(
        r"^(\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d+).*wm_activity_launch_time: \[.*?,.*?,(.*?),(.*?)]$"
    )

    def __init__(self, context):
        super().__init__(context)

    def analyse(self, **kwargs):
        """解析单个 event_logcat 文件，返回 Activity 启动耗时列表。"""
        try:
            result = []

            for raw_line in self.context.iter_lines():
                line = raw_line.strip()

                if "wm_activity_launch_time" not in line:
                    continue

                item = self._parse_line(line)

                if item:
                    result.append(item)

            if not result:
                self.logger.w(
                    f"未匹配到 wm_activity_launch_time 数据: {self.context.name}"
                )

            return self.success(result)

        except Exception as e:
            self.logger.e(f"解析 events_log 失败: {e}")
            return self.fail(e)

    def _parse_line(self, line):
        """解析单行日志"""

        match = self.PATTERN.match(line)

        if not match:
            return None

        try:
            time_str = match.group(1)
            activity = match.group(2)
            value = int(match.group(3))

        except Exception:
            return None

        package = activity.split("/")[0] if "/" in activity else activity

        return {
            "Time": time_str,
            "Package": package,
            "Activity": activity,
            "Value": value,
        }
