from metric_parser.log.base.registry import AnalyseRegistry

from .base import BaseRadarAnalyser


@AnalyseRegistry.register("animation_jank")
class AnimationJankAnalyser(BaseRadarAnalyser):

    TARGET_TYPE = "ANIMATION_JANK_FRAME"
