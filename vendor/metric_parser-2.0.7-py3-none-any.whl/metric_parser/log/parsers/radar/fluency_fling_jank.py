from metric_parser.log.base.registry import AnalyseRegistry

from .base import BaseRadarAnalyser


@AnalyseRegistry.register("fluency_fling_jank")
class FluencyFlingJankAnalyser(BaseRadarAnalyser):

    TARGET_TYPE = "FLUENCY_FLING_JANK_FRAME"
