from metric_parser.log.base.base_analyser import BaseLogAnalyse


class BaseRadarAnalyser(BaseLogAnalyse):
    TARGET_TYPE = ""

    def analyse(self, **kwargs):
        """性能雷达分析基类"""
        try:
            # 文件名
            time = int(self.context.stem.split("_")[-1])

            # JSON 数据
            bd_data = self.context.json_data

            data = []

            for entry in bd_data.get("BigData", []):
                comment = entry.get("strComment", "")

                if comment != self.TARGET_TYPE:
                    continue

                if not entry.get("Items"):
                    continue

                marks = [int(x["Mark"]) for x in entry.get("Marks", [])]

                for item in entry["Items"]:
                    name_all = item["name"]

                    if "#FLING_WEBVIEW" in name_all:
                        continue

                    parts = name_all.rsplit("#", 1)

                    if len(parts) == 2:
                        jank_name = parts[0]
                        jank_type = parts[1]

                    else:
                        jank_name = name_all
                        jank_type = ""

                    counts = [int(x["Count"]) for x in item["Counts"]]

                    data.append(
                        {
                            "Comment": comment,
                            "Name": jank_name,
                            "Type": jank_type,
                            "Marks": marks,
                            "Counts": counts,
                        }
                    )

            if not data:
                self.logger.w(
                    f"Radar 未匹配到 {self.TARGET_TYPE} 数据: {self.context.name}"
                )

            return self.success({"time": time, "data": data})

        except Exception as e:
            self.logger.e(f"解析 radar ({self.TARGET_TYPE}) 失败: {e}")
            return self.fail(e)
