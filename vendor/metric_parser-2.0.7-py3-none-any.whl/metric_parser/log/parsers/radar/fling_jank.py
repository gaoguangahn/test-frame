from metric_parser.log.base.registry import AnalyseRegistry

from .base import BaseRadarAnalyser


@AnalyseRegistry.register("fling_jank")
class FlingJankAnalyser(BaseRadarAnalyser):

    TARGET_TYPE = "FLING_JANK_FRAME"
