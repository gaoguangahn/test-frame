"""
IOStat 日志分析模块

功能：解析 /sys/block/*/stat 采样数据，提取读写扇区数、IO 延迟等基础指标。
"""

from typing import Any

from metric_parser.log.base.base_analyser import BaseLogAnalyse
from metric_parser.log.base.registry import AnalyseRegistry

IOSTAT_KEYS = [
    "Read-cnt",
    "Rmerge-cnt",
    "R-sectors",
    "Read-ms",
    "Write-cnt",
    "Wmerge-cnt",
    "W-sectors",
    "Write-ms",
    "inflat-IO",
    "IO-time",
    "IO-weighted-ms",
    "Discard-cnt",
    "discard-merge-cnt",
    "discard-sectors",
    "discard-ms",
    "flush-cnt",
    "flush-ms",
]


@AnalyseRegistry.register("io_stat", desc="IO Stat 日志分析")
class IOStatAnalyser(BaseLogAnalyse):
    """解析 /sys/block/*/stat 采样数据，提取读写扇区数、IO 延迟等基础指标。"""

    def __init__(self, context):
        super().__init__(context)

    def analyse(self, **kwargs):
        try:
            filename = self.context.name

            if not filename.endswith(".txt"):
                return self.fail("不是 txt 文件")

            timestamp = self._parse_timestamp(filename)

            if timestamp is None:
                self.logger.w(f"IOStat 时间戳解析失败: {filename}")
                return self.fail("时间戳解析失败")

            first_line = self._get_first_line()

            if not first_line:
                self.logger.w(f"IOStat 文件为空: {filename}")
                return self.fail("文件为空")

            values = first_line.split()

            if len(values) != len(IOSTAT_KEYS):
                self.logger.w(f"IOStat 字段数量异常: 期望 {len(IOSTAT_KEYS)}, 实际 {len(values)}")
                return self.fail("IOStat 字段数量异常")

            result: dict[str, Any] = dict(zip(IOSTAT_KEYS, values))

            result["Timestamp"] = timestamp

            return self.success(result)
        
        except Exception as e:
            return self.fail(e)

    def _parse_timestamp(self, filename: str):
        """从文件名解析时间戳"""

        stem = filename[:-4]

        parts = stem.split("_")

        if len(parts) < 2:
            return None

        try:
            return int(parts[-1])

        except ValueError:
            return None

    def _get_first_line(self):

        for line in self.context.iter_lines():
            return line.strip()

        return None
