"""
IO Measure 日志分析模块

功能：解析 ProcIOMeasure 输出，统计 fs/block/scsi 三层 IO 的读写次数、延迟分布。
"""

from metric_parser.log.base.base_analyser import BaseLogAnalyse
from metric_parser.log.base.registry import AnalyseRegistry


@AnalyseRegistry.register("io_measure", desc="IO Measure 日志分析")
class IOMeasureAnalyser(BaseLogAnalyse):
    """解析 ProcIOMeasure 输出，统计 fs/block/scsi 三层 IO 的读写次数、延迟分布。"""

    IO_TYPES = ["fs", "block", "scsi"]
    IO_KEYS = {"fs": "Latency-fs", "block": "Latency-blk", "scsi": "Latency-scsi"}

    def __init__(self, context):
        super().__init__(context)

    def analyse(self, **kwargs):
        try:
            file_data = {}
            # 初始化统计结构
            info_dict = self._init_info_dict()
            current_type = None

            # 新增标志位：记录是否匹配到了有效的 IO 数据行
            has_matched_lines = False

            for raw_line in self.context.iter_lines():
                line = raw_line.strip()
                if not line:
                    continue

                # Latency 标题行
                if "Latency" in line:
                    current_type = self._detect_io_type(line)
                    continue

                # IO 数据行
                if "IO" in line and current_type in self.IO_TYPES:
                    self._process_io_line(
                        line=line, io_type=current_type, info_dict=info_dict
                    )
                    # 只要成功进入处理逻辑，说明匹配到了有效行
                    has_matched_lines = True

            # 如果跑完整个文件，一行有效数据都没匹配到，说明文件为空或格式已变
            if not has_matched_lines:
                error_msg = f"IO Measure 未匹配到任何有效日志行: {self.context.name}"
                self.logger.e(error_msg)
                return self.fail(error_msg)

            # 汇总统计
            self._build_result(
                info_dict=info_dict,
                file_data=file_data,
            )

            return self.success(file_data)

        except Exception as e:
            self.logger.e(f"解析 io_measure 失败: {e}")
            return self.fail(e)

    def _init_info_dict(self):
        """初始化统计结构"""

        return {io_type: [[0, 0, 0] for _ in range(11)] for io_type in self.IO_TYPES}

    def _detect_io_type(self, line: str):
        """检测当前 IO 类型"""

        for io_type in self.IO_TYPES:
            if io_type in line:
                return io_type

        return None

    def _process_io_line(self, line, io_type, info_dict):
        """处理 IO 行"""

        if ":" not in line:
            return

        data_part = line.split(":", 1)[1].strip()

        fields = data_part.split()[:11]

        for col, item in enumerate(fields):
            try:
                nums = list(map(int, item.split("/")))

            except Exception:
                continue

            if len(nums) != 3:
                continue

            for idx in range(3):
                info_dict[io_type][col][idx] += nums[idx]

    def _build_result(self, info_dict, file_data):
        """构建最终结果"""

        for io_type in self.IO_TYPES:
            prefix = self.IO_KEYS[io_type]

            info = info_dict[io_type]

            read_cnt = sum(item[0] for item in info)

            write_cnt = sum(item[1] for item in info)

            other_cnt = sum(item[2] for item in info)

            all_cnt = sum(sum(item) for item in info)

            file_data[f"{prefix}.read_cnt"] = read_cnt

            file_data[f"{prefix}.write_cnt"] = write_cnt

            file_data[f"{prefix}.other_cnt"] = other_cnt

            file_data[f"{prefix}.all_cnt"] = all_cnt

            # 4~8ms
            file_data[f"{prefix}.read(4~8ms)"] = info[3][0]

            file_data[f"{prefix}.write(4~8ms)"] = info[3][1]

            # 8~16ms
            file_data[f"{prefix}.read(8~16ms)"] = info[4][0]

            file_data[f"{prefix}.write(8~16ms)"] = info[4][1]

            # >16ms
            file_data[f"{prefix}.read(>16ms)"] = sum(item[0] for item in info[5:])

            file_data[f"{prefix}.write(>16ms)"] = sum(item[1] for item in info[5:])
