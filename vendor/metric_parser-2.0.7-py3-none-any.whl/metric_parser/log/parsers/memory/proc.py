"""
Proc Memory 日志分析模块

功能：
解析：
- /proc/meminfo
- /proc/vmstat
- /proc/pressure/memory
- /dev/memcg/memory.psi_health_info

等系统内存指标。
"""

from pathlib import Path

from metric_parser.log.base.base_analyser import BaseLogAnalyse
from metric_parser.log.base.registry import AnalyseRegistry
from metric_parser.utils.util import load_from_json

EMPTY = "-"


@AnalyseRegistry.register("proc_memory")
class ProcMemoryAnalyser(BaseLogAnalyse):
    """解析 /proc/meminfo 等系统内存指标"""

    def __init__(self, context):
        super().__init__(context)

        base_dir = Path(__file__).resolve().parent.parent.parent
        memory_metric_path = base_dir / "configs" / "memory_metric.json"
        configs = load_from_json(memory_metric_path)
        if not configs:
            raise RuntimeError("读取配置文件 memory_metric.json 失败")

        self.memory_metrics = configs["memory_metrics"]

        self.section_processors = {
            "proc_meminfo": self._process_meminfo,
            "proc_vmstat": self._process_vmstat,
            "proc_pressure_memory": self._process_pressure_memory,
            "memory.psi_health_info": self._process_psi_health_info,
        }

    def analyse(self, **kwargs):
        data = {}
        try:
            current_section = "proc_meminfo"
            process_next_line = False
            direct_reclaim = 0

            for raw_line in self.context.iter_lines():
                line = raw_line.strip()
                if not line:
                    continue

                current_section = self._detect_section(
                    line=line,
                    current_section=current_section,
                )

                processor = self.section_processors.get(current_section)

                if not processor:
                    continue

                # vmstat
                if current_section == "proc_vmstat":
                    direct_reclaim = processor(
                        line=line,
                        file_data=data,
                        direct_reclaim=direct_reclaim,
                    )

                # pressure memory
                elif current_section == "proc_pressure_memory":
                    process_next_line = processor(
                        line=line,
                        file_data=data,
                        process_next_line=process_next_line,
                    )

                # 普通 section
                else:
                    processor(line=line, file_data=data)

            if not data:
                error_msg = f"Proc Memory 未解析到任何有效指标，请检查日志文件: {self.context.name}"
                self.logger.e(error_msg)
                return self.fail(error_msg)

            data["/proc/vmstat.direct_reclaim"] = direct_reclaim

            return self.success(data)

        except Exception as e:
            self.logger.e(f"解析 proc_memory 失败: {e}")
            return self.fail(e)

    def _detect_section(self, line: str, current_section: str):
        """检测当前 section"""
        # meminfo -> vmstat
        if current_section == "proc_meminfo":
            if ":" not in line and "kB" not in line:
                return "proc_vmstat"

        # vmstat -> pressure memory
        elif current_section == "proc_vmstat":
            if "avg10" in line:
                return "proc_pressure_memory"

        # pressure memory -> psi health
        elif current_section == ("proc_pressure_memory"):
            if "avg10" not in line:
                return "memory.psi_health_info"

        return current_section

    def _process_meminfo(self, line, file_data):
        """处理/proc/meminfo数据"""

        if not line or ":" not in line:
            return

        parts = line.split(":", 1)
        if len(parts) != 2:
            return

        key = parts[0].strip()
        value_str = parts[1].strip()

        if key not in self.memory_metrics.get("/proc/meminfo", []):
            return

        value_parts = value_str.split()
        if not value_parts:
            file_data[f"/proc/meminfo.{key}"] = EMPTY
            return

        try:
            value_num = int(value_parts[0])
        except ValueError:
            file_data[f"/proc/meminfo.{key}"] = EMPTY
        else:
            file_data[f"/proc/meminfo.{key}"] = value_num

    def _process_vmstat(self, line, file_data, direct_reclaim):
        """处理/proc/vmstat数据"""

        parts = line.split(None, 1)
        if len(parts) != 2:
            return direct_reclaim

        key, value = parts
        value = value.strip()

        if key in self.memory_metrics["/proc/vmstat"]:
            file_data[f"/proc/vmstat.{key}"] = value.strip()
        elif (
            "allocstall_dma" in key
            or "allocstall_normal" in key
            or "allocstall_movable" in key
        ):
            try:
                direct_reclaim += int(value.strip())
            except ValueError:
                pass
        return direct_reclaim

    def _process_pressure_memory(self, line, file_data, process_next_line):
        """处理/proc/pressure/memory数据"""

        parts = line.split()
        if not parts:
            return process_next_line

        prefix = parts[0]

        if prefix == "some":
            process_next_line = True
        elif process_next_line:
            process_next_line = False
        else:
            return process_next_line

        for item in parts[1:]:
            if "=" in item:
                k, v = item.split("=")
                if k not in ["avg10", "avg60", "avg300"]:
                    continue
                metric_key = f"{prefix}_{k}"
                if metric_key not in self.memory_metrics["/proc/pressure/memory"]:
                    continue
                try:
                    file_data[f"/proc/pressure/memory.{metric_key}"] = float(v.strip())
                except ValueError:
                    file_data[f"/proc/pressure/memory.{metric_key}"] = EMPTY

        return process_next_line

    def _process_psi_health_info(self, line, file_data):
        """处理/dev/memcg/memory.psi_health_info数据"""

        if ":" not in line:
            return

        key, value = line.split(":", 1)
        key = key.strip()

        if key not in self.memory_metrics["/dev/memcg/memory.psi_health_info"]:
            return

        try:
            value_num = value.strip().split()[0]
        except Exception:
            value_num = EMPTY

        file_data[f"/dev/memcg/memory.psi_health_info.{key}"] = value_num
