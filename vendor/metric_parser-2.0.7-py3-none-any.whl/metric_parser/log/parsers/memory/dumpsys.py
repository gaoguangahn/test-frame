"""
Dumpsys Memory 日志分析模块

功能：解析 dumpsys meminfo 输出，提取 Free RAM、DMA-BUF、GPU、Used RAM、ZRAM 等内存指标。
"""

import re

from metric_parser.log.base.base_analyser import BaseLogAnalyse
from metric_parser.log.base.registry import AnalyseRegistry


@AnalyseRegistry.register("dumpsys_meminfo")
class DumpsysMemoryAnalyser(BaseLogAnalyse):
    """解析 dumpsys meminfo 输出，提取 Free RAM、DMA-BUF、GPU、Used RAM、ZRAM 等内存指标"""

    def __init__(self, context):
        super().__init__(context)

    def analyse(self, **kwargs):
        file_data = {}
        try:
            tail_lines = []

            for line in self.context.iter_lines():
                tail_lines.append(line)

                if len(tail_lines) > 50:
                    tail_lines.pop(0)

            for raw_line in tail_lines:
                line = raw_line.strip()
                if not line:
                    continue

                # Free RAM
                if line.startswith("Free RAM:"):
                    value = line.split(":", 1)[1].strip()
                    file_data["dumpsys meminfo.FreeRAM"] = value

                # DMA-BUF
                elif line.startswith("DMA-BUF:"):
                    match = re.search(
                        r"\(\s*(-?[\d,]+)K\s*mapped\s*\+\s*(-?[\d,]+)K\s*unmapped\s*\)",
                        line,
                    )
                    if not match:
                        continue

                    file_data["dumpsys meminfo.DMA-BUF_mapped"] = (
                        match.group(1).replace(",", "") + "K"
                    )
                    file_data["dumpsys meminfo.DMA-BUF_unmapped"] = (
                        match.group(2).replace(",", "") + "K"
                    )

                # GPU
                elif line.startswith("GPU:"):
                    match = re.search(
                        r"\(\s*(-?[\d,]+)K\s*dmabuf\s*\+\s*(-?[\d,]+)K\s*private\s*\)",
                        line,
                    )

                    if not match:
                        continue

                    file_data["dumpsys meminfo.GPU_dmabuf"] = (
                        match.group(1).replace(",", "") + "K"
                    )
                    file_data["dumpsys meminfo.GPU_private"] = (
                        match.group(2).replace(",", "") + "K"
                    )

                # Used RAM
                elif line.startswith("Used RAM:"):
                    match = re.search(
                        r"\(\s*(-?[\d,]+)K\s*used pss\s*\+\s*(-?[\d,]+)K\s*kernel\s*\)",
                        line,
                    )
                    if not match:
                        continue

                    file_data["dumpsys meminfo.UsedRAM_usedpss"] = (
                        match.group(1).replace(",", "") + "K"
                    )
                    file_data["dumpsys meminfo.UsedRAM_kernel"] = (
                        match.group(2).replace(",", "") + "K"
                    )

                # ZRAM
                elif line.startswith("ZRAM:"):
                    match = re.search(
                        r"ZRAM:\s*([-\d,]+)K\s*physical used for\s*([-\d,]+)K\s*in swap\s*\(\s*([-\d,]+)K\s*total swap\s*\)",
                        line,
                    )
                    if not match:
                        continue

                    file_data["dumpsys meminfo.ZRAM_physical_used"] = (
                        match.group(1).replace(",", "") + "K"
                    )
                    file_data["dumpsys meminfo.ZRAM_swap"] = (
                        match.group(2).replace(",", "") + "K"
                    )
                    file_data["dumpsys meminfo.ZRAM_total_swap"] = (
                        match.group(3).replace(",", "") + "K"
                    )

            # 遍历结束后，如果字典还是空的，说明一行有效数据都没匹配到
            if not file_data:
                error_msg = f"dumpsys meminfo 未匹配到任何有效数据，请检查日志文件: {self.context.name}"
                self.logger.e(error_msg)
                return self.fail(error_msg)

            return self.success(file_data)

        except Exception as e:
            return self.fail(e)
