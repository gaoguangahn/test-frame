# Log Analysis

基于注册表模式的日志分析框架。通过统一入口调度各分析器，支持上下文感知和流式读取。

## 快速开始

```python
from metric_parser.log.log_analysis import LogAnalysis

analyse_tasks = [
    {"metric": "events_logcat", "params": {}},
    {"metric": "jank_logcat", "params": {}},
    {"metric": "radar", "params": {}},
]

results = LogAnalysis.analysis_log(
    log_file_path="/path/to/log_file.log",
    analyse_tasks=analyse_tasks,
    device_brand="Honor"
)
```

## 可用分析器

### Logcat 类

#### `jank_logcat` — 卡顿日志分析

统计 LMK 杀进程、JLOG475/JLOG480 等卡顿相关日志的出现次数和 doFrame 耗时分布。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| 无 | — | — | 无需额外参数 |

返回字段：`logcat日志.lmkd`, `logcat日志.JLOG475`, `logcat日志.JLOG480`, `type_jank`(耗时列表)

```python
{"metric": "jank_logcat", "params": {}}
```

#### `events_logcat` — Activity 启动耗时分析

解析 events_logcat 中的 `wm_activity_launch_time` 事件，提取各 Activity 启动耗时。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| 无 | — | — | 无需额外参数 |

返回字段：列表，每项包含 `Time`, `Package`, `Activity`, `Value`(ms)

```python
{"metric": "events_logcat", "params": {}}
```

#### `adb_logcat` — ADB 日志分析

解析 adblogs 中的 iAware 日志，提取杀进程记录、进程自启记录等。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| 无 | — | — | 无需额外参数 |

返回字段：`kill_results`, `startup_results`, `iaware_startup_results`

```python
{"metric": "adb_logcat", "params": {}}
```

### IO 类

#### `io_measure` — IO Measure 日志分析

解析 ProcIOMeasure 输出，统计 fs/block/scsi 三层 IO 的读写次数和延迟分布。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| 无 | — | — | 无需额外参数 |

返回字段：`Latency-fs.read_cnt`, `Latency-fs.write_cnt`, `Latency-fs.read(4~8ms)`, `Latency-fs.read(>16ms)` 等，block/scsi 同理。

```python
{"metric": "io_measure", "params": {}}
```

#### `io_stat` — IO Stat 日志分析

解析 `/sys/block/*/stat` 采样数据，提取读写扇区数、IO 延迟等基础指标。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| 无 | — | — | 无需额外参数 |

返回字段：`Read-cnt`, `R-sectors`, `Read-ms`, `Write-cnt`, `W-sectors`, `Write-ms`, `Discard-cnt`, `discard-sectors`, `flush-cnt`, `Timestamp`

```python
{"metric": "io_stat", "params": {}}
```

### Memory 类

#### `proc_memory` — 系统内存指标

解析 `/proc/meminfo`、`/proc/vmstat`、`/proc/pressure/memory` 等系统内存指标文件。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| 无 | — | — | 无需额外参数 |

返回字段：`/proc/meminfo.MemAvailable`, `/proc/meminfo.MemFree`, `/proc/meminfo.Active(anon)`, `/proc/vmstat.*`, `/proc/pressure/memory.some_avg10` 等

```python
{"metric": "proc_memory", "params": {}}
```

#### `dumpsys_meminfo` — Dumpsys Meminfo 分析

解析 `dumpsys meminfo` 输出，提取 Free RAM、DMA-BUF、GPU、Used RAM、ZRAM 等内存快照指标。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| 无 | — | — | 无需额外参数 |

返回字段：`dumpsys meminfo.FreeRAM`, `dumpsys meminfo.DMA-BUF_mapped`, `dumpsys meminfo.GPU_dmabuf`, `dumpsys meminfo.UsedRAM_usedpss`, `dumpsys meminfo.ZRAM_physical_used` 等

```python
{"metric": "dumpsys_meminfo", "params": {}}
```

### Radar 类

#### `animation_jank` — 动画掉帧分析

解析性能雷达 JSON 中的 `ANIMATION_JANK_FRAME` 数据，分析各 Activity 动画掉帧情况。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| 无 | — | — | 无需额外参数 |

返回字段：`time`, `data`(包含 `Comment`, `Name`, `Type`, `Marks`, `Counts`)

```python
{"metric": "animation_jank", "params": {}}
```

#### `fling_jank` — Fling 掉帧分析

解析性能雷达 JSON 中的 `FLING_JANK_FRAME` 数据。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| 无 | — | — | 无需额外参数 |

返回字段同 `animation_jank`。

```python
{"metric": "fling_jank", "params": {}}
```

#### `fluency_fling_jank` — 流畅性 Fling 掉帧分析

解析性能雷达 JSON 中的 `FLUENCY_FLING_JANK_FRAME` 数据。

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| 无 | — | — | 无需额外参数 |

返回字段同 `animation_jank`。

```python
{"metric": "fluency_fling_jank", "params": {}}
```

## 完整调用示例

```python
from metric_parser.log.log_analysis import LogAnalysis

log_file = r"D:\perflog\radar\KuaiShou_end_102.txt"

analyse_tasks = [
    {"metric": "animation_jank", "params": {}},
    {"metric": "events_logcat", "params": {}},
    {"metric": "jank_logcat", "params": {}},
]

results = LogAnalysis.analysis_log(
    log_file_path=log_file,
    analyse_tasks=analyse_tasks,
    device_brand="Honor"
)

for item in results:
    print(f"metric: {item['metric']}, result: {item['result']}")
```

## 返回结构

```python
[
    {"metric": "animation_jank", "result": AnalyseResult(success=True, data={...})},
    {"metric": "events_logcat", "result": AnalyseResult(success=True, data=[...])},
    {"metric": "unknown_metric", "result": AnalyseResult(success=False, error="...")},
]
```

每个 task 对应一个元素。通过 `result.success` 判断是否成功，`result.data` 获取解析数据。

## 查看所有已注册分析器

```python
from metric_parser.log.base.registry import AnalyseRegistry

print(AnalyseRegistry.list_all())
```
