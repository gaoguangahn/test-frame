import inspect
import logging
import os


class ParseLogger:
    _LOGGER_NAME = "Parser"
    _initialized = False  # 用于标记是否已经全局初始化过

    @classmethod
    def init_logger(cls, console: bool = True, log_file: str | None = None, level: int = logging.DEBUG):
        """
        初始化解析库的全局日志配置。
        建议调用方在导入本库后，第一时间调用此方法。
        
        :param console: 是否将日志打印到终端 (默认 True)
        :param log_file: 日志保存的文件路径，如果为 None 则不保存到文件
        :param level: 日志的最低输出级别
        """
        logger = logging.getLogger(cls._LOGGER_NAME)
        logger.setLevel(level)
        logger.propagate = False  # 防止日志向上传递给调用方的 root logger，避免重复打印

        # 清理旧的 handlers，防止多次调用 init_logger 导致日志重复
        if logger.hasHandlers():
            logger.handlers.clear()

        formatter = logging.Formatter(
            "[%(asctime)s] [%(levelname)s] [%(tag)s] - %(message)s"
        )

        # 1. 配置文件输出
        if log_file:
            # 自动创建日志文件所在的目录
            os.makedirs(os.path.dirname(os.path.abspath(log_file)), exist_ok=True)
            file_handler = logging.FileHandler(log_file, encoding='utf-8')
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)

        # 2. 配置终端输出
        if console:
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            logger.addHandler(console_handler)

        # 如果既不输出到终端，也不输出到文件，可以添加一个 NullHandler 避免 logging 报错
        if not console and not log_file:
            logger.addHandler(logging.NullHandler())

        cls._initialized = True

    def __init__(self, tag=None):
        self.logger = logging.getLogger(self._LOGGER_NAME)
    
        self.tag = tag or self._auto_tag()

    def _auto_tag(self):
        frame = inspect.currentframe()
        try:
            for _ in range(2):
                if frame:
                    frame = frame.f_back
            if frame:
                module = frame.f_globals.get("__name__", "")
                return module.split(".")[-1]
            return "unknown"
        finally:
            del frame

    def _log(self, level, message):
        self.logger.log(level, message, extra={"tag": self.tag})

    def d(self, message):
        self._log(logging.DEBUG, message)

    def i(self, message):
        self._log(logging.INFO, message)

    def w(self, message):
        self._log(logging.WARNING, message)

    def e(self, message):
        self._log(logging.ERROR, message)

    def c(self, message):
        self._log(logging.CRITICAL, message)

        
logging.getLogger(ParseLogger._LOGGER_NAME).addHandler(logging.NullHandler())
